/**
 * TypeScript definitions for CoinAPI modules
 */

// Base types
export interface CoinAPIError {
  code: number;
  message: string;
}

export interface CoinAPIResponse<T> {
  data?: T;
  error?: CoinAPIError;
}

// Authentication types
export interface AuthConfig {
  apiKey?: string;
  baseURL?: string;
}

// Market Data types
export interface ExchangeRate {
  time: string;
  asset_id_base: string;
  asset_id_quote: string;
  rate: number;
}

export interface ExchangeRateResponse {
  asset_id_base: string;
  rates: ExchangeRate[];
}

export interface OHLCV {
  time_period_start: string;
  time_period_end: string;
  time_open: string;
  time_close: string;
  price_open: number;
  price_high: number;
  price_low: number;
  price_close: number;
  volume_traded: number;
  trades_count: number;
}

export interface Trade {
  symbol_id: string;
  time_exchange: string;
  time_coinapi: string;
  uuid: string;
  price: number;
  size: number;
  taker_side: 'BUY' | 'SELL';
  sequence?: number;
}

export interface Quote {
  symbol_id: string;
  time_exchange: string;
  time_coinapi: string;
  ask_price?: number;
  ask_size?: number;
  bid_price?: number;
  bid_size?: number;
  sequence?: number;
}

export interface OrderBookLevel {
  price: number;
  size: number;
}

export interface OrderBook {
  symbol_id: string;
  time_exchange: string;
  time_coinapi: string;
  asks: OrderBookLevel[];
  bids: OrderBookLevel[];
  sequence?: number;
}

export interface Symbol {
  symbol_id: string;
  exchange_id: string;
  symbol_type: 'SPOT' | 'FUTURES' | 'OPTION' | 'PERPETUAL' | 'INDEX';
  asset_id_base?: string;
  asset_id_quote?: string;
  asset_id_unit?: string;
  future_delivery_time?: string;
  option_type_is_call?: boolean;
  option_strike_price?: number;
  option_exercise_style?: string;
  price_precision?: number;
  size_precision?: number;
  data_start?: string;
  data_end?: string;
  data_quote_start?: string;
  data_quote_end?: string;
  data_trade_start?: string;
  data_trade_end?: string;
  data_orderbook_start?: string;
  data_orderbook_end?: string;
}

export interface Asset {
  asset_id: string;
  name: string;
  type_is_crypto: number;
  data_quote_start?: string;
  data_quote_end?: string;
  data_orderbook_start?: string;
  data_orderbook_end?: string;
  data_trade_start?: string;
  data_trade_end?: string;
  data_symbols_count?: number;
  volume_1hrs_usd?: number;
  volume_1day_usd?: number;
  volume_1mth_usd?: number;
  id_icon?: string;
}

export interface Exchange {
  exchange_id: string;
  website: string;
  name: string;
  data_quote_start: string;
  data_quote_end: string;
  data_orderbook_start: string;
  data_orderbook_end: string;
  data_trade_start: string;
  data_trade_end: string;
  data_symbols_count: number;
  volume_1hrs_usd: number;
  volume_1day_usd: number;
  volume_1mth_usd: number;
  id_icon?: string;
}

// Request options
export interface RequestOptions {
  retries?: number;
  retryDelay?: number;
}

export interface MarketDataOptions {
  timeStart?: string;
  timeEnd?: string;
  limit?: number;
  periodId?: string;
}

export interface ExchangeRateOptions {
  filterAssets?: string[];
  invert?: boolean;
  time?: string;
}

export interface SymbolOptions {
  filterSymbolId?: string;
  filterAssetId?: string;
}

// WebSocket types
export interface WebSocketMessage {
  type: string;
  symbol_id?: string;
  time_exchange?: string;
  time_coinapi?: string;
  sequence?: number;
}

export interface WebSocketTradeMessage extends WebSocketMessage {
  type: 'trade';
  uuid: string;
  price: number;
  size: number;
  taker_side: 'BUY' | 'SELL';
}

export interface WebSocketQuoteMessage extends WebSocketMessage {
  type: 'quote';
  ask_price?: number;
  ask_size?: number;
  bid_price?: number;
  bid_size?: number;
}

export interface WebSocketOrderBookMessage extends WebSocketMessage {
  type: 'book5' | 'book20' | 'book50';
  asks: OrderBookLevel[];
  bids: OrderBookLevel[];
}

export interface WebSocketOHLCVMessage extends WebSocketMessage {
  type: 'ohlcv';
  period_id: string;
  time_period_start: string;
  time_period_end: string;
  price_open: number;
  price_high: number;
  price_low: number;
  price_close: number;
  volume_traded: number;
  trades_count: number;
}

export interface WebSocketSubscription {
  unsubscribe: () => void;
}

export interface ConnectionStatus {
  isConnected: boolean;
  readyState?: number;
  subscriptions: string[];
}

// Callback types
export type WebSocketCallback<T = WebSocketMessage> = (message: T) => void;
export type ConnectionCallback = () => void;
export type ErrorCallback = (error: Error) => void;
export type DisconnectCallback = (event: CloseEvent) => void;

// Period types
export type Period = 
  | '1SEC' | '2SEC' | '3SEC' | '4SEC' | '5SEC' | '6SEC' | '10SEC' | '15SEC' | '20SEC' | '30SEC'
  | '1MIN' | '2MIN' | '3MIN' | '4MIN' | '5MIN' | '6MIN' | '10MIN' | '15MIN' | '20MIN' | '30MIN'
  | '1HRS' | '2HRS' | '3HRS' | '4HRS' | '6HRS' | '8HRS' | '12HRS'
  | '1DAY' | '2DAY' | '3DAY' | '5DAY' | '7DAY' | '10DAY'
  | '1MTH' | '2MTH' | '3MTH' | '4MTH' | '6MTH'
  | '1YRS' | '2YRS' | '3YRS' | '4YRS' | '5YRS';

// Class types
export declare class CoinAPIAuth {
  constructor(apiKey?: string);
  getHeaders(additionalHeaders?: Record<string, string>): Record<string, string>;
  getBaseURL(): string;
  validateApiKey(): boolean;
  testConnection(): Promise<boolean>;
}

export declare class MarketData {
  constructor(apiKey?: string);
  
  // Exchange Rates
  getAllExchangeRates(baseAsset: string, options?: ExchangeRateOptions): Promise<ExchangeRateResponse>;
  getExchangeRate(baseAsset: string, quoteAsset: string, time?: string): Promise<ExchangeRate>;
  getExchangeRateHistory(baseAsset: string, quoteAsset: string, options?: MarketDataOptions): Promise<ExchangeRate[]>;
  
  // OHLCV
  getOHLCV(symbolId: string, options?: MarketDataOptions): Promise<OHLCV[]>;
  getLatestOHLCV(symbolId: string, periodId?: Period, limit?: number): Promise<OHLCV[]>;
  getOHLCVPeriods(): Promise<Period[]>;
  
  // Trades
  getTrades(symbolId: string, options?: MarketDataOptions): Promise<Trade[]>;
  getLatestTrades(symbolId: string, limit?: number): Promise<Trade[]>;
  getAllLatestTrades(limit?: number): Promise<Trade[]>;
  
  // Quotes
  getCurrentQuotes(symbolId: string): Promise<Quote[]>;
  getQuotes(symbolId: string, options?: MarketDataOptions): Promise<Quote[]>;
  getLatestQuotes(symbolId: string, limit?: number): Promise<Quote[]>;
  
  // Order Book
  getOrderBook(symbolId: string, limit?: number): Promise<OrderBook>;
  getOrderBookHistory(symbolId: string, options?: MarketDataOptions): Promise<OrderBook[]>;
  
  // Metadata
  getExchanges(): Promise<Exchange[]>;
  getExchange(exchangeId: string): Promise<Exchange>;
  getAssets(): Promise<Asset[]>;
  getAsset(assetId: string): Promise<Asset>;
  getSymbols(exchangeId?: string): Promise<Symbol[]>;
  getExchangeSymbols(exchangeId: string, options?: SymbolOptions): Promise<Symbol[]>;
  
  // Utilities
  testConnection(): Promise<boolean>;
  getStatus(): Promise<Exchange[]>;
}

export declare class WebSocketClient {
  constructor(apiKey?: string);
  
  connect(endpoint?: string): Promise<void>;
  disconnect(): void;
  
  // Subscriptions
  subscribeTrades(symbolIds: string | string[], callback: WebSocketCallback<WebSocketTradeMessage>): WebSocketSubscription;
  subscribeQuotes(symbolIds: string | string[], callback: WebSocketCallback<WebSocketQuoteMessage>): WebSocketSubscription;
  subscribeOrderBook(symbolIds: string | string[], callback: WebSocketCallback<WebSocketOrderBookMessage>, depth?: 5 | 20 | 50): WebSocketSubscription;
  subscribeOHLCV(symbolIds: string | string[], callback: WebSocketCallback<WebSocketOHLCVMessage>): WebSocketSubscription;
  
  // Event handlers
  onConnect(callback: ConnectionCallback): void;
  onDisconnect(callback: DisconnectCallback): void;
  onError(callback: ErrorCallback): void;
  onMessage(callback: WebSocketCallback): void;
  
  // Status
  getConnectionStatus(): ConnectionStatus;
}