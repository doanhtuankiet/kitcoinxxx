import MarketData from './modules/marketData.js';
import WebSocketClient from './modules/websocket.js';
import CoinAPIAuth from './modules/auth.js';
import * as utils from './utils/index.js';

// Re-export all modules
export {
  MarketData,
  WebSocketClient,
  CoinAPIAuth,
  utils
};

// Export types for TypeScript projects
export * from './types/index.ts';

// Default export for convenience
export default {
  MarketData,
  WebSocketClient,
  CoinAPIAuth,
  utils
};