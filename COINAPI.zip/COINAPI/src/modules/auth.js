import 'dotenv/config';

/**
 * Authentication and configuration module for CoinAPI
 */
class CoinAPIAuth {
  constructor(apiKey = null) {
    this.apiKey = apiKey || process.env.COINAPI_KEY;
    this.baseURL = process.env.COINAPI_BASE_URL || 'https://rest.coinapi.io';
    
    if (!this.apiKey) {
      throw new Error('CoinAPI key is required. Set COINAPI_KEY environment variable or pass apiKey parameter.');
    }
  }

  /**
   * Get standard headers for REST API requests
   */
  getHeaders(additionalHeaders = {}) {
    return {
      'X-CoinAPI-Key': this.apiKey,
      'Accept': 'application/json',
      'Accept-Encoding': 'br, gzip',
      ...additionalHeaders
    };
  }

  /**
   * Get base URL for API requests
   */
  getBaseURL() {
    return this.baseURL;
  }

  /**
   * Validate API key format
   */
  validateApiKey() {
    if (!this.apiKey || this.apiKey.length < 30) {
      throw new Error('Invalid CoinAPI key format');
    }
    return true;
  }

  /**
   * Test API key validity by making a simple request
   */
  async testConnection() {
    try {
      const response = await fetch(`${this.baseURL}/v1/exchanges`, {
        headers: this.getHeaders()
      });
      
      if (response.status === 401) {
        throw new Error('Invalid API key');
      }
      
      return response.ok;
    } catch (error) {
      throw new Error(`API connection test failed: ${error.message}`);
    }
  }
}

export default CoinAPIAuth;