import CoinAPIAuth from './auth.js';

/**
 * Market Data REST API module for CoinAPI
 * Provides methods for exchange rates, OHLCV, trades, quotes, and metadata
 */
class MarketData {
  constructor(apiKey = null) {
    this.auth = new CoinAPIAuth(apiKey);
    this.baseURL = this.auth.getBaseURL();
  }

  /**
   * Make HTTP request with error handling and retries
   */
  async makeRequest(endpoint, options = {}) {
    const { retries = 3, retryDelay = 1000 } = options;
    
    for (let i = 0; i < retries; i++) {
      try {
        const response = await fetch(`${this.baseURL}${endpoint}`, {
          headers: this.auth.getHeaders(),
          ...options
        });

        if (response.status === 429) {
          // Rate limit - exponential backoff
          const delay = Math.pow(2, i) * retryDelay;
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        return await response.json();

      } catch (error) {
        if (i === retries - 1) throw error;
        await new Promise(resolve => setTimeout(resolve, retryDelay));
      }
    }
  }

  // =====================
  // EXCHANGE RATES
  // =====================

  /**
   * Get all current exchange rates for a base asset
   */
  async getAllExchangeRates(baseAsset, options = {}) {
    const { filterAssets, invert, time } = options;
    let endpoint = `/v1/exchangerate/${baseAsset}`;
    
    const params = new URLSearchParams();
    if (filterAssets) params.append('filter_asset_id', filterAssets.join(','));
    if (invert) params.append('invert', invert);
    if (time) params.append('time', time);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get specific exchange rate between two assets
   */
  async getExchangeRate(baseAsset, quoteAsset, time = null) {
    let endpoint = `/v1/exchangerate/${baseAsset}/${quoteAsset}`;
    if (time) endpoint += `/${time}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get exchange rate timeseries data
   */
  async getExchangeRateHistory(baseAsset, quoteAsset, options = {}) {
    const { periodId, timeStart, timeEnd, limit } = options;
    let endpoint = `/v1/exchangerate/${baseAsset}/${quoteAsset}/history`;
    
    const params = new URLSearchParams();
    if (periodId) params.append('period_id', periodId);
    if (timeStart) params.append('time_start', timeStart);
    if (timeEnd) params.append('time_end', timeEnd);
    if (limit) params.append('limit', limit);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  // =====================
  // OHLCV DATA
  // =====================

  /**
   * Get historical OHLCV data for a symbol
   */
  async getOHLCV(symbolId, options = {}) {
    const { periodId, timeStart, timeEnd, limit } = options;
    let endpoint = `/v1/ohlcv/${symbolId}/history`;
    
    const params = new URLSearchParams();
    if (periodId) params.append('period_id', periodId);
    if (timeStart) params.append('time_start', timeStart);
    if (timeEnd) params.append('time_end', timeEnd);
    if (limit) params.append('limit', limit);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get latest OHLCV data for a symbol
   */
  async getLatestOHLCV(symbolId, periodId = '1DAY', limit = 100) {
    const params = new URLSearchParams();
    params.append('period_id', periodId);
    params.append('limit', limit);
    
    return this.makeRequest(`/v1/ohlcv/${symbolId}/latest?${params.toString()}`);
  }

  /**
   * Get available OHLCV periods
   */
  async getOHLCVPeriods() {
    return this.makeRequest('/v1/ohlcv/periods');
  }

  // =====================
  // TRADES
  // =====================

  /**
   * Get historical trades for a symbol
   */
  async getTrades(symbolId, options = {}) {
    const { timeStart, timeEnd, limit } = options;
    let endpoint = `/v1/trades/${symbolId}/history`;
    
    const params = new URLSearchParams();
    if (timeStart) params.append('time_start', timeStart);
    if (timeEnd) params.append('time_end', timeEnd);
    if (limit) params.append('limit', limit);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get latest trades for a symbol
   */
  async getLatestTrades(symbolId, limit = 100) {
    return this.makeRequest(`/v1/trades/${symbolId}/latest?limit=${limit}`);
  }

  /**
   * Get all latest trades
   */
  async getAllLatestTrades(limit = 100) {
    return this.makeRequest(`/v1/trades/latest?limit=${limit}`);
  }

  // =====================
  // QUOTES
  // =====================

  /**
   * Get current quotes for a symbol
   */
  async getCurrentQuotes(symbolId) {
    return this.makeRequest(`/v1/quotes/${symbolId}/current`);
  }

  /**
   * Get historical quotes for a symbol
   */
  async getQuotes(symbolId, options = {}) {
    const { timeStart, timeEnd, limit } = options;
    let endpoint = `/v1/quotes/${symbolId}/history`;
    
    const params = new URLSearchParams();
    if (timeStart) params.append('time_start', timeStart);
    if (timeEnd) params.append('time_end', timeEnd);
    if (limit) params.append('limit', limit);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get latest quotes for a symbol
   */
  async getLatestQuotes(symbolId, limit = 100) {
    return this.makeRequest(`/v1/quotes/${symbolId}/latest?limit=${limit}`);
  }

  // =====================
  // ORDER BOOK
  // =====================

  /**
   * Get current order book for a symbol
   */
  async getOrderBook(symbolId, limit = null) {
    let endpoint = `/v1/orderbooks/${symbolId}/current`;
    if (limit) endpoint += `?limit=${limit}`;
    
    return this.makeRequest(endpoint);
  }

  /**
   * Get historical order book snapshots
   */
  async getOrderBookHistory(symbolId, options = {}) {
    const { timeStart, timeEnd, limit } = options;
    let endpoint = `/v1/orderbooks/${symbolId}/history`;
    
    const params = new URLSearchParams();
    if (timeStart) params.append('time_start', timeStart);
    if (timeEnd) params.append('time_end', timeEnd);
    if (limit) params.append('limit', limit);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  // =====================
  // METADATA
  // =====================

  /**
   * Get all exchanges
   */
  async getExchanges() {
    return this.makeRequest('/v1/exchanges');
  }

  /**
   * Get exchange by ID
   */
  async getExchange(exchangeId) {
    return this.makeRequest(`/v1/exchanges/${exchangeId}`);
  }

  /**
   * Get all assets
   */
  async getAssets() {
    return this.makeRequest('/v1/assets');
  }

  /**
   * Get asset by ID
   */
  async getAsset(assetId) {
    return this.makeRequest(`/v1/assets/${assetId}`);
  }

  /**
   * Get all symbols
   */
  async getSymbols(exchangeId = null) {
    if (exchangeId) {
      return this.makeRequest(`/v1/symbols/${exchangeId}`);
    }
    return this.makeRequest('/v1/symbols');
  }

  /**
   * Get symbols by exchange ID
   */
  async getExchangeSymbols(exchangeId, options = {}) {
    const { filterSymbolId, filterAssetId } = options;
    let endpoint = `/v1/symbols/${exchangeId}`;
    
    const params = new URLSearchParams();
    if (filterSymbolId) params.append('filter_symbol_id', filterSymbolId);
    if (filterAssetId) params.append('filter_asset_id', filterAssetId);
    
    if (params.toString()) endpoint += `?${params.toString()}`;
    
    return this.makeRequest(endpoint);
  }

  // =====================
  // UTILITY METHODS
  // =====================

  /**
   * Test API connection
   */
  async testConnection() {
    return this.auth.testConnection();
  }

  /**
   * Get API usage/status info
   */
  async getStatus() {
    return this.makeRequest('/v1/exchanges');
  }
}

export default MarketData;