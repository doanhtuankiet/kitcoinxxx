import CoinAPIAuth from './auth.js';

/**
 * WebSocket API module for real-time CoinAPI data
 * Supports trade, quote, order book, and OHLCV subscriptions
 */
class WebSocketClient {
  constructor(apiKey = null) {
    this.auth = new CoinAPIAuth(apiKey);
    this.ws = null;
    this.isConnected = false;
    this.subscriptions = new Map();
    this.reconnectDelay = 1000;
    this.maxReconnectDelay = 30000;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.heartbeatInterval = null;
    this.callbacks = {
      onConnect: null,
      onDisconnect: null,
      onError: null,
      onMessage: null
    };
  }

  /**
   * Connect to WebSocket endpoint
   */
  connect(endpoint = 'wss://ws.coinapi.io/v1/') {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(endpoint);
        
        this.ws.onopen = () => {
          this.isConnected = true;
          this.reconnectAttempts = 0;
          this.reconnectDelay = 1000;
          this.authenticate();
          this.startHeartbeat();
          
          if (this.callbacks.onConnect) {
            this.callbacks.onConnect();
          }
          
          resolve();
        };

        this.ws.onmessage = (event) => {
          this.handleMessage(JSON.parse(event.data));
        };

        this.ws.onclose = (event) => {
          this.isConnected = false;
          this.stopHeartbeat();
          
          if (this.callbacks.onDisconnect) {
            this.callbacks.onDisconnect(event);
          }
          
          if (!event.wasClean && this.reconnectAttempts < this.maxReconnectAttempts) {
            this.scheduleReconnect(endpoint);
          }
        };

        this.ws.onerror = (error) => {
          if (this.callbacks.onError) {
            this.callbacks.onError(error);
          }
          reject(error);
        };

      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * Authenticate with the WebSocket server
   */
  authenticate() {
    const authMessage = {
      type: 'hello',
      apikey: this.auth.apiKey,
      heartbeat: false,
      subscribe_data_type: [],
      subscribe_filter_symbol_id: []
    };
    
    this.send(authMessage);
  }

  /**
   * Send message to WebSocket server
   */
  send(message) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      throw new Error('WebSocket is not connected');
    }
  }

  /**
   * Handle incoming messages
   */
  handleMessage(message) {
    switch (message.type) {
      case 'ping':
        this.send({ type: 'pong' });
        break;
        
      case 'trade':
        this.handleDataMessage('trade', message);
        break;
        
      case 'quote':
        this.handleDataMessage('quote', message);
        break;
        
      case 'book5':
      case 'book20':
      case 'book50':
        this.handleDataMessage('orderbook', message);
        break;
        
      case 'ohlcv':
        this.handleDataMessage('ohlcv', message);
        break;
        
      default:
        if (this.callbacks.onMessage) {
          this.callbacks.onMessage(message);
        }
    }
  }

  /**
   * Handle data messages and execute callbacks
   */
  handleDataMessage(type, data) {
    const symbolId = data.symbol_id;
    const key = `${type}:${symbolId}`;
    
    if (this.subscriptions.has(key)) {
      const callback = this.subscriptions.get(key);
      callback(data);
    }
  }

  /**
   * Subscribe to trade data for specific symbols
   */
  subscribeTrades(symbolIds, callback) {
    return this.subscribe('trade', symbolIds, callback);
  }

  /**
   * Subscribe to quote data for specific symbols
   */
  subscribeQuotes(symbolIds, callback) {
    return this.subscribe('quote', symbolIds, callback);
  }

  /**
   * Subscribe to order book data for specific symbols
   */
  subscribeOrderBook(symbolIds, callback, depth = 5) {
    const dataType = `book${depth}`;
    return this.subscribe(dataType, symbolIds, callback);
  }

  /**
   * Subscribe to OHLCV data for specific symbols
   */
  subscribeOHLCV(symbolIds, callback) {
    return this.subscribe('ohlcv', symbolIds, callback);
  }

  /**
   * Generic subscribe method
   */
  subscribe(dataType, symbolIds, callback) {
    const symbols = Array.isArray(symbolIds) ? symbolIds : [symbolIds];
    
    // Store callbacks for each symbol
    symbols.forEach(symbolId => {
      const key = `${dataType}:${symbolId}`;
      this.subscriptions.set(key, callback);
    });

    // Send subscription message
    const subscribeMessage = {
      type: 'hello',
      apikey: this.auth.apiKey,
      heartbeat: false,
      subscribe_data_type: [dataType],
      subscribe_filter_symbol_id: symbols
    };

    this.send(subscribeMessage);
    
    return {
      unsubscribe: () => this.unsubscribe(dataType, symbols)
    };
  }

  /**
   * Unsubscribe from data type and symbols
   */
  unsubscribe(dataType, symbolIds) {
    const symbols = Array.isArray(symbolIds) ? symbolIds : [symbolIds];
    
    symbols.forEach(symbolId => {
      const key = `${dataType}:${symbolId}`;
      this.subscriptions.delete(key);
    });

    // Send unsubscribe message
    const unsubscribeMessage = {
      type: 'hello',
      apikey: this.auth.apiKey,
      heartbeat: false,
      subscribe_data_type: [],
      subscribe_filter_symbol_id: symbols
    };

    this.send(unsubscribeMessage);
  }

  /**
   * Start heartbeat to keep connection alive
   */
  startHeartbeat() {
    this.heartbeatInterval = setInterval(() => {
      if (this.isConnected) {
        this.send({ type: 'ping' });
      }
    }, 30000); // Send ping every 30 seconds
  }

  /**
   * Stop heartbeat
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  /**
   * Schedule reconnection with exponential backoff
   */
  scheduleReconnect(endpoint) {
    this.reconnectAttempts++;
    const delay = Math.min(
      this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1),
      this.maxReconnectDelay
    );
    
    setTimeout(() => {
      if (!this.isConnected) {
        this.connect(endpoint).catch(() => {
          // Reconnection failed, will be retried if attempts < max
        });
      }
    }, delay);
  }

  /**
   * Set callback functions
   */
  onConnect(callback) {
    this.callbacks.onConnect = callback;
  }

  onDisconnect(callback) {
    this.callbacks.onDisconnect = callback;
  }

  onError(callback) {
    this.callbacks.onError = callback;
  }

  onMessage(callback) {
    this.callbacks.onMessage = callback;
  }

  /**
   * Disconnect from WebSocket
   */
  disconnect() {
    this.stopHeartbeat();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
    this.subscriptions.clear();
  }

  /**
   * Get connection status
   */
  getConnectionStatus() {
    return {
      isConnected: this.isConnected,
      readyState: this.ws?.readyState,
      subscriptions: Array.from(this.subscriptions.keys())
    };
  }
}

export default WebSocketClient;