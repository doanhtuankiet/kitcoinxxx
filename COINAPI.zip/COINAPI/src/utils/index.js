/**
 * Utility functions for CoinAPI modules
 */

/**
 * Sleep for specified milliseconds
 */
export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Format timestamp to ISO string
 */
export const formatTimestamp = (date) => {
  if (typeof date === 'string') return date;
  if (typeof date === 'number') return new Date(date).toISOString();
  if (date instanceof Date) return date.toISOString();
  return new Date().toISOString();
};

/**
 * Validate symbol ID format
 */
export const validateSymbolId = (symbolId) => {
  const pattern = /^[A-Z0-9]+_(SPOT|FTS|PERP|OPTION)_[A-Z0-9]+_[A-Z0-9]+/;
  return pattern.test(symbolId);
};

/**
 * Validate asset ID format
 */
export const validateAssetId = (assetId) => {
  const pattern = /^[A-Z0-9]+$/;
  return pattern.test(assetId);
};

/**
 * Validate exchange ID format
 */
export const validateExchangeId = (exchangeId) => {
  const pattern = /^[A-Z0-9]+$/;
  return pattern.test(exchangeId);
};

/**
 * Parse symbol ID to get components
 */
export const parseSymbolId = (symbolId) => {
  const parts = symbolId.split('_');
  if (parts.length < 4) {
    throw new Error('Invalid symbol ID format');
  }
  
  return {
    exchange: parts[0],
    type: parts[1],
    base: parts[2],
    quote: parts[3],
    extra: parts.slice(4).join('_') // For futures dates, option strikes, etc.
  };
};

/**
 * Build symbol ID from components
 */
export const buildSymbolId = (exchange, type, base, quote, extra = '') => {
  let symbolId = `${exchange}_${type}_${base}_${quote}`;
  if (extra) {
    symbolId += `_${extra}`;
  }
  return symbolId;
};

/**
 * Calculate percentage change
 */
export const calculatePercentChange = (oldValue, newValue) => {
  if (oldValue === 0) return 0;
  return ((newValue - oldValue) / oldValue) * 100;
};

/**
 * Round to specified decimal places
 */
export const roundToDecimals = (number, decimals) => {
  return Math.round(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
};

/**
 * Format currency value
 */
export const formatCurrency = (value, decimals = 2, symbol = '$') => {
  return `${symbol}${roundToDecimals(value, decimals).toLocaleString()}`;
};

/**
 * Format volume with K/M/B suffixes
 */
export const formatVolume = (volume) => {
  if (volume >= 1e9) return `${(volume / 1e9).toFixed(2)}B`;
  if (volume >= 1e6) return `${(volume / 1e6).toFixed(2)}M`;
  if (volume >= 1e3) return `${(volume / 1e3).toFixed(2)}K`;
  return volume.toFixed(2);
};

/**
 * Get time ago string
 */
export const getTimeAgo = (timestamp) => {
  const now = new Date();
  const time = new Date(timestamp);
  const diffMs = now - time;
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSeconds < 60) return `${diffSeconds}s ago`;
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
};

/**
 * Debounce function calls
 */
export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

/**
 * Throttle function calls
 */
export const throttle = (func, limit) => {
  let inThrottle;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
};

/**
 * Retry async function with exponential backoff
 */
export const retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1000) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      
      const delay = baseDelay * Math.pow(2, i);
      await sleep(delay);
    }
  }
};

/**
 * Create rate limiter
 */
export const createRateLimiter = (requestsPerSecond) => {
  const requests = [];
  const interval = 1000 / requestsPerSecond;
  
  return async () => {
    const now = Date.now();
    const validRequests = requests.filter(time => now - time < 1000);
    
    if (validRequests.length >= requestsPerSecond) {
      const oldestRequest = Math.min(...validRequests);
      const waitTime = 1000 - (now - oldestRequest) + 1;
      await sleep(waitTime);
    }
    
    requests.push(now);
    
    // Keep array size manageable
    if (requests.length > requestsPerSecond * 2) {
      requests.splice(0, requestsPerSecond);
    }
  };
};