# CoinAPI Knowledge Base

## Project Context
- **Purpose**: Modular CoinAPI integration library
- **Location**: E:\VSCODE\COINAPI
- **Usage**: Reusable module for other trading/crypto projects

## Architecture
- Modular design for easy integration
- Separate modules for different API endpoints
- Type definitions for better development experience
- Examples and tests for documentation

## Integration Notes
- Can be linked to other projects via npm link
- Import specific modules as needed
- Designed for volume-spike-bot and future projects

## Current Status
- Structure created
- Ready for CoinAPI knowledge building

## CoinAPI Documentation Knowledge

### API Overview & Architecture

**CoinAPI Market Data API** provides comprehensive cryptocurrency market data through multiple interface types optimized for different use cases and performance requirements.

#### Core API Interfaces

**1. RESTful API**
- **Purpose**: Live and historical data access with widest data coverage
- **Architecture**: HTTP-based stateless request-response model  
- **Protocol Support**: HTTP 1.0, 1.1, 2.0 with OpenAPI v3 specification
- **Best For**: Non-real-time operations, historical analysis, general integration
- **Limitation**: Not capable of streaming data

**2. WebSocket V1** 
- **Purpose**: Real-time live data streaming with persistent connections
- **Architecture**: Publish-subscribe model supporting multiple data sources
- **Best For**: Real-time market data, trading bots, portfolio tracking

**3. WebSocket DS (Data Stream)**
- **Purpose**: Direct connections to exchange data sources
- **Architecture**: Optimized streaming with reduced latency and improved reliability
- **Best For**: High-frequency trading and ultra-low latency applications

**4. FIX API**
- **Purpose**: Professional trading protocol widely adopted in finance industry
- **Architecture**: Stateful publish-subscribe model with tag-value messaging
- **Best For**: Institutional trading platforms and professional market access

#### Technical Standards
- **Variable Naming**: Snake_case convention (`asset_id`, `time_exchange`)
- **Currency Codes**: ISO 4217 compliance for fiat currencies  
- **Time Format**: ISO 8601 standard for all timestamps
- **Precision**: Maximum 19 digits (9 decimal places)
- **Security**: Optional encryption with trusted certificate authority

#### Global Infrastructure
- **Base URL**: `https://rest.coinapi.io/`
- **GeoDNS Auto-routing**: Automatic routing to nearest datacenter
- **Regional Endpoints**: Americas, EMEA, APAC specific endpoints
- **SDK Support**: Official libraries for Python, Java, JavaScript, C#, and more

#### Authentication & Response Formats
- **Authentication**: API key via `X-CoinAPI-Key` header
- **Response Format**: JSON (default), CSV/XML optional
- **Rate Limits**: Varies by plan
- **Compression**: Use `Accept-Encoding: br, gzip` (80% bandwidth reduction)

#### Error Handling
- **Success**: HTTP 200 with JSON response
- **Client Errors**: 400 (Bad Request), 401 (Unauthorized), 403 (Forbidden)
- **Rate Limiting**: 429 (Rate Limit Exceeded)  
- **Data Availability**: 550 (No Data Available)

#### Integration Options
- **Direct CSV/JSON Import**: Excel, Google Sheets compatibility
- **PowerQuery Support**: Web service function integration
- **Platform Independence**: Cross-platform data retrieval methods

### REST API Introduction

**REST API** serves as the primary interface for accessing CoinAPI's comprehensive cryptocurrency market data through standard HTTP protocols.

#### Core REST API Features
- **Stateless Architecture**: Each request contains complete information required for processing
- **Standard HTTP Methods**: Primarily GET requests for data retrieval
- **JSON Response Format**: Default structured data format with optional CSV/XML
- **Global Infrastructure**: GeoDNS auto-routing to nearest datacenter
- **Multi-Protocol Support**: HTTP 1.0, 1.1, 2.0 compatibility

#### Base URLs & Regional Endpoints
- **Global (GeoDNS)**: `https://rest.coinapi.io/` - Automatically routes to nearest datacenter
- **Americas**: `https://api-ncsa.coinapi.io/` - North/South America optimization
- **EMEA**: `https://api-emea.coinapi.io/` - Europe, Middle East, Africa
- **APAC**: `https://api-apac.coinapi.io/` - Asia Pacific region

#### Authentication Requirements
Every REST API request must include:
```javascript
headers: {
  'Accept': 'application/json',
  'X-CoinAPI-Key': 'YOUR_API_KEY'
}
```

#### Performance Optimization Headers
```javascript
headers: {
  'Accept': 'application/json',
  'Accept-Encoding': 'br, gzip', // 80% bandwidth reduction
  'X-CoinAPI-Key': 'YOUR_API_KEY'
}
```

#### Response Formats
- **JSON** (default): Structured data for programmatic access
- **CSV**: Direct spreadsheet integration with `?format=csv`
- **XML**: Alternative structured format for legacy systems

#### Excel/Google Sheets Integration
Direct data import using native functions:
```excel
=IMPORTDATA("https://rest.coinapi.io/v1/exchangerate/BTC/USD?apikey=YOUR_KEY&format=csv")
```

#### Error Response Structure
```json
{
  "error": "Invalid API key",
  "code": 401,
  "message": "API key is missing or invalid"
}
```

#### Rate Limiting
- **Free Tier**: Limited requests per day/month
- **Paid Plans**: Higher rate limits based on subscription
- **Rate Limit Headers**: Response includes remaining quota information
- **429 Status**: Rate limit exceeded, implement exponential backoff

#### OpenAPI v3 Specification
- **Complete API Documentation**: Structured OpenAPI specification available
- **Postman Integration**: Import API collection directly from specification
- **Code Generation**: Generate client libraries for various programming languages

### API Interfaces
1. **RESTful API** - Live/historical data, request-response
2. **WebSocket V1** - Real-time streaming, pub-sub model
3. **WebSocket DS** - Direct data source connections
4. **FIX API** - Industry-standard financial protocol

### CoinAPI Authentication Framework

**CoinAPI** supports multiple authentication methods to accommodate different integration scenarios and security requirements.

#### Primary Authentication Methods

##### 1. API Key Header (Recommended)
```javascript
headers: {
  'Accept': 'application/json',
  'X-CoinAPI-Key': 'YOUR_API_KEY'
}
```
**Best For**: Production applications, secure server-to-server communication

##### 2. Query String Parameter
```bash
https://rest.coinapi.io/v1/exchangerate/BTC/USD?apikey=YOUR_API_KEY
```
**Best For**: Development, testing, direct browser access

##### 3. URL Path Authentication
```bash
https://rest.coinapi.io/v1/YOUR_API_KEY/exchangerate/BTC/USD
```
**Best For**: Simple integrations, URL-based access patterns

##### 4. Authorization Header
```javascript
headers: {
  'Authorization': 'Bearer YOUR_API_KEY'
}
```
**Best For**: OAuth-compatible systems, standard bearer token patterns

##### 5. Basic Authentication
```javascript
headers: {
  'Authorization': 'Basic ' + btoa('apikey:YOUR_API_KEY')
}
```
**Best For**: Legacy systems requiring HTTP Basic Auth

#### Advanced Authentication: JWT Tokens

**JSON Web Token (JWT)** authentication provides enhanced security for professional applications.

##### JWT Configuration
```javascript
// JWT Token Generation
const jwt = require('jsonwebtoken');
const token = jwt.sign({
  sub: 'your-subject-id',
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + (60 * 60) // 1 hour
}, privateKey, {
  algorithm: 'RS256' // or PS256, ES256
});

// JWT Usage
headers: {
  'Authorization': `Bearer ${token}`,
  'Accept': 'application/json'
}
```

##### Supported JWT Algorithms
- **RS256**: RSA Signature with SHA-256
- **PS256**: RSA PSS with SHA-256
- **ES256**: ECDSA using P-256 and SHA-256
- **HS256**: HMAC with SHA-256

##### JWT Public Key Import
```javascript
// Import CoinAPI public key for token verification
const publicKey = `-----BEGIN PUBLIC KEY-----
// Your CoinAPI provided public key
-----END PUBLIC KEY-----`;
```

#### Protocol-Specific Authentication

##### FIX Protocol Authentication
```fix
SenderCompID=YOUR_API_KEY
TargetCompID=COINAPI_V2
```
**Use Case**: Professional trading applications using FIX 4.4 protocol

##### AWS Signature Authentication (Flat Files API)
```javascript
// AWS Signature Version 4
const credentials = {
  accessKeyId: 'YOUR_COINAPI_KEY',
  secretAccessKey: 'coinapi' // Fixed value
};
```
**Use Case**: S3-compatible flat files data access

#### Authentication Best Practices

##### Security Recommendations
1. **Environment Variables**: Store API keys in environment variables, never in source code
2. **HTTPS Only**: Always use encrypted connections (https://, wss://)
3. **Key Rotation**: Regularly rotate API keys for enhanced security
4. **Scope Limitation**: Use API keys with minimal required permissions
5. **Rate Monitoring**: Monitor API usage to detect unauthorized access

##### Error Handling
```javascript
// Handle authentication errors gracefully
switch (response.status) {
  case 401:
    throw new Error('Invalid or missing API key');
  case 403:
    throw new Error('API key lacks required permissions');
  case 429:
    throw new Error('Rate limit exceeded - implement backoff');
}
```

##### Implementation Examples
```python
# Python with requests library
import requests
import os

headers = {
    'Accept': 'application/json',
    'X-CoinAPI-Key': os.environ['COINAPI_KEY']
}
response = requests.get('https://rest.coinapi.io/v1/exchanges', headers=headers)
```

```javascript
// Node.js with fetch
const API_KEY = process.env.COINAPI_KEY;
const response = await fetch('https://rest.coinapi.io/v1/exchanges', {
  headers: {
    'Accept': 'application/json',
    'X-CoinAPI-Key': API_KEY
  }
});
```

#### Authentication Selection Guide

| Method | Security Level | Complexity | Use Case |
|--------|---------------|------------|----------|
| **API Key Header** | High | Low | Production REST APIs |
| **JWT Tokens** | Very High | High | Enterprise applications |
| **Query String** | Medium | Very Low | Development/testing |
| **FIX Protocol** | High | High | Professional trading |
| **AWS Signature** | High | Medium | Bulk data access |

### Authentication Headers
```javascript
headers: {
  'Accept': 'application/json',
  'X-CoinAPI-Key': 'YOUR_API_KEY'
}
```

### Programming Language SDK Support

**CoinAPI** provides comprehensive SDK support across multiple programming languages for seamless integration.

#### Officially Supported Languages

##### Web Development
- **JavaScript**: Browser and Node.js environments
- **TypeScript**: Type-safe development with enhanced IDE support
- **PHP**: Server-side web applications and WordPress plugins

##### Enterprise & Backend
- **Java**: Enterprise applications and Android development
- **C#/.NET**: Windows applications and web services
- **C++**: High-performance applications and trading systems
- **Python**: Data analysis, machine learning, and web services
- **Ruby**: Web applications and scripting
- **Go**: Microservices and high-performance backends

##### Data Analysis & Research
- **Python**: pandas, numpy integration for financial analysis
- **R**: Statistical analysis and financial modeling
- **MATLAB**: Mathematical computing and algorithm development

#### SDK Installation Examples

##### Python SDK
```bash
pip install coinapi-rest-v1
```
```python
import coinapi_rest_v1 as coinapi

api_key = 'YOUR_API_KEY'
client = coinapi.CoinAPIv1(api_key)

# Get exchange rates
rates = client.exchange_rates_get_all_current_rates('BTC')
print(rates)
```

##### JavaScript/Node.js SDK
```bash
npm install coinapi-sdk
```
```javascript
const CoinAPI = require('coinapi-sdk');
const client = CoinAPI(process.env.COINAPI_KEY);

// Get current exchange rate
client.exchangeRatesGetSpecificRate('BTC', 'USD')
  .then(data => console.log(data))
  .catch(error => console.error(error));
```

##### Java SDK
```xml
<dependency>
    <groupId>io.coinapi</groupId>
    <artifactId>coinapi-sdk</artifactId>
    <version>1.0.0</version>
</dependency>
```
```java
CoinAPIRestClient client = CoinAPIRestClient.newInstance("YOUR_API_KEY");
List<Exchange> exchanges = client.exchangesGet();
```

##### C#/.NET SDK
```bash
Install-Package CoinAPI.REST.V1
```
```csharp
var apikey = "YOUR_API_KEY";
var client = new CoinApiRestClient(apikey);
var exchanges = client.Metadata_list_all_exchanges();
```

#### Integration Patterns

##### RESTful API Integration
```python
# Standard HTTP requests approach
import requests

headers = {
    'Accept': 'application/json',
    'X-CoinAPI-Key': 'YOUR_API_KEY'
}

# Get all exchanges
response = requests.get(
    'https://rest.coinapi.io/v1/exchanges',
    headers=headers
)
exchanges = response.json()
```

##### WebSocket Integration
```javascript
// WebSocket real-time data
const WebSocket = require('ws');
const ws = new WebSocket('wss://ws.coinapi.io/v1/');

ws.on('open', function open() {
    // Send hello message with authentication
    ws.send(JSON.stringify({
        type: 'hello',
        apikey: 'YOUR_API_KEY',
        subscribe_data_type: ['trade'],
        subscribe_filter_symbol_id: ['BITSTAMP_SPOT_BTC_USD']
    }));
});

ws.on('message', function message(data) {
    const trade = JSON.parse(data);
    console.log('New trade:', trade);
});
```

#### Advanced SDK Features

##### Error Handling
```python
# Python SDK with comprehensive error handling
try:
    rates = client.exchange_rates_get_specific_rate('BTC', 'USD')
except coinapi.CoinAPIException as e:
    if e.status_code == 429:
        print("Rate limit exceeded - implement backoff")
    elif e.status_code == 401:
        print("Invalid API key")
    elif e.status_code == 550:
        print("No data available")
    else:
        print(f"API error: {e}")
```

##### Async/Await Support
```javascript
// JavaScript async/await pattern
async function fetchMarketData() {
    try {
        const btcRate = await client.exchangeRatesGetSpecificRate('BTC', 'USD');
        const ethRate = await client.exchangeRatesGetSpecificRate('ETH', 'USD');
        
        return {
            bitcoin: btcRate.rate,
            ethereum: ethRate.rate
        };
    } catch (error) {
        console.error('Market data fetch failed:', error);
        throw error;
    }
}
```

##### Configuration Management
```java
// Java SDK configuration
CoinAPIRestClient client = CoinAPIRestClient.builder()
    .apiKey("YOUR_API_KEY")
    .timeout(30000) // 30 seconds
    .retryPolicy(RetryPolicy.exponentialBackoff(3))
    .build();
```

#### Framework Integrations

##### React/Vue.js Components
```jsx
// React hook for CoinAPI integration
import { useState, useEffect } from 'react';

function useCoinAPIRate(base, quote) {
    const [rate, setRate] = useState(null);
    const [loading, setLoading] = useState(true);
    
    useEffect(() => {
        fetch(`https://rest.coinapi.io/v1/exchangerate/${base}/${quote}`, {
            headers: {
                'X-CoinAPI-Key': process.env.REACT_APP_COINAPI_KEY
            }
        })
        .then(res => res.json())
        .then(data => {
            setRate(data.rate);
            setLoading(false);
        });
    }, [base, quote]);
    
    return { rate, loading };
}
```

##### Django/Flask Integration
```python
# Django model integration
from django.db import models
import coinapi_rest_v1 as coinapi

class CryptoPrice(models.Model):
    symbol = models.CharField(max_length=10)
    price_usd = models.DecimalField(max_digits=20, decimal_places=8)
    updated_at = models.DateTimeField(auto_now=True)
    
    @classmethod
    def update_prices(cls):
        client = coinapi.CoinAPIv1(settings.COINAPI_KEY)
        rates = client.exchange_rates_get_all_current_rates('USD')
        
        for rate in rates:
            cls.objects.update_or_create(
                symbol=rate['asset_id_quote'],
                defaults={'price_usd': rate['rate']}
            )
```

#### Mobile Development

##### React Native
```javascript
// React Native implementation
import CoinAPI from 'coinapi-sdk';

const client = CoinAPI('YOUR_API_KEY');

export const fetchCryptoPortfolio = async (assets) => {
    const rates = await Promise.all(
        assets.map(asset => 
            client.exchangeRatesGetSpecificRate(asset, 'USD')
        )
    );
    
    return rates.map((rate, index) => ({
        asset: assets[index],
        price: rate.rate,
        timestamp: rate.time
    }));
};
```

##### Android (Java/Kotlin)
```kotlin
// Kotlin Android implementation
class CoinAPIService {
    private val client = OkHttpClient()
    private val apiKey = "YOUR_API_KEY"
    
    suspend fun getExchangeRate(base: String, quote: String): ExchangeRate {
        val request = Request.Builder()
            .url("https://rest.coinapi.io/v1/exchangerate/$base/$quote")
            .addHeader("X-CoinAPI-Key", apiKey)
            .build()
        
        return withContext(Dispatchers.IO) {
            val response = client.newCall(request).execute()
            gson.fromJson(response.body?.string(), ExchangeRate::class.java)
        }
    }
}
```

#### Testing & Development

##### Unit Testing Examples
```python
# Python unittest for CoinAPI integration
import unittest
from unittest.mock import patch, Mock
import coinapi_rest_v1 as coinapi

class TestCoinAPIIntegration(unittest.TestCase):
    def setUp(self):
        self.client = coinapi.CoinAPIv1('test_api_key')
    
    @patch('coinapi_rest_v1.requests.get')
    def test_get_exchange_rate(self, mock_get):
        # Mock API response
        mock_response = Mock()
        mock_response.json.return_value = {
            'time': '2025-08-31T10:30:00.000Z',
            'asset_id_base': 'BTC',
            'asset_id_quote': 'USD',
            'rate': 43250.75
        }
        mock_get.return_value = mock_response
        
        rate = self.client.exchange_rates_get_specific_rate('BTC', 'USD')
        self.assertEqual(rate['rate'], 43250.75)
```

##### Integration Testing
```javascript
// Jest integration test
const CoinAPI = require('coinapi-sdk');

describe('CoinAPI Integration', () => {
    const client = CoinAPI(process.env.TEST_COINAPI_KEY);
    
    test('should fetch BTC/USD rate', async () => {
        const rate = await client.exchangeRatesGetSpecificRate('BTC', 'USD');
        
        expect(rate).toHaveProperty('time');
        expect(rate).toHaveProperty('asset_id_base', 'BTC');
        expect(rate).toHaveProperty('asset_id_quote', 'USD');
        expect(rate).toHaveProperty('rate');
        expect(typeof rate.rate).toBe('number');
    });
});
```

### HTTP Status Codes
- `200`: Success
- `400`: Bad Request
- `401`: Unauthorized
- `403`: Forbidden
- `429`: Rate Limit Exceeded
- `550`: No Data Available

---

## REST API Endpoints

### Exchange Rates
**Base Endpoint**: `/v1/exchangerate/`

#### Get All Current Rates
- **URL**: `GET /v1/exchangerate/:asset_id_base`
- **Parameters**:
  - `asset_id_base` (path, required): Base asset identifier
  - `filter_asset_id` (query, optional): Comma-separated asset IDs
  - `invert` (query, optional): Boolean to invert rates
  - `time` (query, optional): Historical timestamp
- **Response**:
```json
{
  "asset_id_base": "BTC",
  "rates": [
    {
      "time": "2017-08-09T14:31:37.0520000Z",
      "asset_id_quote": "USD",
      "rate": 3258.887541779804
    }
  ]
}
```

#### Get Specific Rate
- **URL**: `GET /v1/exchangerate/:base/:quote`
- **URL**: `GET /v1/exchangerate/:base/:quote/:time`

#### Timeseries Data
- **URL**: `GET /v1/exchangerate/:base/:quote/history`
- **Required Parameters**:
  - `asset_id_base` (string): Base asset identifier
  - `asset_id_quote` (string): Quote asset identifier  
  - `period_id` (string): Time period (5SEC, 1MIN, 1HRS, 1DAY, etc.)
  - `time_start` (string): ISO 8601 start time
  - `time_end` (string): ISO 8601 end time
- **Optional Parameters**:
  - `limit` (int32): Items to return (default 100, max 100,000)
- **Response Schema**:
  - `time_period_start/end`: Period boundaries
  - `time_open/close`: Opening/closing times (nullable)
  - `rate_open/high/low/close`: OHLC rates (nullable)
- **Formats**: JSON, CSV, XML, MessagePack

#### Timeseries Periods
- **URL**: `GET /v1/exchangerate/history/periods`
- **Purpose**: Get all supported time periods
- **Available Periods**:
  - **Seconds**: 1SEC, 2SEC, 3SEC, 4SEC, 5SEC, 6SEC, 10SEC, 15SEC, 20SEC, 30SEC
  - **Minutes**: 1MIN, 2MIN, 3MIN, 4MIN, 5MIN, 6MIN, 10MIN, 15MIN, 20MIN, 30MIN
  - **Hours**: 1HRS, 2HRS, 3HRS, 4HRS, 6HRS, 8HRS, 12HRS
  - **Days**: 1DAY, 2DAY, 3DAY, 5DAY, 7DAY, 10DAY
- **Response Fields**:
  - `period_id`: Unique identifier
  - `length_seconds`: Duration in seconds
  - `length_months`: Duration in months
  - `unit_count`: Number of time units
  - `unit_name`: Time unit name
  - `display_name`: Human-readable description

---

### Metadata Endpoints
**Base Endpoint**: `/v1/`

#### Symbols
- **All Active Symbols**: `GET /v1/symbols`
- **Exchange Symbols**: `GET /v1/symbols/:exchange_id`
- **Historical Symbols**: `GET /v1/symbols/:exchange_id/history`
- **Active Symbol Mapping**: `GET /v1/symbols/map/:exchange_id`
  - **Purpose**: List active symbol mapping for the exchange
  - **Required Parameter**: `exchange_id` (string) - Exchange ID from Metadata
  - **Response Fields**:
    - `symbol_id`: Exchange symbol identifier
    - `symbol_id_exchange`: Exchange-specific symbol ID
    - `asset_id_base`: Base asset ID
    - `asset_id_quote`: Quote asset ID
    - `price_precision`: Decimal price precision
    - `size_precision`: Decimal size precision
- **Historical Symbols for Exchange**: `GET /v1/symbols/:exchange_id/history`
  - **Purpose**: Retrieve historical symbols for a specific exchange
  - **Required Parameter**: `exchange_id` (string) - Exchange ID
  - **Optional Parameters**:
    - `page` (int32): Page number for pagination (default: 1)
    - `limit` (int32): Records per page (default: 100)
  - **Response**: Array of symbol objects with symbol_id, exchange_id, symbol_type, asset IDs, volumes, price/precision info, data periods

#### Assets
- **All Assets**: `GET /v1/assets`
  - **Optional Parameter**: `filter_asset_id` (comma/semicolon delimited)
  - **Response Fields**:
    - `asset_id`: Unique identifier (ISO 4217 for fiat)
    - `name`: Asset name
    - `type_is_crypto`: 1 for crypto, 0 for others
    - `price_usd`: Current USD price
    - `volume_1hrs_usd/1day_usd/1mth_usd`: Trading volumes
    - `chain_addresses`: Blockchain network addresses
    - Data period information (quote, orderbook, trade)
- **Asset by ID**: `GET /v1/assets/:asset_id`
  - **Purpose**: Retrieve detailed information about a specific asset
  - **Required Parameter**: `asset_id` (string) - Unique asset identifier
  - **Response Includes**: Asset details, trading data, volume metrics, price, supply information, chain addresses
- **Asset Icons**: `GET /v1/assets/icons/:size`
  - **Purpose**: Retrieve icons for all assets
  - **Required Parameter**: `size` (int32) - Icon size specification
  - **Response Fields**:
    - `exchange_id`: Exchange identifier (nullable)
    - `asset_id`: Asset identifier (nullable) 
    - `url`: Icon URL (nullable)
  - **Example Response**:
```json
[
  {
    "asset_id": "BTC",
    "url": "https://s3.eu-central-1.amazonaws.com/bbxt-static-icons/type-id/png_16/f231d7382689406f9a50dde841418c64.png"
  },
  {
    "asset_id": "ETH", 
    "url": "https://s3.eu-central-1.amazonaws.com/bbxt-static-icons/type-id/png_16/04836ff3bc4d4d95820e0155594dca86.png"
  }
]
```

#### Exchanges
- **All Exchanges**: `GET /v1/exchanges`
  - **Optional Parameter**: `filter_exchange_id`
  - **Response Fields**:
    - `exchange_id`: Unique identifier
    - `website`: Exchange web address
    - `name`: Exchange name
    - `data_start/end`: Data availability periods
    - `volume_1day_usd`: Daily trading volume
    - `data_symbols_count`: Number of trading symbols
    - Integration status and ranking information
- **Exchange by ID**: `GET /v1/exchanges/:exchange_id`
  - **Purpose**: Retrieve detailed information about a specific exchange
  - **Required Parameter**: `exchange_id` (string) - Exchange identifier
  - **Response Includes**: Exchange details, website, name, data periods, trading volume, symbol count, rank, integration status
- **Exchange Icons**: `GET /v1/exchanges/icons/:size`
  - **Purpose**: Retrieve icons for cryptocurrency exchanges
  - **Required Parameter**: `size` (int) - Icon dimensions
  - **Response Fields**:
    - `exchange_id`: Exchange identifier
    - `asset_id`: Optional asset identifier
    - `url`: Icon image URL
  - **Example Response**:
```json
[
  {
    "exchange_id": "CHAINCE",
    "url": "https://s3.eu-central-1.amazonaws.com/bbxt-static-icons/type-id/png_16/204e55dd8dab4a0d823c21f04be6be4b.png"
  }
]
```
- **Historical Symbols for Exchange**: `GET /v1/symbols/:exchange_id/history`
  - **Purpose**: Retrieve historical symbols for a specific exchange
  - **Required Parameter**: `exchange_id` (string) - Exchange ID
  - **Optional Parameters**:
    - `page` (int32): Page number for pagination (default: 1)
    - `limit` (int32): Records per page (default: 100)
  - **Response**: Array of symbol objects with symbol_id, exchange_id, symbol_type, asset IDs, volumes, price/precision info, data periods

#### Blockchain
- **All Chains**: `GET /v1/chains`
  - **Purpose**: Retrieve all blockchain chains supported by the system
  - **Optional Parameter**: `filter_chain_id` (comma/semicolon delimited chain identifiers)
  - **Response Fields**:
    - `chain_id`: Unique identifier (e.g., "ETHEREUM")
    - `name`: Full name of the chain (e.g., "Ethereum")
  - **Note**: Provides aggregated information from all symbols related to the specific chain
- **Chain by ID**: `GET /v1/chains/:chain_id`
  - **Purpose**: Retrieve chain information by specific chain ID
  - **Required Parameter**: `chain_id` (string) - Blockchain chain identifier
  - **Example Response**:
```json
[
  {
    "chain_id": "ETHEREUM",
    "name": "Ethereum"
  },
  {
    "chain_id": "ARBITRUM", 
    "name": "Arbitrum"
  },
  {
    "chain_id": "POLYGON",
    "name": "Polygon"
  }
]
```

---

### OHLCV (Open, High, Low, Close, Volume)
**Base Endpoint**: `/v1/ohlcv/`

#### Historical Data

##### By Symbol
- **URL**: `GET /v1/ohlcv/:symbol_id/history`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier from metadata
  - `period_id` (string): Time period (5SEC, 1MIN, 1HRS, 1DAY, etc.)
- **Optional Parameters**:
  - `time_start` (string): ISO 8601 starting time
  - `time_end` (string): ISO 8601 ending time
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Schema**:
  - `time_period_start/end`: Period boundaries
  - `time_open/close`: Opening/closing times
  - `price_open/high/low/close`: OHLC prices
  - `volume_traded`: Trading volume
  - `trades_count`: Number of trades
- **Note**: Data can be delayed a few seconds

##### By Exchange
- **URL**: `GET /v1/ohlcv/exchanges/:exchange_id/history`
- **Required Parameters**:
  - `exchange_id` (string): Exchange identifier
  - `period_id` (string): Period identifier (e.g., `5SEC` or `1DAY`)
  - `time_start` (string): Start time in ISO 8601
  - `time_end` (string): End time in ISO 8601
- **Important Limitations**:
  - Data can be delayed by a few seconds
  - Time difference between `time_start` and `time_end` cannot exceed 1 day
  - `period_id` cannot be higher than `1DAY`
- **Response Fields**:
  - Time period start and end
  - Open, high, low, close prices
  - Volume traded
  - Number of trades
  - Exchange and CoinAPI symbol identifiers
- **Note**: Returns OHLCV timeseries data in time ascending order

##### Latest Data
- **URL**: `GET /v1/ohlcv/:symbol_id/latest`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier
  - `period_id` (string): Timeseries period (e.g., `5SEC` or `2MTH`)
- **Optional Parameters**:
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Details**:
  - Returns OHLCV data in **descending time order**
  - Each data point includes time period boundaries, OHLC prices, volume, trade count
- **Note**: This endpoint is a shortcut to the OHLCV Historical endpoint

##### Supported Periods
- **URL**: `GET /v1/ohlcv/periods`
- **Purpose**: Get full list of supported time periods for OHLCV timeseries data
- **Available Time Periods**:
  - **Seconds**: 1SEC, 2SEC, 3SEC, 4SEC, 5SEC, 6SEC, 10SEC, 15SEC, 20SEC, 30SEC
  - **Minutes**: 1MIN, 2MIN, 3MIN, 4MIN, 5MIN, 6MIN, 10MIN, 15MIN, 20MIN, 30MIN
  - **Hours**: 1HRS, 2HRS, 3HRS, 4HRS, 6HRS, 8HRS, 12HRS
  - **Days**: 1DAY, 2DAY, 3DAY, 5DAY, 7DAY, 10DAY
  - **Months**: 1MTH, 2MTH, 3MTH, 4MTH, 5MTH, 6MTH
  - **Years**: 1YRS, 2YRS, 3YRS, 4YRS, 5YRS
- **Response Schema**:
  - `period_id` (string): Unique period identifier
  - `length_seconds` (int32): Duration in seconds
  - `length_months` (int32): Duration in months
  - `unit_count` (int32): Number of time units
  - `unit_name` (string): Time unit name
  - `display_name` (string): Human-readable description

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

**Example Response**:
```json
[
  {
    "time_period_start": "2016-01-01T00:00:00.0000000Z",
    "time_period_end": "2016-01-02T00:00:00.0000000Z",
    "time_open": "2016-01-01T00:00:00.0000000Z",
    "time_close": "2016-01-01T23:59:59.0000000Z",
    "price_open": 431.18,
    "price_high": 432.65,
    "price_low": 429.15,
    "price_close": 430.84,
    "volume_traded": 42.12,
    "trades_count": 17
  }
]
```

---

### Options API
**Base Endpoint**: `/v1/options/`

#### Current Data by Exchange
- **URL**: `GET /v1/options/:exchange_id/current`
- **Parameters**:
  - `exchange_id` (path, required): Exchange identifier from Metadata
- **Purpose**: Retrieve current options market data for a specific exchange
- **Response Structure**: Options data grouped by:
  - Underlying asset
  - Quote currency
  - Expiration time
- **Response Fields**:
  - `asset_id_base`: Base asset identifier
  - `asset_id_quote`: Quote asset identifier  
  - `underlying_price`: Current price of underlying asset
  - `expiration_time`: Option expiration timestamp
  - `strikes`: Array of strike prices with call/put data
- **Strike Data Includes**:
  - Strike price
  - Call option details (symbol ID, timestamps, ask/bid prices and sizes, last trade info)
  - Put option details (symbol ID, timestamps, ask/bid prices and sizes, last trade info)
- **Response Formats**: JSON, text/plain, text/json, application/x-msgpack
- **Example Response** (Bitcoin options with USD quote):
```json
{
  "asset_id_base": "BTC",
  "asset_id_quote": "USD", 
  "underlying_price": 45000.00,
  "expiration_time": "2024-12-29T08:00:00.0000000Z",
  "strikes": [
    {
      "strike_price": 44000.00,
      "call": {
        "symbol_id": "DERIBIT_OPTION_BTC_29DEC23_44000_C",
        "time_exchange": "2023-12-15T10:30:00.0000000Z",
        "time_coinapi": "2023-12-15T10:30:01.2340000Z",
        "ask_price": 1200.50,
        "ask_size": 5.0,
        "bid_price": 1180.25,
        "bid_size": 3.5,
        "last_trade": {
          "time": "2023-12-15T10:29:45.0000000Z",
          "price": 1190.00,
          "size": 2.0
        }
      },
      "put": {
        "symbol_id": "DERIBIT_OPTION_BTC_29DEC23_44000_P",
        "time_exchange": "2023-12-15T10:30:00.0000000Z",
        "time_coinapi": "2023-12-15T10:30:01.2340000Z",
        "ask_price": 450.75,
        "ask_size": 8.0,
        "bid_price": 425.50,
        "bid_size": 6.0,
        "last_trade": {
          "time": "2023-12-15T10:28:30.0000000Z",
          "price": 440.25,
          "size": 1.5
        }
      }
    }
  ]
}
```

---

### Order Book API (Level 2 Market Data)
**Base Endpoint**: `/v1/orderbooks/`

**Purpose**: Provides data related to order books (passive level 2 data) with multiple endpoints for retrieving order book information at different levels of detail and timeframes.

**Important Notes**:
- For current data on specific symbol, output is not in JSON array format
- GET `/v1/orderbooks/current` is charged per 100 data points
- When requesting single-level order book data, quotes are used
- Some data sources merge order book and quote feeds for faster updates
- Quote data might have size equal to 0 when size is unknown

#### Current Order Book Data

##### Current Order Book
- **URL**: `GET /v1/orderbooks/:symbol_id/current`
- **Purpose**: Retrieve the current order book for a specified symbol
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier from Metadata
- **Optional Parameters**:
  - `limit_levels` (int): Maximum number of levels to include in response
- **Response Fields**:
  - `symbol_id`: Symbol identifier
  - `time_exchange`: Exchange timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `asks`: Market maker sell orders (array)
  - `bids`: Market maker buy orders (array)
- **Example Response**:
```json
{
  "symbol_id": "COINBASE_SPOT_BCH_USD",
  "time_exchange": "2020-08-27T10:28:35.6111130Z",
  "time_coinapi": "2020-08-27T10:28:35.6766461Z",
  "asks": [
    {
      "id": "unique_id",
      "price": 272.89,
      "size": 1
    }
  ],
  "bids": [
    {
      "id": "unique_id", 
      "price": 272.83,
      "size": 18
    }
  ]
}
```

##### Current Depth of Order Book
- **URL**: `GET /v1/orderbooks/:symbol_id/depth/current`
- **Purpose**: Retrieve current depth of an order book for a specific symbol
- **Required Parameters**:
  - `symbol_id` (string): Trading symbol identifier
- **Optional Parameters**:
  - `limit_levels` (int): Maximum number of levels to include in response
- **Response Fields**:
  - `symbol_id`: Symbol identifier
  - `time_exchange`: Timestamp from the exchange
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_levels`: Number of ask levels
  - `bid_levels`: Number of bid levels
  - `ask_depth`: Depth of ask side
  - `bid_depth`: Depth of bid side

#### Historical Order Book Data

##### Historical Data
- **URL**: `GET /v1/orderbooks/:symbol_id/history`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier
- **Optional Parameters**:
  - `date` (string): ISO 8601 date for retrieving order book data (recommended)
  - `time_start/time_end` (string): Time range parameters (deprecated)
  - `limit` (int): Items to return (default 100, max 100,000)
  - `limit_levels` (int): Maximum order book levels to include
- **Response Details**:
  - Returns order book snapshots in **time ascending order**
  - Each snapshot includes: `symbol_id`, `time_exchange`, `time_coinapi`, `asks`, `bids`
- **Important Limitations**:
  - Intraday data only
  - Limited to 20 levels per order book
  - Use 'date' parameter instead of time range for better performance
- **Example Response**:
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2013-09-28T22:40:50Z",
  "asks": [{"price": 456.35, "size": 123}],
  "bids": [{"price": 456.1, "size": 42}]
}
```

##### Latest Data
- **URL**: `GET /v1/orderbooks/:symbol_id/latest`
- **Purpose**: Retrieve latest order book snapshots for a specific symbol
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier from Metadata
- **Optional Parameters**:
  - `limit` (int): Items to return (default 100, max 100,000)
  - `limit_levels` (int): Maximum levels from each side of the book
- **Response Format**:
  - Returns array of order book snapshots
  - Each snapshot includes: `symbol_id`, `time_exchange`, `time_coinapi`, `asks`, `bids`
- **Note**: Historical order book data via REST API is limited to maximum of 20 levels

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

### Order Book L3 API (Level 3 Market Data)
**Base Endpoint**: `/v1/orderbooks3/`

**Purpose**: Provides detailed order book data representing "passive level 3 data" with individual order information, offering more granular market depth than Level 2 data.

**Key Differences from L2**:
- **Individual Order Details**: Each order includes unique identifiers
- **Enhanced Granularity**: More detailed order information
- **Order-by-Order Data**: Ability to track individual orders rather than aggregated levels

#### Current Order Book Data

##### Current Order Book by Symbol
- **URL**: `GET /v1/orderbooks3/:symbol_id/current`
- **Purpose**: Retrieve the current L3 order book for a specific symbol
- **Required Parameters**:
  - `symbol_id` (string): Identifier for the specific trading symbol
- **Optional Parameters**:
  - `limit_levels` (int): Maximum number of order book levels to return
- **Response Fields**:
  - `symbol_id`: Symbol identifier
  - `time_exchange`: Timestamp from the exchange
  - `time_coinapi`: CoinAPI receipt timestamp
  - `asks`: List of sell orders with price, size, and unique ID
  - `bids`: List of buy orders with price, size, and unique ID
- **Example Response**:
```json
{
  "symbol_id": "COINBASE_SPOT_BCH_USD",
  "time_exchange": "2020-08-27T10:28:35.6111130Z",
  "time_coinapi": "2020-08-27T10:28:35.6766461Z",
  "asks": [
    {
      "id": "unique-order-id-1",
      "price": 272.89,
      "size": 1.0
    }
  ],
  "bids": [
    {
      "id": "unique-order-id-2",
      "price": 272.83,
      "size": 18.0
    }
  ]
}
```

##### Current Order Books (All Symbols)
- **URL**: `GET /v1/orderbooks3/current`
- **Purpose**: Retrieve current L3 order books across all symbols
- **Optional Parameters**:
  - `filter_symbol_id` (string): Filter results by symbol identifier
  - `limit_levels` (int): Set maximum number of order book levels to return
- **Response Characteristics**:
  - Returns an array of order book data
  - Each entry includes: `symbol_id`, `time_exchange`, `time_coinapi`, `asks`, `bids`
  - Provides real-time order book information with individual order tracking

**Key Features**:
- **Individual Order Tracking**: Unique identifiers for each order
- **Enhanced Market Depth**: More detailed than L2 aggregated data
- **Real-time Updates**: Current market state with precise timing
- **Flexible Filtering**: Filter by symbol or limit depth levels

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

### MetricsV1 API
**Base Endpoint**: `/v1/metrics/`

**Purpose**: Provide quantitative measurements to evaluate cryptocurrency exchange performance and activity

**Key Metrics Tracked**:
1. Trading Volume
2. Market Depth  
3. Order Book
4. Spread
5. Price Charts
6. Market Cap
7. Trading Pairs
8. User Metrics
9. Trading Fees
10. Security Metrics

#### Current Metrics

##### Current Metrics for Asset
- **URL**: `GET /v1/metrics/asset/current`
- **Parameters**:
  - `metric_id` (string): Metric identifier
  - `asset_id` (string): Asset identifier
  - `asset_id_external` (string, optional): Exchange asset identifier
  - `exchange_id` (string, optional): Exchange identifier
- **Response Fields**:
  - `entry_time`: Entry timestamp
  - `recv_time`: Receipt timestamp
  - `exchange_id`: Exchange identifier
  - `asset_id`: Asset identifier
  - `metric_id`: Metric identifier
  - `value_decimal`: Numeric value
  - `value_text`: Text value (optional)
  - `value_time`: Value timestamp (optional)
- **Example Response**:
```json
[
  {
    "entry_time": "2023-06-16T07:55:07.2787756Z",
    "exchange_id": "DERIBIT",
    "metric_id": "DERIVATIVES_MARK_PRICE",
    "value_decimal": 0.0086
  }
]
```

##### Current Metrics for Exchange
- **URL**: `GET /v1/metrics/exchange/current`
- **Required Parameters**:
  - `exchange_id` (string): Exchange identifier
  - `metric_id` (string): Metric identifier
- **Response Fields**:
  - `entry_time`: Entry timestamp
  - `recv_time`: Receipt timestamp
  - `exchange_id`: Exchange identifier
  - `metric_id`: Metric identifier
  - `value_decimal`: Numeric value
- **Example Response**:
```json
[
  {
    "exchange_id": "DERIBIT",
    "metric_id": "DERIVATIVES_MARK_PRICE", 
    "value_decimal": 0.0086
  }
]
```

##### Current Metrics for Symbol
- **URL**: `GET /v1/metrics/symbol/current`
- **Parameters**:
  - `metric_id` (string): Metric identifier
  - `symbol_id` (string): Symbol identifier
  - `exchange_id` (string, optional): Exchange identifier
- **Response Fields**:
  - `entry_time`: Entry timestamp
  - `recv_time`: Receipt timestamp
  - `exchange_id`: Exchange identifier
  - `symbol_id`: Symbol identifier
  - `metric_id`: Metric identifier
  - `value_decimal`: Numeric value
  - `value_text`: Text value (optional)
  - `value_time`: Value timestamp (optional)
- **Example Response**:
```json
[
  {
    "exchange_id": "DERIBIT",
    "symbol_id": "DERIBIT_OPT_BTC_USD_240329_80000_P",
    "metric_id": "GREEKS_VEGA",
    "value_decimal": 49.31013
  }
]
```

#### Historical Metrics

##### Historical Metrics for Asset
- **URL**: `GET /v1/metrics/asset/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier
  - `exchange_id` (string): Exchange identifier
- **Optional Parameters**:
  - `asset_id` (string): Asset identifier
  - `time_start` (string): Starting time (ISO 8601)
  - `time_end` (string): Ending time (ISO 8601)
  - `period_id` (string): Timeseries period (default: `1SEC`)
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Response Fields**:
  - `symbol_id`: Symbol identifier (nullable)
  - `time`: Timestamp of recorded value
  - `value`: Metric value

##### Historical Metrics for Symbol  
- **URL**: `GET /v1/metrics/symbol/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier
  - `symbol_id` (string): Symbol identifier
- **Optional Parameters**:
  - `time_start` (string): Starting time (ISO 8601)
  - `time_end` (string): Ending time (ISO 8601)
  - `time_format` (string): Time format (unix options)
  - `period_id` (string): Timeseries period (default: `1SEC`)
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Example Response**:
```json
[
  {
    "symbol_id": "string",
    "time": "2025-08-31T00:17:12.222Z",
    "value": 0
  }
]
```

##### Historical Metrics for Exchange
- **URL**: `GET /v1/metrics/exchange/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier
  - `exchange_id` (string): Exchange identifier
- **Optional Parameters**:
  - `time_start` (string): Starting time (ISO 8601)
  - `time_end` (string): Ending time (ISO 8601)
  - `time_format` (string): Time format (unix options)
  - `period_id` (string): Timeseries period (default: `1SEC`)
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Example Response**:
```json
[
  {
    "symbol_id": "string",
    "time": "2025-08-31T00:17:12.216Z",
    "value": 0
  }
]
```

#### Metrics Listings

##### All Supported Metrics by CoinAPI
- **URL**: `GET /v1/metrics/listing`
- **Purpose**: Retrieve complete catalog of all metrics supported by CoinAPI
- **Response Fields**:
  - `metric_id`: Unique metric identifier
  - `description`: Metric description and calculation method
  - `category`: Metric category (trading, derivatives, blockchain, etc.)
  - `data_type`: Value type (decimal, text, timestamp)
  - `update_frequency`: How often the metric is calculated
- **Use Cases**: 
  - Metric discovery and catalog browsing
  - Integration planning and capability assessment
  - Comprehensive metric reference

##### Supported Exchange Metrics
- **URL**: `GET /v1/metrics/exchange/listing`
- **Required Parameters**:
  - `exchange_id` (string): Exchange identifier from Metadata
- **Optional Parameters**:
  - `metric_id` (string): Specific metric identifier
- **Response Fields**:
  - `metric_id`: Metric identifier
  - `symbol_id`: Symbol identifier
  - `exchange_id`: Exchange identifier
  - `asset_id`: Asset identifier
  - `chain_id`: Chain identifier
  - `network_id`: Network identifier
- **Example Response**:
```json
[
  {
    "metric_id": "LIQUIDATION_TIME_IN_FORCE",
    "exchange_id": "BINANCEFTS"
  },
  {
    "metric_id": "LIQUIDATION_ORDER_TYPE",
    "exchange_id": "BINANCEFTS"
  }
]
```

##### Supported Metrics for Asset
- **URL**: `GET /v1/metrics/asset/listing`
- **Parameters**:
  - `metric_id` (string, optional): Metric identifier
  - `exchange_id` (string, optional): Exchange identifier
  - `chain_id` (string, optional): Chain identifier
  - `network_id` (string, optional): Network identifier
  - `asset_id` (string, optional): Asset identifier
  - `asset_id_external` (string, optional): External asset identifier
- **Example Response**:
```json
[
  {
    "metric_id": "LIQUIDATION_TIME_IN_FORCE",
    "symbol_id": "BINANCEFTS_PERP_ETC_USDT",
    "exchange_id": "BINANCEFTS"
  }
]
```

##### Supported Metrics for Symbol
- **URL**: `GET /v1/metrics/symbol/listing`
- **Parameters**:
  - `metric_id` (string, optional): Metric identifier
  - `exchange_id` (string, optional): Exchange identifier
  - `symbol_id` (string, optional): Symbol identifier
- **Response Fields**:
  - `metric_id`: Metric identifier
  - `symbol_id`: Symbol identifier
  - `exchange_id`: Exchange identifier
  - `symbol_id_external`: External symbol identifier (optional)
  - `asset_id`: Asset identifier (optional)
- **Example Response**:
```json
[
  {
    "metric_id": "LIQUIDATION_TIME_IN_FORCE",
    "symbol_id": "BINANCEFTS_PERP_ETC_USDT",
    "exchange_id": "BINANCEFTS"
  }
]
```

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

### MetricsV2 API
**Base Endpoint**: `/v2/metrics/`

**Purpose**: Provide quantitative measurements to evaluate cryptocurrency exchange performance and activity with enhanced functionality over MetricsV1

**Key Metrics Tracked**:
1. Trading Volume
2. Market Depth
3. Order Book  
4. Spread
5. Price Charts
6. Market Cap
7. Trading Pairs
8. User Metrics
9. Trading Fees
10. Security Metrics

#### Historical Metrics

##### Historical Metrics for Asset
- **URL**: `GET /v2/metrics/asset/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier (e.g., 'TVL', 'STABLES_BRIDGED_USD')
  - `asset_id` (string): Asset identifier (e.g., 'USDC', 'USDT')
- **Optional Parameters**:
  - `time_start` (string): Starting time in ISO 8601
  - `time_end` (string): Ending time in ISO 8601
  - `time_format` (string): Unix timestamp format options
  - `period_id` (string): Timeseries period (default: '1MIN')
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Response Fields**:
  - `time_period_start`: Period start timestamp
  - `time_period_end`: Period end timestamp
  - `first_value`: First value in period
  - `last_value`: Last value in period
  - `min_value`: Minimum value in period
  - `max_value`: Maximum value in period
  - `count`: Number of values
  - `sum`: Sum of values
- **Example Response**:
```json
[
  {
    "time_period_start": "2023-07-03T00:00:00.0000000Z",
    "first_value": 15000000000,
    "last_value": 15500000000,
    "min_value": 14800000000,
    "max_value": 15600000000
  }
]
```

##### Historical Metrics for Chain
- **URL**: `GET /v2/metrics/chain/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier (e.g., 'TVL')
  - `chain_id` (string): Chain identifier (e.g., 'Ethereum')
- **Optional Parameters**:
  - `time_start` (string): Starting time in ISO 8601
  - `time_end` (string): Ending time in ISO 8601
  - `time_format` (string): Time format (unix options)
  - `period_id` (string): Timeseries period (default: '1MIN')
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Response Fields**: Same as Historical Metrics for Asset
- **Example Response**:
```json
[
  {
    "time_period_start": "2023-07-03T00:00:00.0000000Z",
    "first_value": 25000000000,
    "last_value": 26000000000,
    "min_value": 24500000000,
    "max_value": 26200000000
  }
]
```

##### Historical Metrics for Exchange
- **URL**: `GET /v2/metrics/exchange/history`
- **Required Parameters**:
  - `metric_id` (string): Metric identifier (e.g., 'TVL', 'STABLES_BRIDGED_USD')
  - `exchange_id` (string): Exchange identifier (e.g., 'BINANCE', 'UNISWAP-V3-ETHEREUM')
- **Optional Parameters**:
  - `time_start` (string): Starting time in ISO 8601
  - `time_end` (string): Ending time in ISO 8601
  - `time_format` (string): Time format (unix options)
  - `period_id` (string): Timeseries period (default: '1MIN')
  - `limit` (int): Items to return (default: 100, max: 100,000)
- **Response Fields**: Same as Historical Metrics for Asset

#### Metrics Listings

##### All Supported Metrics
- **URL**: `GET /v2/metrics/listing`
- **Purpose**: Get all metrics available in the system
- **Response Fields**:
  - `metric_id` (string): Metric identifier
  - `description` (string): Metric description
  - `source_id` (string, optional): Source identifier
- **Example Metrics**:
  - `TVL`: Total Value Locked in the protocol
  - `FEES`: Total fees collected by the protocol
  - `VOLUMES`: Trading volume metrics
  - `STABLES_BRIDGED_USD`: Total USD stablecoins bridged to USD value
  - `STABLES_CIRCULATING_USD`: Total circulating USD stablecoins

##### Metrics for Specific Asset
- **URL**: `GET /v2/metrics/asset/listing`
- **Required Parameters**:
  - `asset_id` (string): Asset identifier (e.g., USDC, USDT)
- **Response Fields**:
  - `metric_id` (string): Metric identifier
  - `description` (string): Metric description
  - `source_id` (string, nullable): Source identifier
- **Example Response**:
```json
[
  {
    "metric_id": "STABLES_BRIDGED_USD",
    "description": "Total USD stablecoins bridged to USD value"
  },
  {
    "metric_id": "STABLES_CIRCULATING_USD",
    "description": "Total circulating USD stablecoins"
  }
]
```

##### Metrics for Specific Chain
- **URL**: `GET /v2/metrics/chain/listing`
- **Required Parameters**:
  - `chain_id` (string): Chain identifier (e.g., ETHEREUM, ARBITRUM)
- **Response Fields**:
  - `metric_id`: Metric identifier
  - `description`: Metric description
  - `source_id`: Source identifier (optional)
- **Example Metrics**:
  - `TVL`: Total Value Locked in the protocol
  - `STABLES_BRIDGED_USD`: Total USD stablecoins bridged to USD value
  - `STABLES_CIRCULATING_USD`: Total circulating USD stablecoins

##### Metrics for Specific Exchange
- **URL**: `GET /v2/metrics/exchange/listing`
- **Required Parameters**:
  - `exchange_id` (string): Exchange identifier (e.g., BINANCE, UNISWAP-V3-ETHEREUM)
- **Response Fields**:
  - `metric_id`: Metric identifier
  - `description`: Description of the metric
  - `source_id`: Source identifier of the metric
- **Example Metrics**:
  - `TVL`: Total Value Locked in the protocol
  - `FEES`: Total fees collected by the protocol
  - `TRADES_COUNT_BUYS`: Generic metric for buy trades
  - `VOLUME_QUOTED`: Generic metric for quoted volume

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

## How-to Guides

### Overview
CoinAPI provides comprehensive how-to guides with practical, step-by-step instructions for integrating cryptocurrency data across various scenarios. These tutorials help developers leverage CoinAPI's capabilities effectively.

### Available Tutorials

#### Programming Language Implementations

##### Acquire Exchange Rates with Different Programming Languages
**Purpose**: Learn how to retrieve cryptocurrency exchange rates using Python, JavaScript, and Java

**Prerequisites**:
- CoinAPI key (free from console.coinapi.io)
- Basic understanding of RESTful APIs and JSON
- Familiarity with chosen programming language

**Python Implementation**:
```python
import requests

url = "https://rest.coinapi.io/v1/exchangerate/BTC/USD"
headers = {"X-CoinAPI-Key": "YOUR-API-KEY"}
response = requests.get(url, headers=headers)
print(response.json())
```

**JavaScript Implementation**:
```javascript
fetch('https://rest.coinapi.io/v1/exchangerate/BTC/USD', {
  headers: {"X-CoinAPI-Key": "YOUR_API_KEY"}
})
.then(response => response.json())
.then(data => console.log(data))
```

**Java Implementation**:
```java
URL url = new URL("https://rest.coinapi.io/v1/exchangerate/BTC/USD");
HttpURLConnection conn = (HttpURLConnection) url.openConnection();
conn.setRequestProperty("X-CoinAPI-Key", API_KEY);
// Read and process response
```

**Response Format**:
- Timestamp
- Base asset identifier
- Quote asset identifier  
- Current exchange rate

**Best Practices**:
- Secure API key storage
- Implement error handling
- Be aware of rate limits
- Consider caching responses

#### Web Application Development

##### Build Cryptocurrency Portfolio Tracker using React
**Purpose**: Create a real-time cryptocurrency portfolio tracker with React and CoinAPI

**Setup Steps**:
1. Create React app: `npx create-react-app coinapi-portfolio-tracker-app`
2. Install dependencies: `npm install axios`
3. Obtain CoinAPI key

**Core Implementation**:
```javascript
function App() {
  const [portfolio, setPortfolio] = useState([]);
  
  useEffect(() => {
    async function fetchExchangeRates() {
      // Fetch rates for selected cryptocurrencies
      const assets = ['BTC', 'ETH', 'XRP'];
      // API call logic with axios
    }
    fetchExchangeRates();
  }, []);
  
  return (
    <div className="App">
      {/* Portfolio display components */}
    </div>
  );
}
```

**Features**:
- Real-time exchange rate updates
- Interval-based data refresh
- Responsive design
- USD conversion for multiple assets

**Recommended Enhancements**:
- Add more cryptocurrencies
- Implement detailed portfolio tracking
- Improve error handling
- Enhanced UI/UX

##### Building Cryptocurrency Exchange Comparison Tool
**Purpose**: Compare cryptocurrency prices across different exchanges using Market Data API

**Key Features**:
- Compare prices across exchanges
- Fetch real-time quotes and trading volume
- Historical price comparison

**Python Implementation Structure**:
```python
class PriceInformation:
    def __init__(self, price, size, direction):
        self.price = price
        self.size = size
        self.direction = direction

# Fetch price data for specific trading pairs
# Compare prices from exchanges like Kraken and Binance
# Display price, trading size, and trade direction
```

**Implementation Steps**:
1. Obtain CoinAPI key
2. Use REST API to fetch current quotes
3. Create comparison logic for multiple exchanges
4. Display results with price differences

**Supported Comparisons**:
- Current price across exchanges
- Trading volume comparison
- Historical price trends
- Trading pair availability

#### Data Analysis and Visualization

##### Historical Crypto Price Charts with D3.js
**Purpose**: Build interactive historical cryptocurrency price charts using D3.js
**Technologies**: CoinAPI, JavaScript, D3.js
**Key Steps**:
1. **Project Setup**: Create HTML, CSS, and JavaScript files
2. **API Configuration**: Obtain CoinAPI key, fetch historical price data
3. **Data Preparation**: Transform API response into chart-compatible format
4. **Chart Creation**: Use D3.js SVG, scales, and line generators
5. **Styling**: Apply CSS gradients and visual design
**Code Highlights**:
- `async function fetchData()` - API data retrieval
- `function transformData(data)` - Data transformation  
- D3.js line generator and scaling methods for visualization

##### Historical Crypto Price Charts with D3.js
**Purpose**: Build interactive historical cryptocurrency price charts using D3.js
**Technologies**: CoinAPI, JavaScript, D3.js
**Key Steps**:
1. **Project Setup**: Create HTML, CSS, and JavaScript files
2. **API Configuration**: Obtain CoinAPI key, fetch historical price data
3. **Data Preparation**: Transform API response into chart-compatible format
4. **Chart Creation**: Use D3.js SVG, scales, and line generators
5. **Styling**: Apply CSS gradients and visual design
**Code Highlights**:
- `async function fetchData()` - API data retrieval  
- `function transformData(data)` - Data transformation  
- D3.js line generator and scaling methods for visualization

##### Real-time Data Visualization with JavaScript
**Purpose**: Create real-time cryptocurrency price charts using WebSocket
**Technologies**: JavaScript, WebSocket, Chart.js
**Implementation**:
1. **Chart Initialization**: Create empty line chart with Chart.js
2. **WebSocket Connection**: Connect to CoinAPI WebSocket API
3. **Real-time Updates**: Parse trade data, update chart continuously
**Code Example**:
```javascript
// Chart initialization
const chart = new Chart(ctx, {
    type: 'line',
    data: { labels: [], datasets: [{ data: [], label: 'BTC/USD' }] }
});

// WebSocket real-time updates
socket.onmessage = function (event) {
    const data = JSON.parse(event.data);
    chart.data.labels.push(data.time_exchange);
    chart.data.datasets[0].data.push(data.price);
    
    // Limit to 50 data points
    if (chart.data.labels.length > 50) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }
    chart.update();
};
```

##### Real-time Trades Stream using WebSocket
**Purpose**: Demonstrate real-time cryptocurrency market data streaming
**Supported Languages**: Python, JavaScript, Java
**WebSocket Endpoint**: `wss://ws.coinapi.io/v1/`
**Implementation Steps**:
1. Establish WebSocket connection
2. Send "hello" message with API key and subscriptions
3. Process real-time trade data
**Language Examples**:
- **Python**: Uses `websocket-client` library with `WebSocketApp`
- **JavaScript**: Node.js with `ws` library or browser native `WebSocket`
- **Java**: Uses `Java-WebSocket` library with `WebSocketClient`
**Best Practices**: Connection error handling, rate limit awareness, secure API key storage

##### Retrieve and Analyze Crypto Order Book Data
**Purpose**: Fetch and analyze cryptocurrency order book data for market insights
**Technologies**: Python, CoinAPI, Matplotlib
**Analysis Techniques**:
1. **Order Book Depth**: Visualize liquidity at different price levels
2. **Order Imbalance**: Measure buy vs sell order volume differences
3. **Significant Price Levels**: Identify key price points with substantial activity
4. **Market Spread**: Calculate bid-ask spread for transaction costs
**Key Metrics**:
- Order Imbalance (market sentiment indicator)
- Significant Bids/Asks (important price levels)
- Market Spread (transaction cost representation)
**Implementation**: Uses `requests` for API calls, `matplotlib` for visualization

##### Get Historical OHLCV Data
**Purpose**: Retrieve historical Open, High, Low, Close, Volume data
**Key Endpoints**:
- `ohlcv/period_id/history`: Historical OHLCV data
- `trades/symbol_id/history`: Historical trades
- `quotes/symbol_id/history`: Historical quotes
**Implementation Requirements**:
1. CoinAPI key authentication
2. Symbol ID specification (e.g., `BINANCE_SPOT_ETH_BTC`)
3. Period ID selection (e.g., `1MTH`)
4. Time range parameters
**Language Examples**:
```python
# Python implementation
url = "https://rest.coinapi.io/v1/ohlcv/BINANCE_SPOT_ETH_BTC/history"
headers = { "X-CoinAPI-Key": "YOUR_API_KEY" }
response = requests.get(url, headers=headers)
```
```javascript
// JavaScript implementation
fetch('https://rest.coinapi.io/v1/ohlcv/BINANCE_SPOT_ETH_BTC/history', {
  headers: { "X-CoinAPI-Key": "YOUR_API_KEY" }
})
```

##### Get Symbol Funding Rate Metrics
**Purpose**: Access funding rate metrics for cryptocurrency derivatives
**Key Endpoints**:
1. `/v1/metrics/symbol/listing` - List supported metrics for symbols
2. `/v1/metrics/symbol/current` - Real-time metrics for specific symbols
3. `/v1/metrics/symbol/history` - Historical metric data
**Example Request**:
```
GET /v1/metrics/symbol/current?metric_id=DERIVATIVES_FUNDING_RATE_CURRENT&symbol_id=BINANCEFTSC_PERP_ETH_USD&exchange_id=BINANCEFTSC
```
**Parameters**: metric_id, symbol_id, exchange_id, time ranges, format options
**Best Practices**: Secure API keys, respect rate limits, handle errors gracefully

#### Integration Tools

##### Import API into Postman  
**Purpose**: Set up CoinAPI in Postman for testing and development
**Steps**:
1. Copy OpenAPI URL from CoinAPI website
2. Open Postman workspace
3. Import OpenAPI specification via URL
4. Review and confirm generated collection
5. Begin API testing and development
**Benefits**: Effortless OpenAPI specification import, immediate API testing capability

##### Import Data to Google Sheets/Excel
**Purpose**: Access CoinAPI market data in spreadsheet applications
**Prerequisites**: Web browser, CoinAPI key, spreadsheet application
**Key Steps**:
1. **Retrieve CSV Data**: Use CoinAPI URL with CSV format
   - Example: `https://rest.coinapi.io/v1/exchangerate/BTC?apikey=YOUR_API_KEY&output_format=csv`
2. **Excel Import**: Data tab → From Text/CSV → Select file → Import
3. **Google Sheets Import**: File → Import → Upload CSV → Configure settings
**Tip**: Simple browser-based approach for direct CSV data access

##### Fetch Market Data with KNIME
**Purpose**: Integrate CoinAPI data into KNIME Analytics workflows  
**Prerequisites**: CoinAPI key, KNIME Analytics Platform
**Workflow Setup**:
1. Create KNIME workflow
2. Add "Get Request" node for HTTP requests
3. Add "Output JSON" node for response display
4. Configure URL and authentication headers
**Configuration**: Set API endpoint, add CoinAPI key in headers
**Use Cases**: Machine learning, portfolio optimization, trading strategy development
**Benefits**: Flexible data workflow creation, comprehensive financial analysis integration

### Learning Objectives
After completing these guides, developers will be able to:
- Access and integrate cryptocurrency data effectively
- Build portfolio tracking applications
- Create exchange comparison tools
- Implement real-time data visualization
- Set up data pipelines for analysis
- Subscribe to live market feeds
- Handle API authentication and rate limits

---

## Latency FAQ

### Overview
Comprehensive guide for technical professionals to understand and address latency-related challenges in cryptocurrency market data APIs. This FAQ provides insights into latency concepts, influencing factors, and optimization strategies.

### What Influences Latency

#### Geographic Distance
- **Direct Path Impact**: Geographic distance significantly affects latency
- **Example**: Direct path from London to Binance is approximately 250ms
- **Challenge**: Some matching engines are inherently located far from clients

#### Infrastructure Considerations
To achieve low latency (below 100ms), organizations need:
- **Additional Data Centers**: Strategic placement of servers
- **Optimized Network Configurations**: Specialized network topology
- **Network Infrastructure Investment**: Dedicated network resources

#### Client-Side Factors
- **Customer Infrastructure**: Client's own infrastructure plays crucial role
- **Network Setup**: Local network configuration affects overall performance
- **Hardware Considerations**: Processing power and network equipment quality

### How to Reduce Market Data API Latency

#### Network Optimization Strategies

##### AWS Direct Connect
- **Purpose**: Dedicated, direct connection to AWS services
- **Benefits**: Reduced network hops, consistent performance
- **Use Case**: Enterprise-grade connectivity for critical applications

##### AWS VPC Peering
- **Purpose**: Keep data transmission within AWS environment
- **Benefits**: Lower latency, improved security
- **Implementation**: Direct VPC-to-VPC communication

##### GeoDNS Routing
- **Purpose**: Route data through nearest server
- **Benefits**: Minimized geographic distance
- **Implementation**: Automatic routing to closest datacenter

#### Data Transmission Strategies

##### WebSocket API
- **Purpose**: Real-time, continuous data transmission
- **Benefits**: Persistent connection, immediate updates
- **Use Case**: Live market data streaming
- **Implementation**: Maintain active WebSocket connections

##### Effective Data Caching
- **Purpose**: Reduce repeated data fetching
- **Benefits**: Faster response times, reduced API calls
- **Strategies**: Cache frequently accessed market data locally

##### FIX API
- **Purpose**: High-frequency trading environments
- **Benefits**: Industry-standard protocol, optimized for low latency
- **Use Case**: Professional trading applications

#### Performance Monitoring

##### Service Level Agreements (SLAs)
- **Purpose**: Define acceptable latency thresholds
- **Benefits**: Clear performance expectations
- **Implementation**: Monitor and track SLA compliance

##### Real-time Performance Monitoring
- **Purpose**: Continuous latency tracking
- **Benefits**: Early problem detection
- **Tools**: Latency measurement dashboards

##### Alert Systems
- **Purpose**: Proactive notification of latency spikes
- **Benefits**: Immediate response to performance issues
- **Implementation**: Automated alert triggers

#### Critical Optimization Principles

1. **Minimize Data Travel Distance**: Use geographically distributed servers
2. **Maintain Continuous Connections**: Avoid connection overhead
3. **Cache Frequently Used Data**: Reduce API call frequency
4. **Monitor Proactively**: Track performance metrics continuously
5. **Strategic Server Placement**: Position servers near trading venues

#### Key Performance Considerations

- **Sub-100ms Latency**: May require additional data centers
- **Provider vs Customer**: Latency depends on both infrastructure setups
- **Competitive Edge**: "Even the smallest delays can make a big difference"
- **Environment-Specific**: Optimization strategies vary by use case

**Target Audience**: Technical professionals, system administrators, developers working with high-frequency market data applications

---

## Performance Testing Guide

### Overview
Comprehensive guide for testing and optimizing CoinAPI performance across different interfaces (REST, WebSocket, FIX) with detailed methodologies and best practices.

### Performance Testing Methodologies

#### REST API Performance Testing
**Tool**: curl commands on Linux
**Measured Metrics**:
- Name lookup time
- Connection time
- Total request time
- Detailed timing breakdowns

**Implementation**: Uses curl with timing parameters to benchmark HTTP request performance

#### WebSocket API Performance Testing
**Requirements**: .NET 8.0+
**Captured Metrics**:
- Message counts
- Latency measurements
- Connection performance

**Approach**: Multiple connections for comprehensive testing
**Tools**: GitHub repositories with client applications provided

#### FIX Protocol Testing
**Engine**: QuickFix
**Capabilities**:
- Session management
- Data subscription
- Message processing
- Protocol-specific performance metrics

### Good Performance Testing Practices

#### Key Recommendations

##### Message Handling
- **Fetch Messages Quickly**: Minimize retrieval delays
- **Separate Processing Threads**: Decouple data acquisition from processing
- **Strategic Multithreading**: Implement parallel processing efficiently

##### Connection Management
- **Multiple Connections**: Distribute load across connections
- **Thread Utilization**: "If latency increases, split data acquisition across multiple connections to utilize more threads effectively"
- **Load Distribution**: Balance traffic across available resources

#### Testing Strategy
1. **Baseline Measurement**: Establish performance benchmarks
2. **Load Testing**: Test under various traffic conditions  
3. **Latency Monitoring**: Track response times continuously
4. **Scalability Testing**: Verify performance with increased load

#### Tools and Resources
- **GitHub Repositories**: WebSocket and FIX client applications
- **Configuration Guides**: Detailed setup instructions
- **Testing Scripts**: Pre-built performance testing utilities

---

## JSON-RPC API

### Overview
Lightweight JSON-RPC 2.0 protocol interface providing flexible access to CoinAPI market data resources.

### Connection Details
- **Endpoint**: `https://rest.coinapi.io/jsonrpc`
- **Protocol**: JSON-RPC 2.0
- **Authentication**: API key required

### Request Structure
**Standard JSON-RPC 2.0 Format**:
```json
{
  "jsonrpc": "2.0",
  "method": "v1/resource",
  "params": [],
  "id": "tracking-id"
}
```

### Available Methods

#### Get Exchanges
- **Method**: `v1/exchanges`
- **Purpose**: Retrieve list of cryptocurrency exchanges
- **Response**: Exchange metadata including names, IDs, and details

#### Get Exchange Rates
- **Method**: `v1/exchangerate/BTC`
- **Purpose**: Retrieve current exchange rates for specified asset
- **Example**: Bitcoin exchange rates across different quote currencies

#### Get Symbols
- **Method**: `v1/symbols`
- **Purpose**: Retrieve trading symbols with filtering support
- **Filters**: By exchange, symbol, or asset
- **Response**: Symbol details and trading pair information

### Error Handling

#### Standard HTTP Errors
- **400 Error**: Invalid request format or parameters
- **404 Error**: Resource not found or unavailable
- **Authentication Errors**: Invalid or missing API key

#### JSON-RPC Error Format
```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32602,
    "message": "Invalid params"
  },
  "id": "tracking-id"
}
```

### Key Benefits

#### Protocol Advantages
- **Lightweight**: Minimal overhead compared to REST
- **Flexible Resource Access**: Single endpoint for multiple operations
- **Standard Compliance**: Full JSON-RPC 2.0 compatibility
- **REST Compatibility**: Methods map to existing REST endpoints

#### Use Cases
- **Batch Operations**: Multiple requests in single call
- **Legacy System Integration**: JSON-RPC protocol compatibility
- **Simplified Architecture**: Single endpoint for all operations
- **Custom Client Implementation**: Flexible method calling

**Implementation Note**: Compatible with all REST API endpoints through JSON-RPC method mapping

---

## Model Context Protocol (MCP) Servers

### Overview & Purpose

**Model Context Protocol (MCP) Servers** provide a unified interface for accessing multiple APIs through a single, standardized endpoint, transforming traditional HTTP APIs into self-describing JSON-Schema functions.

#### Core MCP Capabilities
- **API Consolidation**: Single endpoint for accessing multiple services
- **Schema Validation**: Automatic JSON-Schema validation for API requests
- **Autonomous Discovery**: Agents can discover and validate API functionality
- **Zero-Day Coverage**: Automatic support for new API routes
- **Unified Authentication**: Consistent authentication across multiple services

#### Key Benefits for Developers
- **Simplified Integration**: Reduce API integration complexity
- **Reduced Boilerplate**: Eliminate repetitive API integration code
- **Accelerated Development**: Speed up development cycles
- **Consistent Interface**: Standardized access to heterogeneous APIs
- **Client/Server Consolidation**: Unified management approach

### MCP Endpoint Architecture

#### Primary Endpoint Variants

##### 1. HTTP Streaming Endpoint (Bidirectional)
- **URL**: `https://mcp.api.apibricks.io/mcp`
- **Type**: HTTP streaming with bidirectional communication
- **Use Case**: Real-time, interactive API access with response streaming
- **Features**: Full duplex communication, real-time updates

##### 2. Server-Sent Events Endpoint (One-Way)
- **URL**: `https://mcp.api.apibricks.io/sse`
- **Type**: Server-Sent Events for one-way updates
- **Use Case**: Real-time notifications and data streaming
- **Features**: Push notifications, live data feeds

#### Composite MCP Endpoint
- **URL**: `https://mcp.api.apibricks.io/mcp`
- **Purpose**: Aggregates all individual server endpoints into single access point
- **Benefit**: "Treat a heterogeneous fleet of APIs as a single, extensible RPC surface"

### Supported API Services

#### Financial Data Services
- **FinFeedAPI**: SEC filings, stock data, foreign exchange
- **CoinAPI**: Comprehensive cryptocurrency market data
  - Market Data API endpoints
  - Exchange rates and timeseries data
  - Indexes API (PRIMKT, VWAP, CAPIVIX)
  - Real-time WebSocket streaming
  - Historical data access

#### CoinAPI Integration Benefits
- **Unified Access**: Single MCP endpoint for all CoinAPI functionality
- **Schema Validation**: Automatic validation of CoinAPI requests
- **Simplified Authentication**: Consistent auth across all endpoints
- **Discovery**: Autonomous agents can explore CoinAPI capabilities
- **Error Handling**: Standardized error responses and validation

### MCP Implementation Examples

#### Basic MCP Request
```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "coinapi_exchange_rate",
    "arguments": {
      "base_asset": "BTC",
      "quote_asset": "USD"
    }
  },
  "id": "request_1"
}
```

#### MCP Response Format
```json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Current BTC/USD rate: 43,250.75"
      }
    ],
    "isError": false
  },
  "id": "request_1"
}
```

### Technical Architecture

#### JSON-Schema Function Transformation
- **Input**: Traditional HTTP API endpoints
- **Process**: Transform to self-describing JSON-Schema functions
- **Output**: Discoverable, validatable API functions
- **Benefit**: Autonomous agents can understand and use APIs without manual configuration

#### Validation Framework
- **Request Validation**: Automatic parameter validation before API calls
- **Response Validation**: Ensure API responses meet expected schema
- **Error Handling**: Standardized error messages and codes
- **Type Safety**: Strong typing through JSON Schema definitions

### Use Cases & Applications

#### Autonomous Agent Integration
- **AI Assistant**: Agents can discover and use CoinAPI functions autonomously
- **Trading Bots**: Automated trading systems with unified API access
- **Portfolio Management**: Consolidated access to market data and metrics
- **Research Tools**: Streamlined data access for analysis applications

#### Development Workflow Benefits
- **Rapid Prototyping**: Quick API integration without boilerplate
- **Consistent Interface**: Same patterns across different APIs
- **Automatic Documentation**: Self-describing functions with schemas
- **Testing Simplification**: Unified testing approach for multiple APIs

#### Enterprise Integration
- **Microservices**: Unified API gateway for distributed systems
- **Multi-Vendor APIs**: Consistent access to different service providers
- **Legacy System Integration**: Modernize API access patterns
- **Compliance**: Standardized validation and audit trails

### Getting Started with MCP

#### Prerequisites
- Understanding of JSON-RPC 2.0 protocol
- API authentication credentials for desired services
- Client capable of HTTP streaming or Server-Sent Events

#### Basic Integration Steps
1. **Connect**: Establish connection to MCP endpoint
2. **Discover**: Query available tools and their schemas
3. **Validate**: Use JSON Schema validation for requests
4. **Execute**: Call API functions through MCP interface
5. **Handle**: Process standardized responses and errors

#### Best Practices
- **Schema Validation**: Always validate requests against provided schemas
- **Error Handling**: Implement robust error handling for API failures
- **Authentication**: Secure API key management and rotation
- **Rate Limiting**: Respect underlying API rate limits
- **Monitoring**: Track API usage and performance metrics

**Strategic Value**: MCP Servers enable treating "a heterogeneous fleet of APIs as a single, extensible RPC surface—simplifying integration, reducing boilerplate, and speeding up development cycles."

---

*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added comprehensive authentication, SDK support, REST API framework, WebSocket documentation, and Model Context Protocol (MCP) Servers for unified API access*

---

## Flat Files API

### Overview & Architecture

**Flat Files API** provides comprehensive historical cryptocurrency market data via S3-compatible access patterns, enabling bulk data retrieval and analysis.

**Core Capabilities:**
- **Historical Data Access**: Complete cryptocurrency market data in flat file format
- **S3-Compatible API**: Industry-standard access patterns and tools
- **Data Types Available**: Quotes, Trades, Limit Order Book, OHLCV (coming soon)
- **Automated Delivery**: Push API for scheduled data delivery to designated S3 buckets

**File Organization Structure:**
```
/T-[DATATYPE]/D-YYYYMMDD/E-[EXCHANGE]/FILENAME.csv.gz
```

**Technical Standards:**
- **Variable Naming**: Snake_case convention
- **Asset Codes**: ISO 4217 compliance for fiat currencies
- **Time Format**: ISO 8601 standard timestamps
- **Precision**: Maximum 19 digits (9 decimal places)
- **Compression**: Gzip compression for efficient storage

### Data Types & File Structures

#### Quotes Data Files
- **File Path**: `T-QUOTES/D-YYYYMMDD/E-[EXCHANGE]/IDDI-[ID]+SC-[SYMBOL]+S-[EXCHANGE_SYMBOL].csv.gz`
- **Key Fields**:
  - `id_site_coinapi`: UUID of data reception site
  - `time_exchange`: Exchange UTC timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_px/ask_sx`: Best ask price and volume
  - `bid_px/bid_sx`: Best bid price and volume
- **Applications**: Spread analysis, liquidity monitoring, market timing

#### Trades Data Files
- **Structure**: Individual transaction records in chronological order
- **Key Fields**:
  - `time_exchange/time_coinapi`: Dual timestamp tracking
  - `guid`: Unique trade identifier for deduplication
  - `price`: Transaction execution price
  - `base_amount`: Asset quantity traded
  - `taker_side`: Aggressor side (BUY/SELL/ESTIMATED)
- **Applications**: Volume analysis, price discovery, execution simulation

#### Full Limit Order Book Files
- **Update Types**: ADD, SUB, MATCH, SET, DELETE, SNAPSHOT
- **Key Fields**:
  - `is_buy`: Boolean for bid (1) or ask (0) side
  - `update_type`: Order book change classification
  - `entry_px/entry_sx`: Price and volume of update
  - `order_id`: Optional order identifier for tracking
- **Applications**: Market microstructure analysis, order flow modeling

### S3 API Integration

#### Authentication Framework
- **Access Key ID**: Your CoinAPI key
- **Secret Access Key**: "coinapi" (fixed value)
- **Signature Support**: AWS Signature Version 2 and 4
- **Endpoint**: `s3.flatfiles.coinapi.io`
- **Region**: `us-east-1`

#### Supported Operations

##### List Objects (GET)
```
GET /bucket/?prefix={prefix}
```
- **Headers**: `Accept: application/xml`
- **Filtering**: Prefix-based object filtering
- **Response**: XML-formatted object listings

##### Download Object (GET)
```
GET /bucket/{Key}
```
- **Authentication**: Authorization header with CoinAPI key
- **Protocol**: HTTPS recommended for production
- **Error Handling**: Standard HTTP status codes with XML responses

**Compatible Tools:**
- **AWS CLI**: Standard AWS command-line interface
- **S3 Browser**: GUI-based S3 management
- **SDK Libraries**: Multi-language support (Python boto3, JavaScript AWS SDK, etc.)

### Multi-Language SDK Integration

**Supported Programming Languages:**
- **JavaScript (Node.js)**: AWS SDK v3 with custom endpoint configuration
- **Python**: boto3 client with CoinAPI credentials
- **Java**: AWS SDK for Java with S3 client setup
- **C# (.NET)**: AWS SDK for .NET integration
- **Ruby**: AWS SDK for Ruby implementation
- **PHP**: AWS SDK for PHP integration
- **Go**: AWS SDK for Go with S3 service
- **Swift, Rust, SAP ABAP**: Additional language support available

**Standard Configuration Pattern:**
```javascript
// Example: JavaScript SDK
const s3Client = new S3Client({
  endpoint: "https://s3.flatfiles.coinapi.io",
  region: "us-east-1",
  credentials: {
    accessKeyId: "YOUR_COINAPI_KEY",
    secretAccessKey: "coinapi"
  }
});
```

### Snowflake Data Warehouse Integration

#### Available Datasets
- **Assets**: Cryptocurrency and token metadata
- **Exchange Rates**: Historical price relationships
- **Index Data**: Market index calculations and values
- **Order Books**: Market depth and liquidity data
- **Quotes**: Best bid/ask historical records
- **OHLCV**: Open, High, Low, Close, Volume data
- **Trades**: Transaction execution records

#### Integration Benefits
- **Enhanced Query Performance**: SQL-based data analysis
- **Scalability**: Cloud-native data warehouse capabilities
- **Security**: Enterprise-grade data protection
- **Transformation**: Advanced data processing and analytics
- **Integration**: Seamless connection with existing workflows

**Access Method:**
- Requires existing Snowflake account
- Contact CoinAPI Account Executive for dataset access
- Sample files available in Snowflake Marketplace

**Dataset Examples:**

##### Assets Table
- **Purpose**: Complete cryptocurrency asset directory
- **Fields**: Asset identifiers, names, types, supply data, chain addresses
- **Use Cases**: Portfolio construction, asset classification, regulatory compliance

##### Exchange Rates Table
- **Purpose**: Historical cross-asset pricing data
- **Fields**: Base/quote pairs, timestamps, calculated rates
- **Use Cases**: Portfolio valuation, historical analysis, risk modeling

##### Index Data Table
- **Purpose**: Market benchmark and index values
- **Fields**: Index identifiers, calculation methodologies, historical values
- **Use Cases**: Performance benchmarking, market analysis, investment strategies

##### Order Books Table
- **Purpose**: Historical market depth snapshots
- **Fields**: Bid/ask levels, timestamps, liquidity metrics
- **Use Cases**: Market microstructure research, slippage analysis, trading strategy optimization

##### Quotes Table
- **Purpose**: Best bid/ask price history
- **Fields**: Symbol identifiers, timestamps, price/size data
- **Use Cases**: Spread analysis, market timing, execution quality assessment

##### OHLCV Table
- **Purpose**: Candlestick and volume data
- **Fields**: Time periods, OHLC prices, trading volumes, transaction counts
- **Use Cases**: Technical analysis, pattern recognition, volatility studies

##### Trades Table
- **Purpose**: Individual transaction records
- **Fields**: Execution details, prices, volumes, taker sides
- **Use Cases**: Transaction cost analysis, market impact studies, execution analytics

### Push API & Order Management

#### Push API Framework
- **Automated Delivery**: Scheduled data delivery to customer S3 buckets
- **Authentication**: API key-based access control
- **Version**: v1 implementation with MIT License

#### Order Management Endpoints

##### Price Calculation
**Endpoint**: `POST /api/push-orders/calculate-price`

**Required Parameters**:
- `id` (UUID): Unique order identifier
- `idOrganization` (UUID): Organization identifier
- `exchange` (string): Exchange identifier (max 255 chars)

**Optional Parameters**:
- `symbols` (string): Symbol filtering
- `schema` (string): Data schema specification (max 255 chars)
- `date_from` (date-time): Historical data start date
- `date_to` (date-time): Historical data end date
- `priceHistorical` (double): Historical data pricing
- `priceDailyUpdates` (double): Daily updates pricing
- `encoding` (string): File encoding format (max 50 chars)
- `compression` (string): Compression method (max 50 chars)

**Purpose**: Estimate costs for data orders before creation

##### Order Creation
**Endpoint**: `POST /api/push-orders`

**Configuration Options**:
- Exchange selection with symbol filtering
- Custom date ranges for historical data
- Delivery format options (encoding/compression)
- Data storage endpoint configuration

**Management Features**:
- Order tracking with unique IDs and organization mapping
- Status monitoring and updates
- Integration with data storage endpoints

##### Order Administration
- **List Orders**: `GET /api/push-orders` - View all active orders
- **Delete Order**: `DELETE /api/push-orders/{id}` - Cancel specific orders
- **Account Balance**: `GET /api/push-orders/account-balance` - Monitor available credits

#### Pricing Model

**Credit-Based System**:
- Usage credits consumed based on data volume
- **Example Pricing**: Trades data at $3.00 per GB
- **Calculation**: `Size in GB × Price per GB = Total Order Cost`
- **Estimation**: Use calculation endpoint before order creation

**Cost Factors**:
- Data type (TRADES, QUOTES, ORDERBOOKS)
- Exchange coverage
- Historical date range
- Daily update frequency
- File format and compression options

#### Data Storage Management

##### Datastore Configuration
- **List Types**: `GET /api/metadata/datastore-types` - Available storage options
- **List Endpoints**: `GET /api/metadata/datastore-endpoints` - Configured destinations
- **Add Endpoint**: `POST /api/metadata/datastore-endpoints` - Configure new storage
- **Delete Endpoint**: `DELETE /api/metadata/datastore-endpoints/{id}` - Remove storage

**Supported Storage Types**:
- Customer S3 buckets
- Cloud data warehouse connections
- Custom endpoint configurations
- Automated delivery schedules

#### Metadata Endpoints

##### Exchange Information
- **List All Exchanges**: `GET /api/metadata/list-all-exchanges`
- **Exchange by ID**: `GET /api/metadata/list-all-exchanges-by-exchange-id`
- **Available Schemas**: `GET /api/metadata/list-all-schemas`
- **Exchange Symbols**: `GET /api/metadata/list-of-symbols-for-the-exchange`

**Integration Benefits**:
- Dynamic exchange discovery
- Schema validation and selection
- Symbol filtering capabilities
- Automated metadata updates

#### Estimation Guide

**Python Script Features**:
- **Size Calculation**: Accurate data volume estimation
- **Cost Estimation**: Pricing calculation before order creation
- **Filtering Options**: Exchange, date range, data types, symbols
- **Report Generation**: Detailed breakdown of costs and volumes

**Estimation Variables**:
```python
# Key parameters for estimation
API_KEY = "your_coinapi_key"
EXCHANGE_ID = "BINANCE"  # Target exchange
DATE_FROM = "2023-01-01"
DATE_TO = "2023-01-31"
DATA_TYPES = ["TRADES", "QUOTES", "ORDERBOOKS"]
SYMBOLS = ["BTC_USD", "ETH_USD"]  # Optional filtering
```

**Pricing Examples**:
- **TRADES Data**: $3.00 per GB
- **QUOTES Data**: Variable pricing per GB
- **ORDERBOOKS Data**: Variable pricing per GB
- **Volume Calculation**: Size in GB × Price per GB = Total Cost

**Best Practices**:
1. Use estimation script before creating large orders
2. Filter by specific symbols to reduce costs
3. Optimize date ranges for required analysis periods
4. Consider compression options to reduce data size
5. Contact sales team for custom pricing arrangements

---

## Indexes API

### Overview & Index Types

**CoinAPI Indexes** provide transparent, accurate, and reliable benchmarks for the digital asset market as an independent index provider.

#### Available Index Types

**1. Principal Market Price Index (PRIMKT)**
- **Purpose**: Representative price from primary market sources
- **Methodology**: Identifies and weights primary trading venues for each asset
- **Use Cases**: Fair value pricing, portfolio benchmarking, regulatory compliance

**2. Volume Weighted Average Price Index (VWAP)**
- **Purpose**: Volume-weighted pricing across multiple exchanges
- **Methodology**: Weights prices by actual trading volume over time periods
- **Use Cases**: Execution quality measurement, algorithmic trading benchmarks

**3. Volatility Index (CAPIVIX)**
- **Purpose**: Market volatility measurement and forecasting
- **Methodology**: Calculates implied volatility from options and derivatives data
- **Use Cases**: Risk management, volatility trading strategies, market sentiment analysis

#### Index Access Methods
- **REST API**: Standard HTTP endpoints for index data retrieval
- **WebSocket API**: Real-time index value streaming
- **Historical Data**: Time-series index values for backtesting and analysis

#### Key Features
- **Transparency**: Open methodology and calculation documentation
- **Reliability**: Robust data quality controls and validation
- **Comprehensive Coverage**: Multiple index types for different market aspects
- **Real-time Updates**: Live index calculations with minimal latency

---

## Advanced Trading Infrastructure

### High-Frequency Trading (HFT) Strategies

**Core HFT Strategy Categories:**

#### 1. Statistical Arbitrage
- **Model-Based Approach**: Uses statistical models to identify price discrepancies
- **Correlation Trading**: Exploits relationships between correlated cryptocurrencies
- **Predictive Execution**: Based on historical data patterns and mean reversion
- **Risk Management**: Sophisticated position sizing and hedging strategies

**Implementation Requirements:**
- Multi-asset correlation analysis
- Real-time statistical model execution
- Dynamic position rebalancing
- Risk-adjusted return optimization

#### 2. Cross-Exchange Arbitrage
- **Speed Advantage**: Capitalizes on execution speed differences between venues
- **Price Discrepancy**: Profits from momentary price variations across platforms
- **Infrastructure Requirements**: Direct connections to multiple exchanges
- **Latency Optimization**: Sub-millisecond execution capabilities

**Technical Implementation:**
- Simultaneous multi-exchange connectivity
- Price difference detection algorithms
- Automated arbitrage execution
- Transaction cost optimization

#### 3. Market Making Strategies
- **Bid-Ask Spread**: Simultaneous buy/sell order placement for spread capture
- **Liquidity Provision**: Continuous market presence for trading opportunities
- **Inventory Management**: Dynamic position balancing across assets
- **Risk Control**: Real-time exposure monitoring and adjustment

**Operational Framework:**
- Order book depth analysis
- Dynamic spread adjustment
- Inventory risk management
- Regulatory compliance monitoring

#### 4. Momentum Trading
- **Sentiment Exploitation**: Leverages current market momentum and news events
- **Volume Analysis**: High trading volume and volatility pattern recognition
- **Event-Driven**: Trading around significant market catalysts and announcements
- **Trend Following**: Algorithmic pattern recognition for directional trades

#### 5. Scalping Operations
- **High-Frequency Execution**: "Dozens or even hundreds of trades daily"
- **Micro-Profit Accumulation**: Small gains from minute market inefficiencies
- **Order Flow Analysis**: Tick-by-tick market microstructure examination
- **Rapid Position Turnover**: Minimal holding periods for risk reduction

### Low-Latency Trading Infrastructure

#### Performance Benefits

##### Execution Speed Advantages
- **Slippage Reduction**: Minimizes adverse price movements during order execution
- **Optimal Price Capture**: "Secure trades at desired prices before market conditions shift"
- **Position Management**: Rapid entry and exit capabilities for dynamic strategies
- **Order Flow Priority**: Faster execution in competitive order queues

##### Market Making Optimization
- **Efficient Order Management**: "Efficient order placement and cancellation"
- **Large Volume Handling**: Process significant trade volumes without market impact
- **Spread Maintenance**: Tighter bid-ask spreads for improved profitability
- **Inventory Balancing**: Real-time position adjustments based on market flow

##### Algorithmic Trading Enhancement
- **Real-Time Responsiveness**: "Real-time reaction to market changes"
- **Complex Strategy Support**: Advanced algorithmic implementation capabilities
- **Automated Execution**: Trading bots with sophisticated conditional logic
- **Market Adaptation**: Dynamic strategy adjustment based on market conditions

##### Risk Management Benefits
- **Adverse Movement Protection**: Rapid response to unfavorable price changes
- **Position Adjustment**: Quick rebalancing of exposure across assets
- **Stop-Loss Efficiency**: Immediate execution of risk management orders
- **Volatility Response**: Fast reaction to sudden market disruptions

#### Technical Infrastructure Components
- **Sub-Millisecond Accuracy**: Precise timestamp and execution tracking
- **High-Speed Connectivity**: Dedicated network infrastructure for trading
- **Advanced Computing**: Powerful hardware for complex calculations
- **Unified Data Access**: Standardized APIs across multiple exchanges
- **Sophisticated Algorithms**: Purpose-built trading logic and execution engines

> **Core Principle**: "Time is money" - every millisecond counts in cryptocurrency trading

### Protocol Comparison: Performance Hierarchy

#### Latency Performance Ranking
```
FIX API < WebSocket < REST API
```

#### FIX API Specifications
- **Protocol Type**: Specialized FIX (Financial Information eXchange) protocol
- **Connection State**: Stateful, persistent connections
- **Message Format**: Tag-value structured messages for financial data
- **Performance**: Optimized for high-frequency trading operations
- **Use Cases**: 
  - Direct market access (DMA)
  - Complex order types and conditions
  - Institutional trading platforms
  - Ultra-low latency execution

#### WebSocket API Specifications
- **Protocol Type**: Real-time bidirectional communication
- **Connection State**: Persistent, streaming connections
- **Message Format**: JSON-based structured data
- **Performance**: Real-time with minimal latency
- **Use Cases**:
  - Live market data streaming
  - Real-time price monitoring
  - Trading bot integration
  - Portfolio tracking applications

#### REST API Specifications
- **Protocol Type**: HTTP/HTTPS standard web protocols
- **Connection State**: Stateless, request-response pattern
- **Message Format**: JSON/XML structured data
- **Performance**: Universal implementation with moderate latency
- **Use Cases**:
  - Historical data retrieval and analysis
  - Basic market data and order operations
  - Web and mobile application integration
  - General-purpose trading applications

### Crypto Market Making Framework

#### Strategic Market Making Approaches

##### Liquidity Provision Services
- **Continuous Opportunity Creation**: "Always an opportunity to sell assets or trade crypto assets at a fair price"
- **Spread Optimization**: Maintain competitive bid-ask spreads across markets
- **Volume Facilitation**: Enable large transactions without significant price impact
- **Market Stability**: Reduce volatility through consistent presence

##### Revenue Generation Models

**Spread-Based Income:**
- **Bid-Ask Arbitrage**: Profit from buying at bid and selling at ask
- **Volume Scaling**: Increased profits through high transaction frequency
- **Risk-Neutral Positioning**: Balanced inventory management

**Exchange Incentive Programs:**
- **Rebate Systems**: Payments from exchanges for providing liquidity
- **Volume Tiers**: Escalating incentive structures for high-frequency makers
- **Competitive Advantages**: Reduced trading costs through maker programs

**Advanced Strategy Integration:**
- **Cross-Exchange Arbitrage**: Simultaneous market making across venues
- **Derivatives Hedging**: Risk management through futures and options
- **High-Frequency Optimization**: Algorithmic execution for maximum efficiency

#### Operational Challenges

##### Market Structure Issues
- **Low Volume Assets**: Difficulty providing liquidity in niche cryptocurrencies
- **Supply-Demand Imbalances**: Managing inventory in trending markets
- **Exchange Fragmentation**: Coordination across multiple trading venues
- **Regulatory Uncertainty**: Compliance across different jurisdictions

##### Technical Implementation
- **Multi-Exchange Integration**: Reliable connections to diverse platforms
- **24/7 Operations**: Continuous asset management and monitoring
- **Automated Systems**: Sophisticated trading algorithms and risk controls
- **High-Speed Infrastructure**: Low-latency execution platforms

#### Compliance and Risk Management
- **Regulatory Navigation**: Cross-market compliance requirements
- **Manipulation Prevention**: Avoiding predatory trading practices
- **Documentation Standards**: Comprehensive audit trails and reporting
- **Activity Monitoring**: Real-time surveillance of trading patterns

> **Strategic Role**: Market makers create stability and efficiency in volatile cryptocurrency markets through professional liquidity provision.

### Infrastructure Requirements

#### Technical Prerequisites
- **Multi-Exchange Connectivity**: Direct API connections to major venues
- **Smart Order Routing**: Intelligent execution across fragmented liquidity
- **Real-Time Data Access**: Sub-millisecond market data feeds
- **Historical Data**: Comprehensive backtesting and strategy validation
- **Risk Management**: Real-time position and exposure monitoring

#### Crypto Market Characteristics
- **24/7 Trading**: Continuous market operations across global timezones
- **High Volatility**: Extreme price movements creating opportunities and risks
- **Market Fragmentation**: Liquidity distributed across numerous exchanges
- **News Sensitivity**: Rapid price reactions to technological developments

#### Implementation Guidelines
- **Historical Analysis**: REST API for data retrieval and research
- **Real-Time Monitoring**: WebSocket for streaming market data
- **Simple Trading**: REST API for basic order management
- **Professional Trading**: FIX API for advanced high-frequency operations

**Selection Criteria:**
- Use REST API for analysis and general applications
- Use WebSocket API for real-time data and monitoring
- Use FIX API for institutional and high-frequency trading

---

### WebSocket API V1

#### Connection Endpoints

##### Production Encrypted (wss://)
- **Global GeoDNS**: `wss://ws.coinapi.io/v1/` (auto-routes to nearest datacenter)
- **North/South America**: `wss://api-ncsa.coinapi.io/v1/`
- **Europe/Middle East/Africa**: `wss://api-emea.coinapi.io/v1/`
- **Asia Pacific**: `wss://api-apac.coinapi.io/v1/`

##### Production Unencrypted (ws://)
- Similar endpoints without encryption for each region

#### Connection Setup
1. **Establish WebSocket connection** to endpoint
2. **Send Hello message** with API key and subscriptions
3. **Handle heartbeat messages** (maintain connection)
4. **Process real-time data streams**

#### Subscription Management

##### Authentication & Initial Subscription (Hello Message)
```json
{
  "type": "hello",
  "apikey": "YOUR_API_KEY",
  "subscribe_data_type": ["trade", "quote"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}
```

##### Dynamic Subscription Management
- **Subscribe**: Add new subscriptions without removing existing ones
- **Unsubscribe**: Remove specific subscriptions
- **Hello**: Reset and establish new subscription scope

##### Subscription Filters
- **By Symbol ID**: Filter specific trading pairs
- **By Asset ID**: Filter by base/quote assets  
- **By Exchange ID**: Filter by specific exchanges
- **By Data Type**: Filter message types (trade, quote, book, etc.)

#### Message Types

##### Trades
- **Purpose**: Executed transaction data
- **Fields**: symbol_id, price, size, taker_side, time_exchange, time_coinapi
- **Example**:
```json
{
  "type": "trade",
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "sequence": 1234567,
  "time_exchange": "2023-12-15T10:30:00.000Z",
  "time_coinapi": "2023-12-15T10:30:00.123Z",
  "price": 45000.50,
  "size": 0.05,
  "taker_side": "BUY"
}
```

##### Quotes  
- **Purpose**: Best bid/ask price updates
- **Fields**: symbol_id, ask_price, ask_size, bid_price, bid_size
- **Note**: Sent on each update to best bid/ask levels

##### Order Book Messages
- **book5**: Order book (5 levels)
- **book20**: Order book (20 levels) 
- **book50**: Order book (50 levels)
- **book**: Full order book (L2)
- **Fields**: asks/bids arrays with price, size, and optional order IDs

##### OHLCV
- **Purpose**: Time-based trading period summaries
- **Fields**: open, high, low, close prices, volume, period information

##### Metadata Messages
- **asset**: Asset-specific information updates
- **exchange**: Trading platform details
- **symbol**: Trading pair metadata updates
- **exrate**: Cross-asset pricing information

##### System Messages
- **reconnect**: Server-side connection management notification
- **heartbeat**: Connection health monitoring (sent every second of silence)

#### Error Handling
- **Permanent errors**: Result in WebSocket connection closure
- **JSON-structured error messages**: Detailed error information
- **Automatic reconnection**: Recommended for production systems

#### Performance Recommendations
- Use **asynchronous processing** to handle high-volume streams
- Ensure **sufficient bandwidth** for data throughput
- Implement **efficient message parsing** strategies
- Use **data buffering** mechanisms (default: 131,072 message queue)

---

### WebSocket DS (Data Stream) API

#### Purpose
Direct connection to exchange data streams with exchange-specific symbol formats and reduced latency.

#### Connection Endpoints

##### Encrypted (wss://)
- **Format**: `wss://lowercase-exchange-name.ws-ds.md.coinapi.io/`
- **Example**: `wss://coinbase.ws-ds.md.coinapi.io/`

##### Non-Encrypted (ws://)
- **Format**: `ws://lowercase-exchange-name.ws-ds.md.coinapi.io/`

#### Key Differences from V1
- **Exchange-specific connections**: Direct connection to individual exchanges
- **Native symbol formats**: Can use exchange-specific symbol identifiers
- **Reduced latency**: Direct data streaming without normalization layer
- **Exchange-specific message formats**: Maintains original exchange message structure

#### Subscription Management
Same as V1 API:
- **Hello**: Reset subscription scope
- **Subscribe**: Add subscriptions
- **Unsubscribe**: Remove subscriptions

#### Supported Data Types
- **Trade**: Executed transactions with exchange-specific details
- **Quote**: Best bid/ask updates
- **Book/Book5/Book20/Book50**: Order book snapshots at different depth levels
- **L3 Order Book**: Order-by-order data with ADD/UPDATE/DELETE operations

#### Message Types
Similar to V1 but with exchange-specific formatting:
- **Trades**: Include exchange-specific taker sides (BUY, SELL, ESTIMATED, UNKNOWN)
- **Quotes**: Exchange-native bid/ask formatting
- **Order Books**: Exchange-specific order book structures
- **L3 Messages**: Include order IDs and update types (ADD, UPDATE, DELETE)

#### Unique Features
- **Exchange symbol compatibility**: Use original exchange symbol formats
- **Asset pair filtering**: Filter by specific trading pairs
- **Configurable update frequency**: Adjust message rates
- **Enhanced sequence tracking**: Per-message-type sequence numbers

**Testing Tools**: wscat (npm), sandy WebSocket client

---

## Data Quality & Calculation

### Exchange Rate Calculation
- Uses **Volume Weighted Average Price (VWAP-24H)**
- **Sources**: Quotes, trades, metadata from multiple exchanges
- **Filtering**:
  - SPOT symbols only
  - Exclude non-legitimate sources
  - Discard excessive spread quotes
  - Weight midpoint prices by volume
  - 1-second update frequency
  - Outlier removal (3 sigma range)

### Data Conventions
- **Naming**: snake_case for variables
- **Currency**: ISO 4217 for fiat codes
- **Precision**: Max 19 digits (9 decimal places)
- **Timezone**: UTC for all timestamps
- **Standards**: ISO compliance for time/asset codes

---

## Additional REST API Endpoints

### Trades API (Transaction Data)
**Base Endpoint**: `/v1/trades/`

**Purpose**: Provides access to executed trade transaction data across cryptocurrency markets with detailed trade information including price, size, and taker side.

#### Historical Trade Data

##### Historical Data
- **URL**: `GET /v1/trades/:symbol_id/history`
- **Required Parameters**:
  - `symbol_id` (string): Trading pair identifier
- **Optional Parameters**:
  - `date` (string): ISO 8601 date for specific day
  - `time_start` (string): Start time (must be same day as time_end)
  - `time_end` (string): End time (must be same day as time_start)
  - `limit` (int): Number of trades (default 100, max 100,000)
  - `include_id` (boolean): Include additional exchange trade identifiers
- **Response Fields**:
  - `symbol_id`: Trading symbol
  - `time_exchange`: Trade time on exchange
  - `time_coinapi`: CoinAPI receive time
  - `uuid`: Unique trade identifier
  - `price`: Transaction price
  - `size`: Base asset amount traded
  - `taker_side`: Transaction side (BUY/SELL/UNKNOWN)
  - `id_trade`: Exchange trade identifier (if include_id=true)
  - `id_order_maker`: Maker order identifier (if available)
  - `id_order_taker`: Taker order identifier (if available)
- **Important Notes**:
  - Provides intraday data only
  - `time_start` and `time_end` must be from same day
  - Returns trades in **time ascending order**
- **Example Response**:
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2013-09-28T22:40:50Z",
  "time_coinapi": "2017-03-18T22:42:21Z",
  "uuid": "unique-uuid-string",
  "price": 770,
  "size": 0.05,
  "taker_side": "BUY"
}
```

#### Latest Trade Data

##### Latest Data (All Symbols)
- **URL**: `GET /v1/trades/latest`
- **Purpose**: Retrieve latest trades executed within the past minute
- **Optional Parameters**:
  - `filter_symbol_id` (string): Filter trades by symbol identifier
  - `include_id` (boolean): Include additional exchange trade identifier
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Fields**:
  - `symbol_id`: Trading symbol
  - `time_exchange`: Trade time on exchange
  - `time_coinapi`: Time trade received by CoinAPI
  - `uuid`: Unique trade identifier
  - `price`: Transaction price
  - `size`: Base asset amount traded
  - `taker_side`: Transaction side (BUY/SELL/UNKNOWN)
- **Key Characteristics**:
  - Returns trades in **time descending order**
  - Provides detailed trade execution information

##### Latest Data by Symbol ID
- **URL**: `GET /v1/trades/:symbol_id/latest`
- **Purpose**: Get latest trades executed up to 1 minute ago for specific symbol
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier from Metadata
- **Optional Parameters**:
  - `limit` (int): Items to return (default 100, max 100,000)
  - `include_id` (boolean): Include additional exchange trade identifier
- **Response Fields**: Same as latest data endpoint
- **Example Response**:
```json
[
  {
    "symbol_id": "BITSTAMP_SPOT_BTC_USD",
    "time_exchange": "2013-09-28T22:40:50.0000000Z",
    "time_coinapi": "2017-03-18T22:42:21.0000000Z",
    "uuid": "unique-uuid-string",
    "price": 770,
    "size": 0.05,
    "taker_side": "BUY"
  }
]
```

**Key Features**:
- Historical trades in time ascending order
- Latest trades (up to 1 minute ago) in descending order
- Real-time trade transaction data
- Detailed execution information including taker side
- Support for additional exchange identifiers

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---
- Real-time trade transaction data

---

### Quotes API (Level 1 Market Data)
**Base Endpoint**: `/v1/quotes/`

**Purpose**: Provides access to passive Level 1 market data, delivering essential bid/ask pricing information across cryptocurrency markets.

#### Current Quote Data

##### Current Data (All Symbols)
- **URL**: `GET /v1/quotes/current`
- **Purpose**: Retrieve current quotes for all or specific symbols
- **Optional Parameters**:
  - `filter_symbol_id` (string): Filter by symbol identifier
- **Response Fields**:
  - `symbol_id`: Trading symbol identifier
  - `time_exchange`: Exchange timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_price`: Best asking price (nullable)
  - `ask_size`: Volume at best ask (nullable)
  - `bid_price`: Best bidding price (nullable)
  - `bid_size`: Volume at best bid (nullable)
  - `last_trade`: Detailed last trade object (time, price, size, taker_side)
- **Note**: When requesting a specific symbol, response is not wrapped in a JSON array
- **Example Response**:
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "ask_price": 770,
  "ask_size": 3252,
  "bid_price": 760,
  "bid_size": 124,
  "last_trade": {
    "time": "2017-03-18T22:42:21Z",
    "price": 770,
    "size": 0.05,
    "taker_side": "SELL"
  }
}
```

##### Current Quotes for Specific Symbol
- **URL**: `GET /v1/quotes/:symbol_id/current`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier
- **Response Fields**: Same as current data endpoint
- **Note**: Returns single quote object (not array format)

#### Historical Quote Data

##### Historical Data
- **URL**: `GET /v1/quotes/:symbol_id/history`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier
- **Optional Parameters**:
  - `date` (string): ISO 8601 date for querying data
  - `time_start` (string): Start time (must be same day as time_end)
  - `time_end` (string): End time (must be same day as time_start)
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Fields**:
  - `symbol_id`: Symbol identifier
  - `time_exchange`: Exchange timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_price`: Ask price
  - `ask_size`: Ask size
  - `bid_price`: Bid price
  - `bid_size`: Bid size
- **Important Note**: For intraday data, `time_start` and `time_end` parameters must be from the same day
- **Example Response**:
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2013-09-28T22:40:50Z",
  "ask_price": 770,
  "bid_price": 760
}
```

#### Latest Quote Data

##### Latest Data (All Symbols)
- **URL**: `GET /v1/quotes/latest`
- **Purpose**: Retrieve latest quote updates within the past minute
- **Optional Parameters**:
  - `filter_symbol_id` (string): Filter results by symbol identifier
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Fields**:
  - `symbol_id`: Unique symbol identifier
  - `time_exchange`: Exchange timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_price`: Best asking price
  - `ask_size`: Volume at best ask
  - `bid_price`: Best bidding price
  - `bid_size`: Volume at best bid

##### Latest Quote Updates for Specific Symbol
- **URL**: `GET /v1/quotes/:symbol_id/latest`
- **Required Parameters**:
  - `symbol_id` (string): Symbol identifier from Metadata
- **Optional Parameters**:
  - `limit` (int): Items to return (default 100, max 100,000)
- **Response Fields**: Same as latest data endpoint
- **Example Response**:
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2013-09-28T22:40:50Z",
  "time_coinapi": "2017-03-18T22:42:21Z",
  "ask_price": 770,
  "ask_size": 3252,
  "bid_price": 760,
  "bid_size": 124
}
```

**Key Features**:
- Passive Level 1 market data
- Best bid/ask prices and sizes
- Time-sorted historical and latest data
- Sub-minute latency for current data

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

### Order Book
**Base Endpoint**: `/v1/orderbooks/`

#### Endpoints
- **Current Order Book**: `GET /v1/orderbooks/:symbol_id/current`
  - **Required Parameter**: `symbol_id` - Trading symbol identifier
  - **Optional Parameter**: `limit_levels` - Maximum number of order book levels
  - **Response Schema**:
    - `symbol_id`: Trading symbol identifier
    - `time_exchange`: Exchange timestamp
    - `time_coinapi`: CoinAPI receipt timestamp
    - `asks`: Array of sell orders with id, price, size
    - `bids`: Array of buy orders with id, price, size
  - **Example Response**:
    ```json
    {
      "symbol_id": "COINBASE_SPOT_BCH_USD",
      "time_exchange": "2020-08-27T10:28:35.6111130Z",
      "time_coinapi": "2020-08-27T10:28:35.6766461Z",
      "asks": [{"id": "unique_id", "price": 272.89, "size": 1}],
      "bids": [{"id": "unique_id", "price": 272.83, "size": 18}]
    }
    ```
- **Current Depth**: `GET /v1/orderbooks/current`
- **Historical Data**: `GET /v1/orderbooks/:symbol_id/history`
- **Latest Data**: `GET /v1/orderbooks/:symbol_id/latest`

**Features**:
- Charged: 1 request per 100 data points
- Multiple depth levels (5, 20, 50)
- Size may be 0 when unknown
- Merged order book and quote feeds

---

### Metrics V1 & V2
**Base Endpoint**: `/v1/metrics/` and `/v2/metrics/`

#### Current Metrics (V1)
- **Asset**: `GET /v1/metrics/asset/current`
  - **Required Parameters**:
    - `metric_id`: Metric identifier
    - `asset_id`: Asset identifier
  - **Optional Parameters**:
    - `asset_id_external`: External asset ID
    - `exchange_id`: Exchange identifier
  - **Response Schema**:
    - `entry_time`: Data point timestamp
    - `recv_time`: Receive timestamp
    - `exchange_id`: Exchange identifier (e.g., "DERIBIT")
    - `asset_id`: Asset identifier
    - `symbol_id`: Symbol identifier
    - `metric_id`: Metric ID (e.g., "DERIVATIVES_MARK_PRICE")
    - `value_decimal`: Numeric metric value
    - `value_text`: Text metric value (optional)
    - `value_time`: Timestamp value (optional)
- **Exchange**: `GET /v1/metrics/:exchange_id/current`
- **Symbol**: `GET /v1/metrics/:symbol_id/current`

#### Historical Metrics
- **Asset**: `GET /v1/metrics/:asset_id/history`
- **Exchange**: `GET /v1/metrics/:exchange_id/history`
- **Symbol**: `GET /v1/metrics/:symbol_id/history`

#### Supported Metrics
- **Trading Volume**
- **Market Depth**
- **Order Book Metrics**
- **Spread Analysis**
- **Market Cap**
- **Trading Fees**
- **Security Metrics**
- **User Activity Metrics**

---

## WebSocket API Comprehensive Framework

### WebSocket API Introduction

**WebSocket API** provides real-time, bidirectional communication for live cryptocurrency market data streaming through persistent connections.

#### Core WebSocket Characteristics
- **Real-Time Streaming**: Continuous data flow with minimal latency
- **Persistent Connections**: Single connection handles multiple data streams
- **Pub-Sub Model**: Subscribe to specific data types and symbols
- **RFC6455 v13 Compliant**: Industry-standard WebSocket protocol
- **Global Infrastructure**: Multiple regional endpoints for optimal performance

#### WebSocket vs REST API
| Feature | WebSocket | REST API |
|---------|-----------|----------|
| **Latency** | Ultra-low | Standard HTTP latency |
| **Data Flow** | Continuous streaming | Request-response |
| **Connection** | Persistent | Stateless |
| **Bandwidth** | Efficient for high-frequency | Higher overhead |
| **Use Case** | Real-time trading, live data | Historical analysis, occasional queries |

### WebSocket Endpoints

#### Production Endpoints (Secure - wss://)
- **GeoDNS (Recommended)**: `wss://ws.coinapi.io/v1/`
  - Automatic routing to nearest datacenter for optimal performance
- **Americas**: `wss://api-ncsa.coinapi.io/v1/`
  - North and South America optimization
- **Europe/Middle East/Africa**: `wss://api-emea.coinapi.io/v1/`
  - European and African market coverage  
- **Asia Pacific**: `wss://api-apac.coinapi.io/v1/`
  - Asian market optimization

#### Non-Encrypted Endpoints (ws://)
- Same regional URLs using `ws://` protocol for development/testing
- **Not Recommended for Production**: Use secure `wss://` endpoints

### Connection Management

#### Connection Establishment Flow
1. **Connect**: Establish WebSocket connection to chosen endpoint
2. **Authenticate**: Send Hello message with API key
3. **Subscribe**: Define data types and symbol filters  
4. **Maintain**: Handle ping/pong for connection health
5. **Process**: Receive and handle real-time data streams

#### Hello Message Authentication
```json
{
  "type": "hello",
  "apikey": "YOUR_API_KEY",
  "subscribe_data_type": ["trade", "quote", "book5"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD", "COINBASE_SPOT_ETH_USD"]
}
```

#### Connection Health Monitoring
- **Ping Messages**: Server sends ping every second of silence
- **Pong Response**: Client must respond with pong message
- **Timeout**: Connection closed if no pong response within 1 minute
- **Automatic Reconnection**: Implement reconnection logic for production systems

### WebSocket Message Types

#### Real-Time Trade Data
```json
{
  "type": "trade",
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2025-08-31T10:30:00.000Z",
  "time_coinapi": "2025-08-31T10:30:00.050Z",
  "price": 43265.75,
  "size": 0.25,
  "taker_side": "BUY",
  "sequence": 1234567
}
```

#### Quote Updates (Level 1)
```json
{
  "type": "quote", 
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2025-08-31T10:30:00.000Z",
  "time_coinapi": "2025-08-31T10:30:00.050Z",
  "ask_price": 43280.50,
  "ask_size": 1.25,
  "bid_price": 43250.75,
  "bid_size": 2.10,
  "sequence": 1234568
}
```

### Subscription Types
- **trade**: Real-time trade execution data with price, size, and taker side
- **quote**: Best bid/ask updates (Level 1 market data)
- **book5**: Order book depth (5 price levels)
- **book20**: Order book depth (20 price levels) 
- **book50**: Order book depth (50 levels)
- **book**: Full order book (Level 2 market data)
- **ohlcv**: Real-time OHLC volume candlestick data
- **asset**: Asset metadata updates
- **exchange**: Exchange information updates
- **symbol**: Trading symbol metadata
- **exrate**: Cross-asset exchange rate updates

### Advanced Subscription Management

#### Dynamic Subscription Updates
```json
// Add new subscriptions without disconnecting
{
  "type": "subscribe",
  "subscribe_data_type": ["book20"],
  "subscribe_filter_symbol_id": ["KRAKEN_SPOT_BTC_EUR"]
}

// Remove specific subscriptions
{
  "type": "unsubscribe",
  "unsubscribe_data_type": ["quote"],
  "unsubscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}
```

#### Filtering Options
- **By Symbol ID**: Filter specific trading pairs
- **By Asset ID**: Filter by base/quote assets (`subscribe_filter_asset_id`)
- **By Exchange ID**: Filter by trading venues (`subscribe_filter_exchange_id`)
- **By Period ID**: Time-based filtering for OHLCV data

### Performance Optimization

#### Best Practices
- **Asynchronous Processing**: Handle messages in separate threads
- **Message Buffering**: Implement message queues (default: 131,072 queue limit)  
- **Connection Pooling**: Use multiple connections for high-volume data
- **Error Handling**: Implement robust reconnection logic
- **Resource Management**: Properly close connections and clean up resources

#### Testing Tools
- **wscat**: `npm install -g wscat` - Command-line WebSocket client
- **sandy**: `https://app.gosandy.io/` - Standalone WebSocket testing client
- **Custom Clients**: Build test clients for specific requirements

### WebSocket Endpoints

### Production Endpoints (Secure - wss://)
- **GeoDNS (Recommended)**: `wss://ws.coinapi.io/v1/`
- **Americas**: `wss://api-ncsa.coinapi.io/v1/`
- **Europe/Middle East/Africa**: `wss://api-emea.coinapi.io/v1/`
- **Asia Pacific**: `wss://api-apac.coinapi.io/v1/`

### Non-Encrypted Endpoints (ws://)
- Same URLs but with `ws://` protocol

### Connection Features
- **GeoDNS Auto-routing**: Automatic routing to nearest datacenter
- **Regional Endpoints**: Choose specific geographic regions
- **Testing Tools**: wscat (npm), sandy WebSocket client

---

## WebSocket Message Types

### Subscription Types
- **trade**: Real-time trade execution data
- **quote**: Best bid/ask updates (Level 1)
- **book5**: Order book depth (5 levels)
- **book20**: Order book depth (20 levels) 
- **book50**: Order book depth (50 levels)
- **ohlcv**: OHLC volume candlestick data

### Connection Flow
```javascript
// 1. Connect to WebSocket
const ws = new WebSocket('wss://ws.coinapi.io/v1/');

// 2. Send Hello Message
ws.send(JSON.stringify({
  "type": "hello",
  "apikey": "YOUR_API_KEY",
  "subscribe_data_type": ["trade"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}));

// 3. Handle Ping/Pong (respond within 1 minute)
ws.on('message', (data) => {
  const message = JSON.parse(data);
  if (message.type === 'ping') {
    ws.send(JSON.stringify({type: 'pong'}));
  }
});
```

---

## Code Examples

### REST API Usage
```javascript
const API_KEY = 'YOUR_API_KEY';
const BASE_URL = 'https://rest.coinapi.io';

// Get Bitcoin price in USD
const response = await fetch(`${BASE_URL}/v1/exchangerate/BTC/USD`, {
  headers: {
    'X-CoinAPI-Key': API_KEY,
    'Accept': 'application/json'
  }
});

// Get OHLCV data
const ohlcv = await fetch(`${BASE_URL}/v1/ohlcv/BITSTAMP_SPOT_BTC_USD/latest?period_id=1DAY`, {
  headers: {
    'X-CoinAPI-Key': API_KEY,
    'Accept': 'application/json'
  }
});
```

### Error Handling
```javascript
try {
  const response = await fetch(url, {headers});
  if (!response.ok) {
    switch(response.status) {
      case 401: throw new Error('Invalid API key');
      case 429: throw new Error('Rate limit exceeded');
      case 550: throw new Error('No data available');
      default: throw new Error(`API error: ${response.status}`);
    }
  }
  return await response.json();
} catch (error) {
  console.error('CoinAPI Error:', error.message);
}
```

---
*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added comprehensive REST API and WebSocket documentation*

---

## Detailed API Parameters & Examples

### Exchange Rates - Specific Rate
**Endpoint**: `GET /v1/exchangerate/:asset_id_base/:asset_id_quote`

**Parameters**:
- `asset_id_base` (path, required): Base asset (e.g., "BTC")
- `asset_id_quote` (path, required): Quote asset (e.g., "USD") 
- `time` (query, optional): Historical timestamp

**Response Example**:
```json
{
  "time": "2025-08-29T06:04:08.1375564Z",
  "asset_id_base": "BTC",
  "asset_id_quote": "USD", 
  "rate": 10000
}
```

---

### Symbols Metadata - Active Symbols
**Endpoint**: `GET /v1/symbols/:exchange_id/active`

**Parameters**:
- `exchange_id` (path, required): Exchange identifier
- `filter_symbol_id` (query, optional): Filter by symbol ID parts
- `filter_asset_id` (query, optional): Filter by asset ID

**Response Fields**:
- `symbol_id`: Full symbol identifier
- `exchange_id`: Exchange name
- `symbol_type`: SPOT, FUTURES, OPTION, PERPETUAL, etc.
- `asset_id_base`: Base asset
- `asset_id_quote`: Quote asset  
- `price_precision`: Decimal places for price
- `size_precision`: Decimal places for size

**Symbol ID Patterns**:
```
SPOT: {exchange_id}_SPOT_{base}_{quote}
FUTURES: {exchange_id}_FTS_{base}_{quote}_{delivery_date}  
PERPETUAL: {exchange_id}_PERP_{base}_{quote}
```

---

### OHLCV - Time Periods
**Available Periods**:
- **Seconds**: 1SEC, 2SEC, 3SEC, 4SEC, 5SEC, 6SEC, 10SEC, 15SEC, 20SEC, 30SEC
- **Minutes**: 1MIN, 2MIN, 3MIN, 4MIN, 5MIN, 6MIN, 10MIN, 15MIN, 20MIN, 30MIN
- **Hours**: 1HRS, 2HRS, 3HRS, 4HRS, 6HRS, 8HRS, 12HRS
- **Days**: 1DAY, 2DAY, 3DAY, 5DAY, 7DAY, 10DAY
- **Months**: 1MTH, 2MTH, 3MTH, 4MTH, 6MTH
- **Years**: 1YRS, 2YRS, 3YRS, 4YRS, 5YRS

**Historical Data Parameters**:
- `period_id` (required): Time period from list above
- `time_start` (optional): ISO 8601 timestamp
- `time_end` (optional): ISO 8601 timestamp  
- `limit` (optional): Default 100, max 100,000

---

## WebSocket Message Formats

### Hello Message (Authentication)
```json
{
  "type": "hello",
  "apikey": "YOUR_API_KEY",
  "subscribe_data_type": ["trade", "quote", "book5"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}
```

### Trade Message
```json
{
  "type": "trade",
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2023-06-20T12:34:56.789Z",
  "time_coinapi": "2023-06-20T12:34:56.790Z", 
  "price": 30000.50,
  "size": 0.025,
  "taker_side": "BUY",
  "sequence": 12345
}
```

### Quote Message  
```json
{
  "type": "quote",
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2023-06-20T12:34:56.789Z",
  "time_coinapi": "2023-06-20T12:34:56.790Z",
  "ask_price": 30001.00,
  "ask_size": 1.5,
  "bid_price": 29999.00, 
  "bid_size": 2.1,
  "sequence": 12346
}
```

### Order Book Message (Book5/20/50)
```json
{
  "type": "book5",
  "symbol_id": "BITSTAMP_SPOT_BTC_USD", 
  "time_exchange": "2023-06-20T12:34:56.789Z",
  "time_coinapi": "2023-06-20T12:34:56.790Z",
  "asks": [
    {"price": 30001.00, "size": 1.5},
    {"price": 30002.00, "size": 0.8}
  ],
  "bids": [
    {"price": 29999.00, "size": 2.1}, 
    {"price": 29998.00, "size": 1.2}
  ],
  "sequence": 12347
}
```

---

## Indexes API

### Index Types
1. **Principal Market Price (PRIMKT)**: Representative price from primary market
2. **Volume Weighted Average Price (VWAP)**: Volume-weighted pricing
3. **Volatility Index (CAPIVIX)**: Market volatility measurement

### Index Endpoints
- **REST API**: Standard HTTP endpoints for index data
- **WebSocket API**: Real-time index updates
- **Historical Data**: Time-series index values

---

## Flat Files API

### Overview
- **Purpose**: Historical cryptocurrency market data via S3-compatible API
- **Access Method**: Pull-based S3 API for on-demand retrieval
- **Authentication**: API credentials via Customer Portal

### Available Data Types
1. **Quotes**: Best bid/ask price data
2. **Trades**: Executed trade transaction data  
3. **Limit Book Data**: Full order book snapshots
4. **Coming Soon**: OHLCV data

### Access Methods
- **Current**: S3 API for manual data retrieval
- **Coming Soon**: Push API for automated daily updates to your S3 bucket

### Standards & Formats
- **Time**: ISO 8601 format
- **Variables**: snake_case naming
- **Currency**: ISO 4217 for fiat codes
- **Precision**: Max 19 digits (9 decimal places)
- **Timezone**: UTC for all timestamps

---

## Rate Limits & Pricing

### API Key Requirements
- **Free Tier**: Available via console.coinapi.io
- **Production**: Paid plans with higher rate limits
- **Enterprise**: Custom rate limits and SLAs

### Usage Credits
- **Flat Files**: Requires usage credits via Customer Portal
- **REST/WebSocket**: Rate limited by plan tier
- **Billing**: Based on API calls and data volume

---

## Common Use Cases

### Real-time Trading Bot
```javascript
// WebSocket for real-time data
const ws = new WebSocket('wss://ws.coinapi.io/v1/');
ws.send(JSON.stringify({
  "type": "hello", 
  "apikey": API_KEY,
  "subscribe_data_type": ["trade"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}));
```

### Historical Analysis
```javascript
// REST API for historical OHLCV
const url = `${BASE_URL}/v1/ohlcv/BITSTAMP_SPOT_BTC_USD/history?period_id=1DAY&limit=365`;
const response = await fetch(url, {headers});
```

### Price Monitoring
```javascript
// Get current exchange rate
const rate = await fetch(`${BASE_URL}/v1/exchangerate/BTC/USD`, {headers});
```

---
*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added detailed parameters, periods, WebSocket formats, Indexes and Flat Files API*

---

## FIX API

### Protocol Details
- **Version**: FIX 4.4
- **Data Dictionary**: FIX44.xml
- **Heartbeat**: 10 seconds recommended

### Connection Endpoints
- **Encrypted**: `fix.coinapi.io:3303` (TLS)
- **Unencrypted**: `fix.coinapi.io:3302`
- **Regional**: Americas, EMEA, APAC endpoints available

### Configuration
- **SenderCompID**: Your API Key
- **TargetCompID**: "COINAPI_V2"
- **Security**: TLS protocol (stunnel for proxy if needed)

### Recommended Libraries
- **C++**: QuickFIX
- **C#**: QuickFIXN  
- **Java**: QuickFIXJ
- **Python**: QuickFIX Python
- **Ruby**: QuickFIX Ruby
- **Go**: QuickFIXGo

> **Note**: Consider REST/WebSocket APIs if unfamiliar with FIX protocol

---

## JSON RPC API

### Overview
- **Endpoint**: `https://rest.coinapi.io/jsonrpc`
- **Protocol**: JSON-RPC 2.0
- **Authentication**: API key required

### Request Format
```json
{
  "jsonrpc": "2.0",
  "method": "v1/resource_path", 
  "params": [],
  "id": "tracking-id"
}
```

### Available Methods
- **Exchanges**: `v1/exchanges`
- **Exchange Rates**: `v1/exchangerate/BTC`
- **Symbols**: `v1/symbols`
- **Assets**: `v1/assets`
- **OHLCV**: `v1/ohlcv/{symbol_id}/history`

### Response Format
```json
{
  "jsonrpc": "2.0",
  "result": {...},
  "id": "tracking-id"
}
```

### Error Response
```json
{
  "jsonrpc": "2.0", 
  "error": {
    "code": 400,
    "message": "Bad Request"
  },
  "id": "tracking-id"
}
```

---

## Performance Testing & Optimization

### REST API Testing
```bash
# Test with curl timing
curl -w "@curl-format.txt" -o /dev/null -s \
  -H "X-CoinAPI-Key: YOUR_KEY" \
  "https://rest.coinapi.io/v1/exchanges"
```

### WebSocket Performance Testing
- **Requirements**: .NET 8.0+ environment
- **Method**: Dedicated WebSocket client application
- **Metrics**: Message counts and latency measurement
- **Best Practice**: Separate connections for different data feeds

### FIX Protocol Testing
- **Engine**: QuickFix
- **Configuration**: Session management
- **Metrics**: Message latency and throughput

### Optimization Strategies
1. **Fetch messages quickly** from API
2. **Process in separate threads** to avoid blocking
3. **Use multithreading** across multiple connections
4. **Split data acquisition** across connections when latency increases
5. **Monitor performance** and scale connections as needed

---

## Best Practices & Tips

### Rate Limiting
- **Monitor** your API usage in dashboard
- **Implement exponential backoff** for 429 errors
- **Use compression** (`Accept-Encoding: br, gzip`)
- **Cache responses** when appropriate

### Error Handling Best Practices
```javascript
async function coinApiRequest(endpoint, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(endpoint, {headers});
      
      if (response.status === 429) {
        // Rate limit - exponential backoff
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
        continue;
      }
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
      
    } catch (error) {
      if (i === retries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}
```

### WebSocket Connection Management
```javascript
class CoinAPIWebSocket {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.reconnectDelay = 1000;
    this.maxReconnectDelay = 30000;
  }
  
  connect() {
    this.ws = new WebSocket('wss://ws.coinapi.io/v1/');
    
    this.ws.onopen = () => {
      this.authenticate();
      this.reconnectDelay = 1000; // Reset delay on successful connection
    };
    
    this.ws.onclose = () => {
      setTimeout(() => this.connect(), this.reconnectDelay);
      this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxReconnectDelay);
    };
    
    this.ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    this.ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'ping') {
        this.ws.send(JSON.stringify({type: 'pong'}));
      }
      this.handleMessage(message);
    };
  }
}
```

---

## Quick Reference

### Common Endpoints
```bash
# Get BTC price in USD
GET /v1/exchangerate/BTC/USD

# Get symbols for Binance
GET /v1/symbols/BINANCE

# Get latest trades for BTC/USD
GET /v1/trades/BITSTAMP_SPOT_BTC_USD/latest

# Get OHLCV daily data
GET /v1/ohlcv/BITSTAMP_SPOT_BTC_USD/history?period_id=1DAY
```

### Required Headers
```javascript
{
  'X-CoinAPI-Key': 'YOUR_API_KEY',
  'Accept': 'application/json',
  'Accept-Encoding': 'br, gzip'
}
```

### WebSocket Subscription
```json
{
  "type": "hello",
  "apikey": "YOUR_API_KEY", 
  "subscribe_data_type": ["trade", "quote"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}
```

---
*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added FIX API, JSON RPC, Performance Testing, Best Practices and Quick Reference*

---

## Advanced Trading Infrastructure

### High-Frequency Trading (HFT) Strategies

**Core HFT Strategy Types:**

#### 1. Statistical Arbitrage
- **Model-Based Approach**: Uses statistical models to identify price discrepancies
- **Correlation Trading**: Exploits relationships between correlated cryptocurrencies
- **Predictive Execution**: Based on historical data patterns and mean reversion
- **Risk Management**: Sophisticated position sizing and hedging strategies

#### 2. Cross-Exchange Arbitrage
- **Speed Advantage**: Capitalizes on execution speed differences between venues
- **Price Discrepancy**: Profits from momentary price variations across platforms
- **Infrastructure Requirements**: Direct connections to multiple exchanges
- **Latency Optimization**: Sub-millisecond execution capabilities

#### 3. Market Making Strategies
- **Bid-Ask Spread**: Simultaneous buy/sell order placement for spread capture
- **Liquidity Provision**: Continuous market presence for trading opportunities
- **Inventory Management**: Dynamic position balancing across assets
- **Risk Control**: Real-time exposure monitoring and adjustment

#### 4. Momentum Trading
- **Sentiment Exploitation**: Leverages current market momentum and news events
- **Volume Analysis**: High trading volume and volatility pattern recognition
- **Event-Driven**: Trading around significant market catalysts and announcements
- **Trend Following**: Algorithmic pattern recognition for directional trades

#### 5. Scalping Operations
- **High-Frequency Execution**: "Dozens or even hundreds of trades daily"
- **Micro-Profit Accumulation**: Small gains from minute market inefficiencies
- **Order Flow Analysis**: Tick-by-tick market microstructure examination
- **Rapid Position Turnover**: Minimal holding periods for risk reduction

**Technical Infrastructure Requirements:**
- **Multi-Exchange Connectivity**: Direct API connections to major venues
- **Smart Order Routing**: Intelligent execution across fragmented liquidity
- **Real-Time Data Access**: Sub-millisecond market data feeds
- **Historical Data**: Comprehensive backtesting and strategy validation
- **Risk Management**: Real-time position and exposure monitoring

**Crypto Market Characteristics:**
- **24/7 Trading**: Continuous market operations across global timezones
- **High Volatility**: Extreme price movements creating opportunities and risks
- **Market Fragmentation**: Liquidity distributed across numerous exchanges
- **News Sensitivity**: Rapid price reactions to technological developments

### Low-Latency Trading Infrastructure

**Core Performance Benefits:**

#### Execution Speed Advantages
- **Slippage Reduction**: Minimizes adverse price movements during order execution
- **Optimal Price Capture**: "Secure trades at desired prices before market conditions shift"
- **Position Management**: Rapid entry and exit capabilities for dynamic strategies
- **Order Flow Priority**: Faster execution in competitive order queues

#### Market Making Optimization
- **Efficient Order Management**: "Efficient order placement and cancellation"
- **Large Volume Handling**: Process significant trade volumes without market impact
- **Spread Maintenance**: Tighter bid-ask spreads for improved profitability
- **Inventory Balancing**: Real-time position adjustments based on market flow

#### Algorithmic Trading Enhancement
- **Real-Time Responsiveness**: "Real-time reaction to market changes"
- **Complex Strategy Support**: Advanced algorithmic implementation capabilities
- **Automated Execution**: Trading bots with sophisticated conditional logic
- **Market Adaptation**: Dynamic strategy adjustment based on market conditions

#### Risk Management Benefits
- **Adverse Movement Protection**: Rapid response to unfavorable price changes
- **Position Adjustment**: Quick rebalancing of exposure across assets
- **Stop-Loss Efficiency**: Immediate execution of risk management orders
- **Volatility Response**: Fast reaction to sudden market disruptions

**Technical Infrastructure Components:**
- **Sub-Millisecond Accuracy**: Precise timestamp and execution tracking
- **High-Speed Connectivity**: Dedicated network infrastructure for trading
- **Advanced Computing**: Powerful hardware for complex calculations
- **Unified Data Access**: Standardized APIs across multiple exchanges
- **Sophisticated Algorithms**: Purpose-built trading logic and execution engines

> **Core Principle**: "Time is money" - every millisecond counts in cryptocurrency trading

### Protocol Comparison: FIX API vs REST API

**Performance Characteristics:**

#### Latency Hierarchy
```
FIX API < WebSocket < REST API
```

#### FIX API Specifications
- **Protocol Type**: Specialized FIX (Financial Information eXchange) protocol
- **Connection State**: Stateful, persistent connections
- **Message Format**: Tag-value structured messages for financial data
- **Performance**: Optimized for high-frequency trading operations
- **Use Cases**: 
  - Direct market access (DMA)
  - Complex order types and conditions
  - Institutional trading platforms
  - Ultra-low latency execution

#### REST API Specifications
- **Protocol Type**: HTTP/HTTPS standard web protocols
- **Connection State**: Stateless, request-response pattern
- **Message Format**: JSON/XML structured data
- **Performance**: Universal implementation with moderate latency
- **Use Cases**:
  - Historical data retrieval and analysis
  - Basic market data and order operations
  - Web and mobile application integration
  - General-purpose trading applications

**Implementation Complexity:**
- **REST API**: Easy implementation with standard HTTP libraries
- **FIX API**: Complex implementation requiring specialized knowledge and libraries

**Selection Guidelines:**
- **Historical Analysis**: REST API for data retrieval and research
- **Real-Time Monitoring**: WebSocket for streaming market data
- **Simple Trading**: REST API for basic order management
- **Professional Trading**: FIX API for advanced high-frequency operations

### Crypto Market Making Framework

**Strategic Market Making Approaches:**

#### Liquidity Provision Services
- **Continuous Opportunity Creation**: "Always an opportunity to sell assets or trade crypto assets at a fair price"
- **Spread Optimization**: Maintain competitive bid-ask spreads across markets
- **Volume Facilitation**: Enable large transactions without significant price impact
- **Market Stability**: Reduce volatility through consistent presence

#### Revenue Generation Models

##### Spread-Based Income
- **Bid-Ask Arbitrage**: Profit from buying at bid and selling at ask
- **Volume Scaling**: Increased profits through high transaction frequency
- **Risk-Neutral Positioning**: Balanced inventory management

##### Exchange Incentive Programs
- **Rebate Systems**: Payments from exchanges for providing liquidity
- **Volume Tiers**: Escalating incentive structures for high-frequency makers
- **Competitive Advantages**: Reduced trading costs through maker programs

##### Advanced Strategy Integration
- **Cross-Exchange Arbitrage**: Simultaneous market making across venues
- **Derivatives Hedging**: Risk management through futures and options
- **High-Frequency Optimization**: Algorithmic execution for maximum efficiency

**Operational Challenges:**

#### Market Structure Issues
- **Low Volume Assets**: Difficulty providing liquidity in niche cryptocurrencies
- **Supply-Demand Imbalances**: Managing inventory in trending markets
- **Exchange Fragmentation**: Coordination across multiple trading venues
- **Regulatory Uncertainty**: Compliance across different jurisdictions

#### Technical Implementation
- **Multi-Exchange Integration**: Reliable connections to diverse platforms
- **24/7 Operations**: Continuous asset management and monitoring
- **Automated Systems**: Sophisticated trading algorithms and risk controls
- **High-Speed Infrastructure**: Low-latency execution platforms

**Compliance and Risk Management:**
- **Regulatory Navigation**: Cross-market compliance requirements
- **Manipulation Prevention**: Avoiding predatory trading practices
- **Documentation Standards**: Comprehensive audit trails and reporting
- **Activity Monitoring**: Real-time surveillance of trading patterns

> **Strategic Role**: Market makers create stability and efficiency in volatile cryptocurrency markets through professional liquidity provision.

---

## Advanced API Endpoints & Features

### Metrics V2 API Comprehensive Guide

**Core Metrics Listing Endpoints:**

#### Get All Supported Metrics
- **Endpoint**: `GET /v2/metrics/listing`
- **Purpose**: Retrieve all available metrics in the system
- **Supported Metrics Examples**:
  - `TVL`: Total Value Locked in protocol
  - `FEES`: Total fees collected by protocol
  - `VOLUMES`: Trading volume metrics
  - `STABLES_BRIDGED_USD`: Total USD stablecoins bridged
  - `STABLES_CIRCULATING_USD`: Total circulating USD stablecoins

#### Asset-Specific Metrics
- **Endpoint**: `GET /v2/metrics/asset/listing`
- **Required Parameter**: `asset_id` (e.g., USDC, USDT)
- **Response Schema**: Array of metrics with `metric_id`, `description`, `source_id`
- **Use Case**: Retrieve all available metrics for specific cryptocurrency or asset

#### Blockchain Chain Metrics
- **Endpoint**: `GET /v2/metrics/chain/listing`
- **Required Parameter**: `chain_id` (e.g., ETHEREUM, ARBITRUM)
- **Key Metrics**: TVL, STABLES_BRIDGED_USD, STABLES_CIRCULATING_USD
- **Application**: On-chain metrics for specific blockchain networks

#### Exchange-Specific Metrics
- **Endpoint**: `GET /v2/metrics/exchange/listing`
- **Required Parameter**: `exchange_id` (e.g., BINANCE, UNISWAP-V3-ETHEREUM)
- **Available Metrics**: TVL, FEES, TRADES_COUNT_BUYS, VOLUME_QUOTED
- **Purpose**: Trading and protocol performance insights per exchange

**Response Formats**: text/plain, application/json, text/json, application/x-msgpack

### Options API Framework

**Core Options Endpoints:**

#### Current Options Data by Exchange
- **Endpoint**: `GET /v1/options/:exchange_id/current`
- **Data Structure**: Options grouped by underlying asset, quote currency, expiration time
- **Response Fields**:
  - `asset_id_base`: Base asset (e.g., "BTC")
  - `asset_id_quote`: Quote currency (e.g., "USD")
  - `underlying_price`: Current underlying asset price
  - `time_expiration`: Option expiration timestamp
  - `strikes`: Available strike prices with call/put details

**Options Data Components:**
- **Call and Put Options** at each strike price
- **Greeks Calculations** for advanced option strategies
- **Bid/Ask Spreads** for market making applications
- **Volume and Open Interest** for liquidity assessment

### Order Book L3 (Level 3) Data

**Granular Order Book Architecture:**

#### Current Order Book by Symbol
- **Endpoint**: `GET /v1/orderbooks3/:symbol_id/current`
- **Optional Parameter**: `limit_levels` for response depth control
- **Response Structure**:
  - Individual order IDs with precise prices and sizes
  - Exchange and CoinAPI timestamps
  - Granular asks and bids with unique identifiers

#### Current Order Books (All Symbols)
- **Endpoint**: `GET /v1/orderbooks3/current`
- **Filter Options**: `filter_symbol_id`, `limit_levels`
- **Application**: Multi-symbol order book monitoring
- **Use Cases**: Market making, arbitrage detection, liquidity analysis

**L3 Data Advantages:**
- **Individual Market Maker Orders** without aggregation
- **Complete Market Microstructure** visibility
- **Order Flow Analysis** for sophisticated strategies
- **Market Impact Modeling** for large transactions

### WebSocket API V1 Enhanced Features

**Connection Infrastructure:**

#### Geographic Endpoint Optimization
- **GeoDNS Auto-Routing**: `wss://ws.coinapi.io/v1/` (recommended)
- **Regional Endpoints**:
  - Americas: North & South America routing
  - EMEA: Europe, Middle East & Africa
  - APAC: Asia Pacific optimization
- **Testing Tools**: `wscat` (npm), `sandy` standalone client

#### Advanced Message Types
- **Trade Messages**: Individual transaction execution details
- **Quote Messages**: Best bid/ask level updates
- **Order Book Messages**: Multi-level (L2, L3) with snapshot/update modes
- **OHLCV Streaming**: Real-time candlestick data
- **Exchange Rate Updates**: Cross-asset pricing information
- **Heartbeat Management**: Connection health monitoring

**Subscription Management:**
- **Hello**: Complete subscription reset
- **Subscribe**: Add new subscriptions without removing existing
- **Unsubscribe**: Remove specific data streams
- **Filtering**: By symbol, asset, exchange, or time period

**Connection Requirements:**
- **Authentication**: API key in hello message
- **Heartbeat Response**: Reply to ping messages within 1 minute
- **Message Buffer**: Default 131,072 message queue limit
- **Error Handling**: JSON-structured error messages

### WebSocket DS (Data Source) Direct Connections

**Direct Exchange Connections:**

#### Specialized Endpoints
- **Format**: `wss://lowercase-exchange-name.ws-ds.md.coinapi.io/`
- **Example**: Coinbase = `wss://coinbase.ws-ds.md.coinapi.io/`
- **Cross-Connect**: `wss://cross-connect-endpoint/md/ws-ds-lowercase-exchange-name/`

#### Enhanced Message Features
- **Trade Direction Estimation**: Proprietary algorithm for BUY/SELL/UNKNOWN
- **Sequence Tracking**: Connection-specific message ordering
- **Reconnect Notifications**: Server maintenance alerts
- **Configurable Updates**: Customizable message frequency

### FIX API Institutional Protocol

**FIX 4.4 Protocol Implementation:**

#### Core Message Types
- **Logon (35=A)**: Session initiation with authentication
- **Security List Request (35=x)**: Symbol and instrument discovery
- **Market Data Request (35=V)**: Snapshot and subscription requests
- **Market Data Incremental (35=X)**: Real-time order book and trade updates
- **Market Data Snapshot (35=W)**: Full order book state delivery

#### Critical Tags and Fields
- **BeginString (8)**: Protocol version identifier
- **MsgType (35)**: Message type classification
- **SenderCompID (49)**: Client identification
- **TargetCompID (56)**: Server identification
- **MDReqId (262)**: Unique request tracking

**Implementation Requirements:**
- **Session Management**: Proper logon/logout sequences
- **Message Validation**: Required fields and format compliance
- **Heartbeat Handling**: Regular connection maintenance
- **Error Recovery**: Reconnection and resynchronization procedures

### Performance Optimization & Latency Reduction

**Infrastructure Optimization Strategies:**

#### Network Infrastructure
- **AWS Direct Connect**: Dedicated connections bypassing public internet
- **VPC Peering**: Direct AWS environment communication
- **GeoDNS Routing**: Automatic nearest server selection
- **Strategic Server Placement**: Geographic optimization for sub-100ms latency

#### Connection Protocol Selection
- **WebSocket API**: Real-time continuous connections
- **FIX API**: High-frequency institutional trading
- **REST API**: Historical data and general queries

#### Performance Monitoring
- **SLA Implementation**: Service level agreement enforcement
- **Real-time Monitoring**: Latency spike detection and alerts
- **Performance Tuning**: Continuous optimization based on metrics
- **Caching Strategies**: Intelligent data storage for response improvement

**Geographic Considerations:**
- **Physical Limitations**: London to Binance ~250ms minimum
- **Infrastructure Requirements**: Multiple data centers for sub-100ms
- **Customer Infrastructure**: Client-side optimization equally important

### Comprehensive How-To Implementation Guides

**Multi-Language Exchange Rate Integration:**

#### Python Implementation
```python
import requests

def fetch_exchange_rate(base, quote):
    url = f"https://rest.coinapi.io/v1/exchangerate/{base}/{quote}"
    headers = {"X-CoinAPI-Key": "YOUR_API_KEY"}
    response = requests.get(url, headers=headers)
    return response.json()
```

#### JavaScript/Node.js Implementation
```javascript
import fetch from 'node-fetch';

const fetchExchangeRate = async (base, quote) => {
    const response = await fetch(
        `https://rest.coinapi.io/v1/exchangerate/${base}/${quote}`,
        { headers: {"X-CoinAPI-Key": "YOUR_API_KEY"} }
    );
    return await response.json();
};
```

#### Java Implementation
```java
URL url = new URL("https://rest.coinapi.io/v1/exchangerate/BTC/USD");
HttpURLConnection conn = (HttpURLConnection) url.openConnection();
conn.setRequestProperty("X-CoinAPI-Key", API_KEY);
// Process response...
```

**React Portfolio Tracker Architecture:**

#### State Management Strategy
```javascript
function App() {
    const [portfolio, setPortfolio] = useState([]);
    
    useEffect(() => {
        async function fetchExchangeRates() {
            // Multi-asset rate fetching
            const rates = await Promise.all([
                fetchRate('BTC', 'USD'),
                fetchRate('ETH', 'USD'),
                fetchRate('XRP', 'USD')
            ]);
            setPortfolio(rates);
        }
        
        fetchExchangeRates();
        const intervalId = setInterval(fetchExchangeRates, 5000);
        return () => clearInterval(intervalId);
    }, []);
}
```

**Historical OHLCV Data Retrieval:**

#### Parameter Configuration
- **Symbol Selection**: `BINANCE_SPOT_ETH_BTC` format
- **Period Configuration**: `1SEC`, `1MIN`, `1HRS`, `1DAY`, `1MTH`
- **Time Range**: ISO 8601 format timestamps
- **Data Limits**: Configurable result set sizes

#### Best Practices
- **API Key Security**: Environment variable storage
- **Rate Limiting**: Respect API usage quotas
- **Error Handling**: Comprehensive exception management
- **Data Validation**: Symbol and period ID verification

**D3.js Visualization Integration:**

#### Chart Creation Pipeline
1. **Data Transformation**: Convert API response to D3-compatible format
2. **Scale Definition**: X/Y axis scaling for time series data
3. **Line Generation**: D3 line generator for price curves
4. **Interactive Features**: Hover tooltips and zoom functionality
5. **Responsive Design**: Dynamic sizing and styling

**Funding Rate Metrics Access:**

#### Key Endpoints
- **Symbol Metrics Listing**: `/v1/metrics/symbol/listing`
- **Current Funding Rates**: `/v1/metrics/symbol/current`
- **Historical Funding Data**: `/v1/metrics/symbol/history`

#### Implementation Example
```javascript
const getFundingRate = async (symbol, exchange) => {
    const endpoint = `/v1/metrics/symbol/current?metric_id=DERIVATIVES_FUNDING_RATE_CURRENT&symbol_id=${symbol}&exchange_id=${exchange}`;
    return await apiRequest(endpoint);
};
```

---

## Flat Files API Comprehensive Framework

### Introduction & Architecture

**Core Flat Files Capabilities:**
- **Historical Data Access**: Comprehensive cryptocurrency market data in flat file format
- **S3-Compatible API**: Industry-standard access patterns and tools
- **Data Types Available**: Quotes, Trades, Limit Order Book, OHLCV (coming soon)
- **Automated Delivery**: Push API for scheduled data delivery to designated S3 buckets

**File Organization Structure:**
```
/T-[DATATYPE]/D-YYYYMMDD/E-[EXCHANGE]/FILENAME.csv.gz
```

**Technical Standards:**
- **Variable Naming**: Snake_case convention
- **Asset Codes**: ISO 4217 compliance for fiat currencies
- **Time Format**: ISO 8601 standard timestamps
- **Precision**: Maximum 19 digits (9 decimal places)
- **Compression**: Gzip compression for efficient storage

### Data Types & File Structures

**Quotes Data Files:**
- **File Path**: `T-QUOTES/D-YYYYMMDD/E-[EXCHANGE]/IDDI-[ID]+SC-[SYMBOL]+S-[EXCHANGE_SYMBOL].csv.gz`
- **Key Fields**:
  - `id_site_coinapi`: UUID of data reception site
  - `time_exchange`: Exchange UTC timestamp
  - `time_coinapi`: CoinAPI receipt timestamp
  - `ask_px/ask_sx`: Best ask price and volume
  - `bid_px/bid_sx`: Best bid price and volume
- **Applications**: Spread analysis, liquidity monitoring, market timing

**Trades Data Files:**
- **Structure**: Individual transaction records in chronological order
- **Key Fields**:
  - `time_exchange/time_coinapi`: Dual timestamp tracking
  - `guid`: Unique trade identifier for deduplication
  - `price`: Transaction execution price
  - `base_amount`: Asset quantity traded
  - `taker_side`: Aggressor side (BUY/SELL/ESTIMATED)
- **Applications**: Volume analysis, price discovery, execution simulation

**Full Limit Order Book Files:**
- **Update Types**: ADD, SUB, MATCH, SET, DELETE, SNAPSHOT
- **Key Fields**:
  - `is_buy`: Boolean for bid (1) or ask (0) side
  - `update_type`: Order book change classification
  - `entry_px/entry_sx`: Price and volume of update
  - `order_id`: Optional order identifier for tracking
- **Applications**: Market microstructure analysis, order flow modeling

### S3 API Integration

**Authentication Framework:**
- **Access Key ID**: Your CoinAPI key
- **Secret Access Key**: "coinapi" (fixed value)
- **Signature Support**: AWS Signature Version 2 and 4
- **Endpoint**: `s3.flatfiles.coinapi.io`
- **Region**: `us-east-1`

**Supported Operations:**

#### List Objects (GET)
```
GET /bucket/?prefix={prefix}
```
- **Headers**: `Accept: application/xml`
- **Filtering**: Prefix-based object filtering
- **Response**: XML-formatted object listings

#### Download Object (GET)
```
GET /bucket/{Key}
```
- **Authentication**: Authorization header with CoinAPI key
- **Protocol**: HTTPS recommended for production
- **Error Handling**: Standard HTTP status codes with XML responses

**Compatible Tools:**
- **AWS CLI**: Standard AWS command-line interface
- **S3 Browser**: GUI-based S3 management
- **SDK Libraries**: Multi-language support (Python boto3, JavaScript AWS SDK, etc.)

### Multi-Language SDK Integration

**Supported Programming Languages:**
- **JavaScript (Node.js)**: AWS SDK v3 with custom endpoint configuration
- **Python**: boto3 client with CoinAPI credentials
- **Java**: AWS SDK for Java with S3 client setup
- **C# (.NET)**: AWS SDK for .NET integration
- **Ruby**: AWS SDK for Ruby implementation
- **PHP**: AWS SDK for PHP integration
- **Go**: AWS SDK for Go with S3 service
- **Swift, Rust, SAP ABAP**: Additional language support available

**Standard Configuration Pattern:**
```javascript
// Example: JavaScript SDK
const s3Client = new S3Client({
  endpoint: "https://s3.flatfiles.coinapi.io",
  region: "us-east-1",
  credentials: {
    accessKeyId: "YOUR_COINAPI_KEY",
    secretAccessKey: "coinapi"
  }
});
```

### Snowflake Data Warehouse Integration

**Available Datasets:**
- **Assets**: Cryptocurrency and token metadata
- **Exchange Rates**: Historical price relationships
- **Indexes**: Market index calculations and values
- **Order Books**: Market depth and liquidity data
- **Quotes**: Best bid/ask historical records
- **OHLCV**: Open, High, Low, Close, Volume data
- **Trades**: Transaction execution records

**Integration Benefits:**
- **Enhanced Query Performance**: SQL-based data analysis
- **Scalability**: Cloud-native data warehouse capabilities
- **Security**: Enterprise-grade data protection
- **Transformation**: Advanced data processing and analytics
- **Integration**: Seamless connection with existing workflows

**Access Method:**
- Requires existing Snowflake account
- Contact CoinAPI Account Executive for dataset access
- Sample files available in Snowflake Marketplace

### Push API & Order Management

**Push API Framework:**
- **Automated Delivery**: Scheduled data delivery to customer S3 buckets
- **Authentication**: API key-based access control
- **Version**: v1 implementation with MIT License

**Order Management Endpoints:**

#### Price Calculation
- **Endpoint**: `POST /api/push-orders/calculate-price`
- **Required Parameters**: `id`, `idOrganization`, `exchange`
- **Optional Parameters**: `symbols`, `date_from`, `date_to`, `priceHistorical`, `priceDailyUpdates`
- **Purpose**: Estimate costs for data orders before creation

#### Order Creation
- **Endpoint**: `POST /api/push-orders`
- **Configuration Options**: Exchange selection, symbol filtering, date ranges
- **Delivery Options**: Historical data, daily updates, custom encoding/compression
- **Management**: Order tracking with unique IDs and organization mapping

#### Order Administration
- **List Orders**: `GET /api/push-orders` - View all active orders
- **Delete Order**: `DELETE /api/push-orders/{id}` - Cancel specific orders
- **Account Balance**: `GET /api/push-orders/account-balance` - Monitor available credits

**Pricing Model:**
- **Credit-Based System**: Usage credits consumed based on data volume
- **Example Pricing**: Trades data at $3 per GB
- **Calculation**: `Size in GB × Price per GB = Total Order Cost`
- **Estimation**: Use calculation endpoint before order creation

**Data Storage Management:**

#### Datastore Configuration
- **List Types**: `GET /api/metadata/datastore-types` - Available storage options
- **List Endpoints**: `GET /api/metadata/datastore-endpoints` - Configured destinations
- **Add Endpoint**: `POST /api/metadata/datastore-endpoints` - Configure new storage
- **Delete Endpoint**: `DELETE /api/metadata/datastore-endpoints/{id}` - Remove storage

**Advanced Implementation Tutorials:**

#### Real-Time Data Visualization with JavaScript
**Technology Stack**: JavaScript + WebSocket + Chart.js

**Implementation Framework:**
```javascript
// WebSocket Connection Setup
const socket = new WebSocket('wss://ws.coinapi.io/v1/');

// Authentication and Subscription
socket.onopen = function(event) {
    socket.send(JSON.stringify({
        "type": "hello",
        "apikey": "YOUR_API_KEY",
        "subscribe_data_type": ["trade"],
        "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
    }));
};

// Real-Time Chart Updates
socket.onmessage = function(event) {
    const tradeData = JSON.parse(event.data);
    // Update Chart.js with new data points
    chart.data.labels.push(new Date().toLocaleTimeString());
    chart.data.datasets[0].data.push(tradeData.price);
    
    // Maintain chart data limit (e.g., 50 points)
    if (chart.data.labels.length > 50) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }
    
    chart.update();
};
```

**Key Features:**
- **Dynamic Chart Updates**: Real-time price visualization
- **Data Point Management**: Limit chart to recent 50 data points
- **Error Handling**: WebSocket connection monitoring
- **Performance Optimization**: Efficient chart rendering

#### Multi-Language WebSocket Streaming

**Python Implementation:**
```python
import websocket
import json

def on_message(ws, message):
    trade_data = json.loads(message)
    print(f"Trade: {trade_data['price']} at {trade_data['time_exchange']}")

def on_open(ws):
    subscribe_message = {
        "type": "hello",
        "apikey": "YOUR_API_KEY",
        "subscribe_data_type": ["trade"],
        "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD$"]
    }
    ws.send(json.dumps(subscribe_message))

ws = websocket.WebSocketApp("wss://ws.coinapi.io/v1/",
                          on_open=on_open,
                          on_message=on_message)
ws.run_forever()
```

**Java Implementation:**
```java
WebSocketClient socket = new WebSocketClient(new URI("wss://ws.coinapi.io/v1/")) {
    @Override
    public void onOpen(ServerHandshake handshake) {
        JSONObject subscribeMsg = new JSONObject();
        subscribeMsg.put("type", "hello");
        subscribeMsg.put("apikey", "YOUR_API_KEY");
        subscribeMsg.put("subscribe_data_type", Arrays.asList("trade"));
        send(subscribeMsg.toString());
    }
    
    @Override
    public void onMessage(String message) {
        // Process trade data
    }
};
```

#### Order Book Data Analysis Framework

**Python Analysis Pipeline:**
```python
import requests
import matplotlib.pyplot as plt
import numpy as np

def analyze_order_book(symbol_id):
    # Fetch order book data
    url = f"https://rest.coinapi.io/v1/orderbooks/{symbol_id}/current"
    headers = {"X-CoinAPI-Key": "YOUR_API_KEY"}
    response = requests.get(url, headers=headers)
    order_book = response.json()
    
    # Calculate market metrics
    best_bid = max(order_book['bids'], key=lambda x: x['price'])
    best_ask = min(order_book['asks'], key=lambda x: x['price'])
    spread = best_ask['price'] - best_bid['price']
    
    # Order imbalance analysis
    total_bid_volume = sum([bid['size'] for bid in order_book['bids']])
    total_ask_volume = sum([ask['size'] for ask in order_book['asks']])
    imbalance = (total_bid_volume - total_ask_volume) / (total_bid_volume + total_ask_volume)
    
    return {
        'spread': spread,
        'imbalance': imbalance,
        'bid_volume': total_bid_volume,
        'ask_volume': total_ask_volume
    }
```

**Visualization Techniques:**
- **Depth Charts**: Matplotlib-based order book visualization
- **Color Coding**: Green for bids, red for asks
- **Dynamic Plotting**: Real-time order book changes
- **Market Metrics**: Spread, imbalance, and liquidity indicators

#### Spreadsheet Integration Methods

**CSV Data Import via URL:**
```
https://rest.coinapi.io/v1/exchangerate/BTC?apikey=YOUR_API_KEY&output_format=csv
```

**Excel Integration Steps:**
1. **Data Tab**: Select "From Text/CSV"
2. **File Selection**: Choose downloaded CSV file
3. **Import Preview**: Verify data format and delimiters
4. **Data Transformation**: Apply necessary formatting

**Google Sheets Integration:**
1. **File Menu**: Select "Import"
2. **Upload Method**: Choose CSV file upload
3. **Separator Configuration**: Set correct delimiter
4. **Import Location**: Specify destination range

**Postman API Testing Setup:**
1. **OpenAPI Import**: Copy CoinAPI specification URL
2. **Collection Generation**: Import via Postman interface
3. **Environment Setup**: Configure API key variables
4. **Testing Workflow**: Execute and validate API endpoints

**Advanced Features:**
- **Automated Data Refresh**: Scheduled CSV updates
- **Formula Integration**: Excel/Sheets function combinations
- **Data Validation**: Error handling and format checking
- **Dashboard Creation**: Visual analytics and charting

---

## Comprehensive Metadata & Metrics APIs

### REST API Metadata Framework

**Core Metadata Endpoints:**

#### Active Symbols Management
- **List All Active Symbols**: `GET /v1/symbols/:exchange_id/active`
- **Symbol Mapping**: `GET /v1/symbols/map/:exchange_id`
- **Historical Symbols**: `GET /v1/symbols/:exchange_id/history`

**Symbol Identifier Patterns:**
```
SPOT: {exchange_id}_SPOT_{base}_{quote}
FUTURES: {exchange_id}_FTS_{base}_{quote}_{delivery_date}
PERPETUAL: {exchange_id}_PERP_{base}_{quote}
OPTION: {exchange_id}_OPT_{base}_{quote}_{expiration}_{strike}_{call/put}
INDEX: {exchange_id}_IDX_{base}_{quote}
```

**Symbol Types Supported:**
- **Spot Trading**: Direct cryptocurrency exchanges
- **Futures Contracts**: Time-specific delivery agreements
- **Perpetual Swaps**: Continuous derivative contracts
- **Options**: Strike price and expiration-based derivatives
- **Index Products**: Market benchmark instruments
- **Credit Products**: Lending and borrowing instruments

#### Assets Information System
- **All Assets**: `GET /v1/assets`
- **Asset by ID**: `GET /v1/assets/:asset_id`
- **Asset Icons**: `GET /v1/assets/icons/:size`

**Asset Metadata Fields:**
- **Identification**: Asset ID aligned with ISO 4217 for fiat currencies
- **Trading Data**: Volume metrics, price ranges, data availability periods
- **Market Information**: USD pricing, supply details, market capitalization
- **Blockchain Data**: Chain addresses for multi-network assets
- **Aggregated Statistics**: Information consolidated across related symbols

#### Exchange Infrastructure Data
- **All Exchanges**: `GET /v1/exchanges`
- **Exchange by ID**: `GET /v1/exchanges/:exchange_id`
- **Exchange Icons**: `GET /v1/exchanges/icons/:size`

**Exchange Information Includes:**
- **Basic Details**: Exchange ID, name, website URL
- **Data Availability**: Start/end dates for quotes, order books, trades
- **Trading Activity**: Symbol count, volume statistics
- **Integration Status**: API connection status and ranking information

#### Blockchain Chain Registry
- **All Chains**: `GET /v1/chains`
- **Chain by ID**: `GET /v1/chains/:chain_id`

**Supported Blockchain Networks:**
- **Ethereum**: Primary smart contract platform
- **Arbitrum**: Layer 2 scaling solution
- **Polygon**: Ethereum-compatible sidechain
- **BSC**: Binance Smart Chain ecosystem
- **Additional Networks**: Comprehensive multi-chain support

**Chain Metadata Structure:**
- **Chain ID**: Unique blockchain identifier
- **Network Name**: Human-readable blockchain name
- **Aggregated Data**: Information consolidated across chain-related symbols

### Metrics V1 Analytics Framework

**Core Metrics Categories:**

#### Trading Performance Metrics
1. **Trading Volume**: Transaction activity measurements
2. **Market Depth**: Order book liquidity analysis
3. **Order Book Dynamics**: Bid/ask spread monitoring
4. **Price Movement**: Historical and real-time price tracking
5. **Market Capitalization**: Asset valuation metrics

#### Exchange Analytics
6. **Trading Pairs**: Available instrument analysis
7. **User Activity**: Platform engagement metrics
8. **Trading Fees**: Cost structure analysis
9. **Security Metrics**: Platform safety indicators
10. **Liquidity Metrics**: Market making effectiveness

**Current Metrics Endpoints:**

#### Asset-Level Analytics
- **Endpoint**: `GET /v1/metrics/asset/current`
- **Parameters**: `metric_id`, `asset_id`, `exchange_id`
- **Response Fields**:
  - `entry_time`: Metric timestamp
  - `recv_time`: Data reception time
  - `exchange_id`: Source exchange identifier
  - `asset_id`: Target asset identifier
  - `metric_id`: Specific metric type
  - `value_decimal`: Numerical metric value
  - `value_text`: Optional text representation

#### Exchange-Level Analytics
- **Endpoint**: `GET /v1/metrics/exchange/current`
- **Purpose**: Real-time exchange performance indicators
- **Metrics Examples**:
  - `DERIVATIVES_MARK_PRICE`: Current mark pricing
  - `IV_UNDERLYING_PRICE`: Implied volatility underlying price
  - `TRADING_VOLUME_24H`: Daily volume statistics

#### Symbol-Level Analytics
- **Endpoint**: `GET /v1/metrics/symbol/current`
- **Parameters**: `metric_id`, `symbol_id`, `exchange_id`
- **Use Cases**: Options Greeks calculation, futures pricing, perpetual funding rates
- **Example Metrics**:
  - **Options Greeks**: Rho, Vega, Theta, Delta, Gamma
  - **Index Pricing**: Real-time index calculations
  - **Funding Rates**: Perpetual contract funding mechanisms

### Historical Metrics & Time Series

**Historical Data Endpoints:**

#### Asset Historical Analytics
- **Endpoint**: `GET /v1/metrics/asset/history`
- **Time Series Features**:
  - **Flexible Time Ranges**: Custom start/end timestamps
  - **Configurable Periods**: Default 1-second granularity
  - **Result Limits**: 100 default, 100,000 maximum
  - **Multiple Formats**: JSON, MessagePack support

#### Symbol Historical Analytics
- **Endpoint**: `GET /v1/metrics/symbol/history`
- **Applications**:
  - **Strategy Backtesting**: Historical performance validation
  - **Trend Analysis**: Long-term pattern identification
  - **Risk Assessment**: Volatility and correlation studies
  - **Academic Research**: Comprehensive datasets for analysis

**Response Structure:**
```json
{
  "entry_time": "2023-06-20T12:34:56.789Z",
  "recv_time": "2023-06-20T12:34:56.790Z",
  "exchange_id": "DERIBIT",
  "asset_id": "BTC",
  "symbol_id": "DERIBIT_OPT_BTC_USD_230630_30000_C",
  "metric_id": "DERIVATIVES_MARK_PRICE",
  "value_decimal": 1245.67,
  "value_text": null,
  "value_time": null
}
```

### Advanced Filtering & Query Capabilities

**Symbol Filtering Options:**
- **filter_symbol_id**: Filter by symbol identifier components
- **filter_asset_id**: Filter by specific asset identifiers
- **Period Selection**: Time-based data aggregation
- **Exchange Filtering**: Source-specific data retrieval

**Asset Filtering Capabilities:**
- **Comma/Semicolon Delimited**: Multiple asset selection
- **Type Filtering**: Cryptocurrency vs fiat classification
- **Volume Thresholds**: Activity-based asset filtering
- **Date Range Filtering**: Historical availability constraints

**Chain Filtering Methods:**
- **filter_chain_id**: Blockchain-specific data retrieval
- **Multi-Chain Selection**: Cross-network analysis support
- **Aggregated Information**: Consolidated chain statistics

### Response Format Support

**Standard Response Formats:**
- **application/json**: Default JSON responses
- **text/json**: Alternative JSON format
- **text/plain**: Plain text responses
- **application/x-msgpack**: MessagePack binary format

**Pagination & Limits:**
- **Default Limits**: 100 results for most endpoints
- **Maximum Limits**: Up to 100,000 results for historical data
- **Efficient Querying**: Optimized for large dataset retrieval
- **Rate Limiting**: Built-in request throttling protection

---

## 📊 Metadata Tables Framework

### Introduction & Purpose
**Metadata Tables** provide comprehensive information about:
- **Supported cryptocurrency assets** across all markets
- **Supported exchanges** with integration status
- **Trading symbols** and their configurations

**Key Access Methods:**
1. **REST API Endpoints**: Programmatic access to live metadata
2. **Downloadable Resources**: Compressed CSV files for bulk analysis
   - `Assets.csv` - Complete asset directory
   - `Exchanges.csv` - Exchange information database

**Technical Benefits:**
- Same data available through both API endpoints and direct downloads
- Enables rapid integration, research, and market analysis
- Comprehensive reference for cryptocurrency market data infrastructure

### Metric IDs per Exchange

**Available Metric Sources:**
1. **List All Exchanges API** - Basic exchange metrics
2. **MetricsV1 API** - Standard trading metrics
3. **MetricsV2 API** - Advanced blockchain and DeFi metrics

**Comprehensive Metric Categories:**

#### Derivatives Metrics
- **Funding Rates**: Periodic payments between long/short traders
- **Mark Prices**: Fair value pricing for derivatives
- **Index Prices**: Underlying asset reference prices
- **Liquidation Details**: Forced position closure information
- **Open Interest**: Outstanding derivative contract volumes

#### Options Trading Metrics
- **Greeks Calculations**: Delta, Gamma, Theta, Vega sensitivity measures
- **Implied Volatility**: Market's expectation of future volatility
- **Strike Price Data**: Available option exercise prices
- **Expiration Information**: Contract maturity details

#### Exchange-Specific Specializations
- **Deribit**: Complete options ecosystem with advanced Greeks
- **Bybit**: Comprehensive perpetual futures metrics
- **Gemini**: Institutional auction mechanisms
- **OKEx**: Full spectrum derivatives and liquidation data

**Implementation Usage:**
- Query specific exchange metrics via MetricsV1/V2 APIs
- Filter by exchange ID for targeted analysis
- Access historical metric data for backtesting and research

---

## 🔄 Enhanced Exchange Rates API

### Calculation Methodology

**VWAP-24H Algorithm** (13-Step Process):
1. **Data Collection**: Aggregates quotes, trades, metadata from legitimate exchanges
2. **Symbol Filtering**: Excludes non-SPOT symbols for accuracy
3. **Spread Filtering**: Removes excessively wide bid-ask spreads
4. **Midpoint Calculation**: Uses midpoint pricing for balanced rates
5. **Volume Weighting**: Weights prices by actual trading activity
6. **Outlier Removal**: Discards stale or anomalous data points
7. **Tree Traversal**: Advanced routing for optimal price discovery
8. **Real-Time Updates**: 1-second refresh cycle for each asset pair
9. **Quality Controls**: Multi-layer validation for data integrity
10. **Liquidity Assessment**: Considers market depth and participation
11. **Geographic Distribution**: Global exchange coverage for accuracy
12. **Time Synchronization**: UTC-standardized timestamps
13. **Final Calculation**: Produces reliable, tradeable exchange rates

**Key Quality Features:**
- Sophisticated filtering eliminates market manipulation
- Volume-weighted approach reflects actual trading conditions
- Real-time updates ensure current market representation
- Multi-exchange aggregation reduces single-point failures

### Current Exchange Rates Endpoints

#### Get All Current Rates
**Endpoint**: `GET /v1/exchangerate/:asset_id_base`

**Parameters:**
- `asset_id_base` (required): Base asset identifier (e.g., "BTC")
- `filter_asset_id` (optional): Comma-separated quote asset filter
- `invert` (optional): Boolean to reverse rate calculation
- `time` (optional): Historical timestamp for specific time rates

**Response Structure:**
```json
{
  "asset_id_base": "BTC",
  "rates": [
    {
      "time": "2025-08-31T10:30:00.000Z",
      "asset_id_quote": "USD",
      "rate": 43250.75
    },
    {
      "time": "2025-08-31T10:30:00.000Z", 
      "asset_id_quote": "EUR",
      "rate": 39180.50
    }
  ]
}
```

**Mission-Critical Usage Note:**
> "For mission-critical operations, measure time difference between current time and response time to ensure rate reliability."

#### Get Specific Rate
**Endpoint**: `GET /v1/exchangerate/:asset_id_base/:asset_id_quote`

**Required Parameters:**
- `asset_id_base`: Base asset identifier
- `asset_id_quote`: Quote asset identifier

**Optional Parameters:**
- `time`: Specific timestamp (defaults to current rate)

**Response Example:**
```json
{
  "time": "2025-08-31T10:30:00.1375564Z",
  "asset_id_base": "BTC",
  "asset_id_quote": "USD", 
  "rate": 43250.75
}
```

**Practical Applications:**
- Real-time pricing for trading applications
- Portfolio valuation and accounting
- Cross-currency conversion calculations
- Risk management and exposure analysis

#### Timeseries Historical Data
**Endpoint**: `GET /v1/exchangerate/:asset_id_base/:asset_id_quote/history`

**Required Parameters:**
- `asset_id_base`: Base asset identifier
- `asset_id_quote`: Quote asset identifier
- `period_id`: Time period granularity (5SEC, 1MIN, 1HRS, 1DAY, etc.)
- `time_start`: ISO 8601 starting timestamp
- `time_end`: ISO 8601 ending timestamp

**Optional Parameters:**
- `limit`: Result count (default: 100, maximum: 100,000)

**Response Schema:**
```json
[
  {
    "time_period_start": "2025-08-31T09:00:00.000Z",
    "time_period_end": "2025-08-31T10:00:00.000Z",
    "time_open": "2025-08-31T09:00:00.000Z",
    "time_close": "2025-08-31T09:59:59.000Z",
    "rate_open": 43100.25,
    "rate_high": 43280.75,
    "rate_low": 43050.00,
    "rate_close": 43250.75
  }
]
```

**Time Period Options:**
- **Seconds**: 5SEC, 10SEC, 15SEC, 30SEC
- **Minutes**: 1MIN, 5MIN, 15MIN, 30MIN
- **Hours**: 1HRS, 4HRS, 12HRS
- **Days**: 1DAY, 7DAY
- **Extended**: 1MTH, 1YRS

**Strategic Applications:**
- Backtesting trading strategies with historical rates
- Technical analysis and pattern recognition
- Risk modeling and volatility analysis
- Academic research and market studies
- Compliance and audit trail maintenance

#### Timeseries Periods
**Endpoint**: `GET /v1/exchangerate/history/periods`

**Available Time Periods:**

**Seconds Granularity:**
- 1SEC, 2SEC, 3SEC, 4SEC, 5SEC, 6SEC
- 10SEC, 15SEC, 20SEC, 30SEC

**Minutes Granularity:**
- 1MIN, 2MIN, 3MIN, 4MIN, 5MIN, 6MIN  
- 10MIN, 15MIN, 20MIN, 30MIN

**Hours Granularity:**
- 1HRS, 2HRS, 3HRS, 4HRS, 6HRS, 8HRS, 12HRS

**Days Granularity:**
- 1DAY, 2DAY, 3DAY, 5DAY, 7DAY, 10DAY

**Response Fields:**
- `period_id`: Unique identifier (e.g., "30MIN")
- `length_seconds`: Duration in seconds
- `length_months`: Duration in months (where applicable)
- `unit_count`: Number of time units
- `unit_name`: Time unit description
- `display_name`: Human-readable format (e.g., "30 Minutes")

---

## 📋 REST API Metadata Framework

### Overview & Purpose
**Metadata REST API** provides comprehensive endpoints for retrieving detailed information about:
- **Active Trading Symbols**: Current market instruments across exchanges
- **Asset Information**: Complete cryptocurrency and fiat asset directory
- **Exchange Data**: Trading venue information and capabilities
- **Blockchain Chains**: Multi-network asset tracking
- **Historical Symbols**: Time-based instrument evolution
- **Asset Icons**: Visual representations for UI applications

**Core Benefits:**
- Enables dynamic market discovery and integration
- Supports filtering and detailed querying capabilities
- Provides complete reference data for market analysis
- Facilitates comprehensive cryptocurrency ecosystem understanding

### Active Symbols Management

#### List All Active Symbols
**Endpoint**: `GET /v1/symbols/:exchange_id/active`

**Required Parameters:**
- `exchange_id`: Specific exchange identifier

**Optional Query Parameters:**
- `filter_symbol_id`: Filter symbols by identifier components
- `filter_asset_id`: Filter symbols by specific asset IDs

**Symbol Identifier Structure:**
```
SPOT:       {exchange_id}_SPOT_{base_asset}_{quote_asset}
FUTURES:    {exchange_id}_FTS_{base_asset}_{quote_asset}_{delivery_date}
PERPETUAL:  {exchange_id}_PERP_{base_asset}_{quote_asset}
OPTIONS:    {exchange_id}_OPT_{base_asset}_{quote_asset}_{expiration}_{strike}_{type}
INDEX:      {exchange_id}_IDX_{base_asset}_{quote_asset}
```

**Response Metadata Fields:**
- `symbol_id`: Complete instrument identifier
- `exchange_id`: Trading venue identifier
- `symbol_type`: Instrument classification (SPOT, FUTURES, OPTION, etc.)
- `asset_id_base`: Base asset identifier
- `asset_id_quote`: Quote asset identifier
- `price_precision`: Decimal places for pricing
- `size_precision`: Decimal places for volume
- **Trading Volumes**: Historical activity metrics
- **Data Periods**: Historical data availability ranges
- **Contract Details**: Futures/options specific information

**Practical Applications:**
- Dynamic symbol discovery for trading applications
- Market instrument analysis and comparison
- Exchange capability assessment
- Trading pair availability validation

### Asset Information System

#### List All Assets
**Endpoint**: `GET /v1/assets`

**Optional Parameters:**
- `filter_asset_id`: Comma/semicolon delimited asset filtering

**Comprehensive Asset Metadata:**

**Identity & Classification:**
- `asset_id`: Unique identifier (ISO 4217 aligned for fiat currencies)
- `name`: Human-readable asset name
- `type_is_crypto`: Boolean cryptocurrency classification

**Market Data:**
- `price_usd`: Current USD valuation
- **Volume Metrics**: 1hr, 1day, 1month USD volumes
- **Data Availability**: Quote, orderbook, trade period ranges
- **Supply Information**: Circulating and total supply data

**Technical Integration:**
- `chain_addresses`: Multi-blockchain network addresses
- **Aggregated Information**: Consolidated across related symbols
- **Historical Ranges**: Data start/end timestamps

**Asset Categories:**
- **Cryptocurrencies**: Bitcoin (BTC), Ethereum (ETH), altcoins
- **Fiat Currencies**: USD, EUR, GBP, JPY (ISO 4217 compliant)
- **Stablecoins**: USDT, USDC, DAI
- **Tokens**: ERC-20, BEP-20, and other blockchain tokens

**Strategic Usage:**
- Portfolio construction and asset allocation
- Market capitalization and valuation analysis
- Cross-blockchain asset tracking
- Regulatory compliance and reporting

### Exchange Information Database

#### List All Exchanges
**Endpoint**: `GET /v1/exchanges`

**Optional Parameters:**
- `filter_exchange_id`: Specific exchange filtering

**Exchange Comprehensive Metadata:**

**Basic Information:**
- `exchange_id`: Unique platform identifier
- `name`: Exchange display name
- `website`: Official website URL

**Data Availability:**
- **Quote Data Periods**: Bid/ask historical ranges
- **Trade Data Periods**: Transaction history availability
- **Order Book Periods**: Market depth historical ranges

**Trading Activity Metrics:**
- **USD Volume**: 1hr, 1day, 1month trading volumes
- `data_symbols_count`: Available trading instruments
- `exchange_rank`: Market position ranking

**Integration Status:**
- **API Status**: Connection and reliability information
- **Data Quality**: Validation and integrity metrics
- **Coverage**: Supported markets and instruments

**Example Exchange Data:**
- **Major Exchanges**: Binance, Coinbase, Kraken, Huobi
- **Regional Platforms**: OKCoin, LocalBitcoins
- **Specialized Venues**: Derivatives and options exchanges

**Business Intelligence Applications:**
- Exchange comparison and selection
- Market share analysis
- Data source diversification
- Trading venue evaluation

---

## 📊 Enhanced OHLCV Market Data

### Core OHLCV Concepts

**OHLCV Definition:**
- **Open**: First trade price in time period
- **High**: Maximum price reached during period
- **Low**: Minimum price reached during period  
- **Close**: Final trade price in time period
- **Volume**: Total trading activity in period

**Primary Purpose:**
> "OHLCV data primary purpose is to present an overview of the market in human readable form."

**CoinAPI Enhanced Features:**
Beyond standard OHLCV, CoinAPI includes:
- **Time of First Trade**: Precise opening transaction timestamp
- **Time of Last Trade**: Exact closing transaction timestamp
- **Number of Trades**: Total transaction count in period
- **Zero Volume Handling**: Periods with only orderbook activity

### OHLCV Data Characteristics

**Market Data Sources:**
- **Order Book Activity**: Bid/ask spread changes
- **Transaction Activity**: Actual trade executions
- **Combined Analysis**: Complete market picture

**Data Completeness:**
- **Active Periods**: Full OHLC data with trade activity
- **Quiet Periods**: May have zero volume/trades with only orderbook updates
- **Multi-Timeframe**: Supports granular to extended time periods
- **Exchange-Specific**: Individual venue data tracking

**Technical Specifications:**
- **Time Synchronization**: UTC timestamps for global consistency
- **Precision Control**: Configurable decimal places
- **Volume Calculation**: Aggregated from actual trades
- **Period Alignment**: Standardized time boundaries

### OHLCV vs Exchange Rates

**Usage Guidance:**
- **Asset Pair Analysis** (e.g., BTC/USD): Use Exchange Rates Timeseries API
- **Individual Symbol Analysis** (e.g., BINANCE_SPOT_BTC_USDT): Use OHLCV API
- **Cross-Exchange Comparison**: OHLCV for venue-specific analysis
- **Portfolio Valuation**: Exchange Rates for normalized pricing

**Data Granularity:**
- **OHLCV**: Symbol-specific, exchange-specific market data
- **Exchange Rates**: Aggregated, normalized asset pricing

**Available OHLCV Endpoints:**
1. **Historical Data by Exchange**: Venue-specific historical analysis
2. **Historical Data by Symbol**: Individual instrument analysis
3. **Latest Data**: Real-time market snapshots
4. **List All Periods**: Available time granularity options

**Strategic Applications:**
- **Technical Analysis**: Candlestick pattern recognition
- **Volatility Studies**: Price range and movement analysis
- **Volume Profile**: Trading activity distribution
- **Market Timing**: Entry/exit point identification
- **Performance Attribution**: Exchange-specific performance tracking

---

## 🔌 WebSocket API V1 Real-Time Streaming

### Overview & Architecture

**WebSocket API V1** provides real-time market data streaming through a sophisticated Subscribe-Publish communication model.

**Core Capabilities:**
- **Real-Time Data Streaming**: Live market updates with minimal latency
- **Subscribe-Publish Model**: Efficient data distribution to connected clients
- **Multi-Regional Infrastructure**: Global datacenter coverage for optimal performance
- **Standards Compliance**: Full RFC6455 v13 WebSocket protocol support

**Technical Standards:**
- **HTTP Protocols**: 1.0, 1.1, 2.0 compatibility
- **HTTP/3 + QUIC**: Next-generation protocol support
- **WebSocket RFC6455 v13**: Industry-standard WebSocket implementation

### Connection Management

#### Production Endpoints (Encrypted - wss://)
- **GeoDNS (Recommended)**: `wss://ws.coinapi.io/v1/`
  - Automatic routing to nearest datacenter for optimal performance
- **Americas**: `wss://api-ncsa.coinapi.io/v1/`
- **Europe/Middle East/Africa**: `wss://api-emea.coinapi.io/v1/`
- **Asia Pacific**: `wss://api-apac.coinapi.io/v1/`

#### Non-Encrypted Endpoints (ws://)
- Same regional URLs using `ws://` protocol for development/testing

**Connection Requirements:**
1. **RFC6455 v13 Compliance**: WebSocket client must meet protocol standards
2. **Hello Message**: Send authentication message immediately after connection
3. **Ping-Pong Handling**: Respond to server "Ping" messages with "Pong"
4. **Connection Maintenance**: Failure to respond to Ping will close connection

**Recommended Testing Tools:**
- **wscat**: `npm install -g wscat` - Command-line WebSocket client
- **sandy**: `https://app.gosandy.io/` - Standalone WebSocket client
- **GitHub Reference**: https://github.com/websockets/wscat

### Authentication & Subscription Flow

**Connection Sequence:**
1. **Establish WebSocket Connection** to chosen endpoint
2. **Send Hello Message** with API key and subscription preferences
3. **Handle Ping/Pong** for connection health maintenance
4. **Process Real-Time Data** from subscribed channels

**Hello Message Structure:**
```json
{
  "type": "hello",
  "apikey": "YOUR_API_KEY",
  "subscribe_data_type": ["trade", "quote", "book5"],
  "subscribe_filter_symbol_id": ["BITSTAMP_SPOT_BTC_USD"]
}
```

**Available Data Types:**
- **trade**: Individual transaction execution data
- **quote**: Best bid/ask price updates (Level 1)
- **book5/book20/book50**: Order book depth (5/20/50 levels)
- **ohlcv**: Real-time OHLC volume candlestick data

**Integration Recommendations:**
- Use REST API first to discover available symbols, exchanges, and assets
- Implement proper error handling and reconnection logic
- Monitor connection health through ping/pong mechanism
- Consider geographic endpoint selection for latency optimization

---

## 📊 Quotes API (Level 1 Market Data)

### Overview & Purpose

**Quotes API** provides access to **passive Level 1 market data**, delivering essential bid/ask pricing information across cryptocurrency markets.

**Core Data Elements:**
- **Best Bid Price**: Highest price buyers are willing to pay
- **Best Ask Price**: Lowest price sellers are willing to accept
- **Bid/Ask Sizes**: Volume available at best prices
- **Last Trade Information**: Most recent transaction details
- **Timestamps**: Exchange and CoinAPI receipt times

### Available Endpoints

#### Current Quote Data
- **All Symbols**: `GET /v1/quotes/current`
- **Specific Symbol**: `GET /v1/quotes/:symbol_id/current`

**Optional Parameters:**
- `filter_symbol_id`: Filter specific symbols for bulk requests

**Response Structure:**
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2025-08-31T10:30:00.000Z",
  "time_coinapi": "2025-08-31T10:30:00.100Z",
  "ask_price": 43280.50,
  "ask_size": 1.25,
  "bid_price": 43250.75,
  "bid_size": 2.10,
  "last_trade": {
    "price": 43265.00,
    "size": 0.5,
    "taker_side": "BUY"
  }
}
```

#### Historical & Latest Data
- **Historical Data**: `GET /v1/quotes/:symbol_id/history`
- **Latest Updates**: `GET /v1/quotes/latest`
- **Symbol-Specific Latest**: `GET /v1/quotes/:symbol_id/latest`

**Time-Based Features:**
- Historical quotes for backtesting and analysis
- Latest updates within the last minute
- Time-ascending order for historical data
- Time-descending order for latest data

**Strategic Applications:**
- Spread analysis and market microstructure studies
- Real-time price monitoring for trading applications
- Market liquidity assessment
- Best execution analysis

---

## 💰 Trades API (Transaction Data)

### Overview & Purpose

**Trades API** provides access to executed transaction data, offering comprehensive information about actual market activity and price discovery.

**Core Trade Information:**
- **Execution Price**: Actual transaction price
- **Trade Size**: Volume of assets traded
- **Taker Side**: Aggressor direction (BUY/SELL)
- **Timestamps**: Exchange execution and CoinAPI receipt times
- **Trade Identifiers**: Unique transaction tracking

### Available Endpoints

#### Historical Trade Data
**Endpoint**: `GET /v1/trades/:symbol_id/history`

**Parameters:**
- `symbol_id` (required): Trading pair identifier
- `date` (optional): ISO 8601 date for specific day
- `time_start/time_end` (optional): Intraday time range filters
- `limit` (optional): Result count (default: 100, max: 100,000)
- `include_id` (optional): Include additional trade identifiers

**Response Schema:**
```json
[
  {
    "symbol_id": "BITSTAMP_SPOT_BTC_USD",
    "time_exchange": "2025-08-31T10:30:00.000Z",
    "time_coinapi": "2025-08-31T10:30:00.050Z",
    "uuid": "unique-trade-identifier",
    "price": 43265.75,
    "size": 0.25,
    "taker_side": "BUY"
  }
]
```

#### Latest Trade Data
- **All Symbols**: `GET /v1/trades/latest`
- **Specific Symbol**: `GET /v1/trades/:symbol_id/latest`

**Data Characteristics:**
- **Historical**: Time-ascending order for chronological analysis
- **Latest**: Time-descending order (up to 1 minute ago)
- **Intraday Only**: Historical trades limited to same-day queries
- **Real-Time**: Latest trades provide near real-time transaction visibility

**Strategic Applications:**
- Volume analysis and market activity assessment
- Price discovery and execution quality analysis
- Market microstructure research
- Trading algorithm backtesting with real execution data

---

## 📊 Order Book L3 API (Level 3 Market Data)

### Overview & Purpose

**Order Book L3 API** provides detailed order book data representing "passive level 3 data" with individual order information, offering more granular market depth than Level 2 data.

**Key Differences from L2**:
- **Individual Order Details**: Each order includes unique identifiers
- **Enhanced Granularity**: More detailed order information
- **Order-by-Order Data**: Ability to track individual orders rather than aggregated levels

### Current Order Book Data

#### Current Order Book by Symbol
- **URL**: `GET /v1/orderbooks3/:symbol_id/current`
- **Purpose**: Retrieve the current L3 order book for a specific symbol
- **Required Parameters**:
  - `symbol_id` (string): Identifier for the specific trading symbol
- **Optional Parameters**:
  - `limit_levels` (int): Maximum number of order book levels to return
- **Response Fields**:
  - `symbol_id`: Symbol identifier
  - `time_exchange`: Timestamp from the exchange
  - `time_coinapi`: CoinAPI receipt timestamp
  - `asks`: List of sell orders with price, size, and unique ID
  - `bids`: List of buy orders with price, size, and unique ID
- **Example Response**:
```json
{
  "symbol_id": "COINBASE_SPOT_BCH_USD",
  "time_exchange": "2020-08-27T10:28:35.6111130Z",
  "time_coinapi": "2020-08-27T10:28:35.6766461Z",
  "asks": [
    {
      "id": "unique-order-id-1",
      "price": 272.89,
      "size": 1.0
    }
  ],
  "bids": [
    {
      "id": "unique-order-id-2",
      "price": 272.83,
      "size": 18.0
    }
  ]
}
```

#### Current Order Books (All Symbols)
- **URL**: `GET /v1/orderbooks3/current`
- **Purpose**: Retrieve current L3 order books across all symbols
- **Optional Parameters**:
  - `filter_symbol_id` (string): Filter results by symbol identifier
  - `limit_levels` (int): Set maximum number of order book levels to return
- **Response Characteristics**:
  - Returns an array of order book data
  - Each entry includes: `symbol_id`, `time_exchange`, `time_coinapi`, `asks`, `bids`
  - Provides real-time order book information with individual order tracking

**Key Features**:
- **Individual Order Tracking**: Unique identifiers for each order
- **Enhanced Market Depth**: More detailed than L2 aggregated data
- **Real-time Updates**: Current market state with precise timing
- **Flexible Filtering**: Filter by symbol or limit depth levels

**Response Formats**: JSON, text/plain, text/json, application/x-msgpack

---

## 📚 Order Book API (Level 2 Market Data)

### Overview & Architecture

**Order Book API** provides access to market depth information, also known as "books" or **passive Level 2 data**.

**Core Order Book Components:**
- **Bids**: Buy orders arranged by price (highest to lowest)
- **Asks**: Sell orders arranged by price (lowest to highest)
- **Price Levels**: Aggregated order volume at each price point
- **Market Depth**: Complete liquidity picture across price ranges

### Available Endpoints

#### Current Order Book Data
- **All Symbols**: `GET /v1/orderbooks/current`
- **Specific Symbol**: `GET /v1/orderbooks/:symbol_id/current`

**Parameters:**
- `symbol_id` (required for specific): Trading pair identifier
- `limit_levels` (optional): Maximum number of price levels to return
- `filter_symbol_id` (optional): Filter for bulk requests

**Response Structure:**
```json
{
  "symbol_id": "BITSTAMP_SPOT_BTC_USD",
  "time_exchange": "2025-08-31T10:30:00.000Z",
  "time_coinapi": "2025-08-31T10:30:00.100Z",
  "asks": [
    {"id": "order_id_1", "price": 43280.50, "size": 1.25},
    {"id": "order_id_2", "price": 43285.00, "size": 0.75}
  ],
  "bids": [
    {"id": "order_id_3", "price": 43250.75, "size": 2.10},
    {"id": "order_id_4", "price": 43245.00, "size": 1.50}
  ]
}
```

#### Historical & Latest Data
- **Historical Data**: `GET /v1/orderbooks/:symbol_id/history`
- **Latest Snapshots**: `GET /v1/orderbooks/:symbol_id/latest`

**Pricing Structure:**
> **Important**: `GET /v1/orderbooks/current` endpoint is charged **one request per 100 data points**

**Technical Features:**
- **Multi-Level Depth**: Support for 5, 20, 50 level configurations
- **Quote Integration**: Single-level requests may use quote data for speed
- **Feed Merging**: Some exchanges merge order book and quote feeds
- **Size Handling**: Size may be 0 when volume information unavailable

**Strategic Applications:**
- Market making strategy development
- Liquidity analysis and assessment
- Slippage estimation for large orders
- Market microstructure research
- Arbitrage opportunity identification

---

## ⚡ FIX API (Professional Trading Protocol)

### Overview & Specifications

**FIX API** implements the **Financial Information eXchange (FIX) 4.4** protocol for professional-grade, real-time market data transmission.

**Protocol Characteristics:**
- **Industry Standard**: Widely adopted in institutional trading
- **High Performance**: Optimized for low-latency data transmission
- **Stateful Connections**: Persistent session management
- **Message-Based**: Tag-value structured financial messages

**Target Users:**
> **Recommendation**: "If you don't have experience with FIX protocol, consider using a much simpler to implement REST or WebSocket API."

### Connection Infrastructure

#### Production Endpoints
- **Encrypted (TLS)**: `fix.coinapi.io:3303`
- **Unencrypted**: `fix.coinapi.io:3302`

#### Regional Endpoints
- **Americas (NCSA)**: Optimized for North/South America
- **Europe/Middle East/Africa (EMEA)**: European datacenter access
- **Asia Pacific (APAC)**: Asian market optimization

**Security Implementation:**
- **TLS Protocol**: Encrypted connections on secure ports
- **Proxy Support**: Use stunnel for additional encryption layers
- **Authentication**: FIX session-based authentication

### Recommended Client Libraries

**Multi-Language Support:**
- **C++**: QuickFIX - Industry-standard FIX engine
- **C#**: QuickFIX/N - .NET implementation
- **Java**: QuickFIX/J - Java-based FIX engine
- **Python**: QuickFIX Python - Python bindings
- **Ruby**: QuickFIX Ruby - Ruby implementation
- **Go**: QuickFIX Go - Go language implementation

**Implementation Considerations:**
- **Session Management**: Proper logon/logout sequences
- **Message Validation**: FIX protocol compliance
- **Heartbeat Handling**: Connection health monitoring
- **Error Recovery**: Reconnection and resynchronization

**Use Cases:**
- **Institutional Trading**: Professional trading platform integration
- **High-Frequency Trading**: Ultra-low latency requirements
- **Market Making**: Advanced order management
- **Risk Management**: Real-time position monitoring
- **Compliance**: Audit trail and regulatory requirements

**Alternative Recommendations:**
For users without FIX protocol experience, CoinAPI offers simpler alternatives:
- **REST API**: Request-response pattern for basic integration
- **WebSocket API**: Real-time streaming with easier implementation

---
*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added Order Book L3 API, Enhanced Metadata Endpoints, Comprehensive How-to Guides, Latency FAQ, Performance Testing Guide, and JSON-RPC API to achieve 100% Market-Data Coverage*

---

## Latency FAQ

### Overview
Comprehensive guide for technical professionals to understand and address latency-related challenges in cryptocurrency market data APIs. This FAQ provides insights into latency concepts, influencing factors, and optimization strategies.

### What Influences Latency

#### Geographic Distance
- **Direct Path Impact**: Geographic distance significantly affects latency
- **Example**: Direct path from London to Binance is approximately 250ms
- **Challenge**: Some matching engines are inherently located far from clients

#### Infrastructure Considerations
To achieve low latency (below 100ms), organizations need:
- **Additional Data Centers**: Strategic placement of servers
- **Optimized Network Configurations**: Specialized network topology
- **Network Infrastructure Investment**: Dedicated network resources

#### Client-Side Factors
- **Customer Infrastructure**: Client's own infrastructure plays crucial role
- **Network Setup**: Local network configuration affects overall performance
- **Hardware Considerations**: Processing power and network equipment quality

### How to Reduce Market Data API Latency

#### Network Optimization Strategies

##### AWS Direct Connect
- **Purpose**: Dedicated, direct connection to AWS services
- **Benefits**: Reduced network hops, consistent performance
- **Use Case**: Enterprise-grade connectivity for critical applications

##### AWS VPC Peering
- **Purpose**: Keep data transmission within AWS environment
- **Benefits**: Lower latency, improved security
- **Implementation**: Direct VPC-to-VPC communication

##### GeoDNS Routing
- **Purpose**: Route data through nearest server
- **Benefits**: Minimized geographic distance
- **Implementation**: Automatic routing to closest datacenter

#### Data Transmission Strategies

##### WebSocket API
- **Purpose**: Real-time, continuous data transmission
- **Benefits**: Persistent connection, immediate updates
- **Use Case**: Live market data streaming
- **Implementation**: Maintain active WebSocket connections

##### Effective Data Caching
- **Purpose**: Reduce repeated data fetching
- **Benefits**: Faster response times, reduced API calls
- **Strategies**: Cache frequently accessed market data locally

##### FIX API
- **Purpose**: High-frequency trading environments
- **Benefits**: Industry-standard protocol, optimized for low latency
- **Use Case**: Professional trading applications

#### Performance Monitoring

##### Service Level Agreements (SLAs)
- **Purpose**: Define acceptable latency thresholds
- **Benefits**: Clear performance expectations
- **Implementation**: Monitor and track SLA compliance

##### Real-time Performance Monitoring
- **Purpose**: Continuous latency tracking
- **Benefits**: Early problem detection
- **Tools**: Latency measurement dashboards

##### Alert Systems
- **Purpose**: Proactive notification of latency spikes
- **Benefits**: Immediate response to performance issues
- **Implementation**: Automated alert triggers

#### Critical Optimization Principles

1. **Minimize Data Travel Distance**: Use geographically distributed servers
2. **Maintain Continuous Connections**: Avoid connection overhead
3. **Cache Frequently Used Data**: Reduce API call frequency
4. **Monitor Proactively**: Track performance metrics continuously
5. **Strategic Server Placement**: Position servers near trading venues

#### Key Performance Considerations

- **Sub-100ms Latency**: May require additional data centers
- **Provider vs Customer**: Latency depends on both infrastructure setups
- **Competitive Edge**: "Even the smallest delays can make a big difference"
- **Environment-Specific**: Optimization strategies vary by use case

**Target Audience**: Technical professionals, system administrators, developers working with high-frequency market data applications

---

## Performance Testing Guide

### Overview
Comprehensive guide for testing and optimizing CoinAPI performance across different interfaces (REST, WebSocket, FIX) with detailed methodologies and best practices.

### Performance Testing Methodologies

#### REST API Performance Testing
**Tool**: curl commands on Linux
**Measured Metrics**:
- Name lookup time
- Connection time
- Total request time
- Detailed timing breakdowns

**Implementation**: Uses curl with timing parameters to benchmark HTTP request performance

#### WebSocket API Performance Testing
**Requirements**: .NET 8.0+
**Captured Metrics**:
- Message counts
- Latency measurements
- Connection performance

**Approach**: Multiple connections for comprehensive testing
**Tools**: GitHub repositories with client applications provided

#### FIX Protocol Testing
**Engine**: QuickFix
**Capabilities**:
- Session management
- Data subscription
- Message processing
- Protocol-specific performance metrics

### Good Performance Testing Practices

#### Key Recommendations

##### Message Handling
- **Fetch Messages Quickly**: Minimize retrieval delays
- **Separate Processing Threads**: Decouple data acquisition from processing
- **Strategic Multithreading**: Implement parallel processing efficiently

##### Connection Management
- **Multiple Connections**: Distribute load across connections
- **Thread Utilization**: "If latency increases, split data acquisition across multiple connections to utilize more threads effectively"
- **Load Distribution**: Balance traffic across available resources

#### Testing Strategy
1. **Baseline Measurement**: Establish performance benchmarks
2. **Load Testing**: Test under various traffic conditions  
3. **Latency Monitoring**: Track response times continuously
4. **Scalability Testing**: Verify performance with increased load

#### Tools and Resources
- **GitHub Repositories**: WebSocket and FIX client applications
- **Configuration Guides**: Detailed setup instructions
- **Testing Scripts**: Pre-built performance testing utilities

---

## JSON-RPC API

### Overview
Lightweight JSON-RPC 2.0 protocol interface providing flexible access to CoinAPI market data resources.

### Connection Details
- **Endpoint**: `https://rest.coinapi.io/jsonrpc`
- **Protocol**: JSON-RPC 2.0
- **Authentication**: API key required

### Request Structure
**Standard JSON-RPC 2.0 Format**:
```json
{
  "jsonrpc": "2.0",
  "method": "v1/resource",
  "params": [],
  "id": "tracking-id"
}
```

### Available Methods

#### Get Exchanges
- **Method**: `v1/exchanges`
- **Purpose**: Retrieve list of cryptocurrency exchanges
- **Response**: Exchange metadata including names, IDs, and details

#### Get Exchange Rates
- **Method**: `v1/exchangerate/BTC`
- **Purpose**: Retrieve current exchange rates for specified asset
- **Example**: Bitcoin exchange rates across different quote currencies

#### Get Symbols
- **Method**: `v1/symbols`
- **Purpose**: Retrieve trading symbols with filtering support
- **Filters**: By exchange, symbol, or asset
- **Response**: Symbol details and trading pair information

### Error Handling

#### Standard HTTP Errors
- **400 Error**: Invalid request format or parameters
- **404 Error**: Resource not found or unavailable
- **Authentication Errors**: Invalid or missing API key

#### JSON-RPC Error Format
```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32602,
    "message": "Invalid params"
  },
  "id": "tracking-id"
}
```

### Key Benefits

#### Protocol Advantages
- **Lightweight**: Minimal overhead compared to REST
- **Flexible Resource Access**: Single endpoint for multiple operations
- **Standard Compliance**: Full JSON-RPC 2.0 compatibility
- **REST Compatibility**: Methods map to existing REST endpoints

#### Use Cases
- **Batch Operations**: Multiple requests in single call
- **Legacy System Integration**: JSON-RPC protocol compatibility
- **Simplified Architecture**: Single endpoint for all operations
- **Custom Client Implementation**: Flexible method calling

**Implementation Note**: Compatible with all REST API endpoints through JSON-RPC method mapping

---

## Model Context Protocol (MCP) Servers

### Overview & Purpose

**Model Context Protocol (MCP) Servers** provide a unified interface for accessing multiple APIs through a single, standardized endpoint, transforming traditional HTTP APIs into self-describing JSON-Schema functions.

#### Core MCP Capabilities
- **API Consolidation**: Single endpoint for accessing multiple services
- **Schema Validation**: Automatic JSON-Schema validation for API requests
- **Autonomous Discovery**: Agents can discover and validate API functionality
- **Zero-Day Coverage**: Automatic support for new API routes
- **Unified Authentication**: Consistent authentication across multiple services

#### Key Benefits for Developers
- **Simplified Integration**: Reduce API integration complexity
- **Reduced Boilerplate**: Eliminate repetitive API integration code
- **Accelerated Development**: Speed up development cycles
- **Consistent Interface**: Standardized access to heterogeneous APIs
- **Client/Server Consolidation**: Unified management approach

### MCP Endpoint Architecture

#### Primary Endpoint Variants

##### 1. HTTP Streaming Endpoint (Bidirectional)
- **URL**: `https://mcp.api.apibricks.io/mcp`
- **Type**: HTTP streaming with bidirectional communication
- **Use Case**: Real-time, interactive API access with response streaming
- **Features**: Full duplex communication, real-time updates

##### 2. Server-Sent Events Endpoint (One-Way)
- **URL**: `https://mcp.api.apibricks.io/sse`
- **Type**: Server-Sent Events for one-way updates
- **Use Case**: Real-time notifications and data streaming
- **Features**: Push notifications, live data feeds

#### Composite MCP Endpoint
- **URL**: `https://mcp.api.apibricks.io/mcp`
- **Purpose**: Aggregates all individual server endpoints into single access point
- **Benefit**: "Treat a heterogeneous fleet of APIs as a single, extensible RPC surface"

### Supported API Services

#### Financial Data Services
- **FinFeedAPI**: SEC filings, stock data, foreign exchange
- **CoinAPI**: Comprehensive cryptocurrency market data
  - Market Data API endpoints
  - Exchange rates and timeseries data
  - Indexes API (PRIMKT, VWAP, CAPIVIX)
  - Real-time WebSocket streaming
  - Historical data access

#### CoinAPI Integration Benefits
- **Unified Access**: Single MCP endpoint for all CoinAPI functionality
- **Schema Validation**: Automatic validation of CoinAPI requests
- **Simplified Authentication**: Consistent auth across all endpoints
- **Discovery**: Autonomous agents can explore CoinAPI capabilities
- **Error Handling**: Standardized error responses and validation

### MCP Implementation Examples

#### Basic MCP Request
```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "coinapi_exchange_rate",
    "arguments": {
      "base_asset": "BTC",
      "quote_asset": "USD"
    }
  },
  "id": "request_1"
}
```

#### MCP Response Format
```json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Current BTC/USD rate: 43,250.75"
      }
    ],
    "isError": false
  },
  "id": "request_1"
}
```

### Technical Architecture

#### JSON-Schema Function Transformation
- **Input**: Traditional HTTP API endpoints
- **Process**: Transform to self-describing JSON-Schema functions
- **Output**: Discoverable, validatable API functions
- **Benefit**: Autonomous agents can understand and use APIs without manual configuration

#### Validation Framework
- **Request Validation**: Automatic parameter validation before API calls
- **Response Validation**: Ensure API responses meet expected schema
- **Error Handling**: Standardized error messages and codes
- **Type Safety**: Strong typing through JSON Schema definitions

### Use Cases & Applications

#### Autonomous Agent Integration
- **AI Assistant**: Agents can discover and use CoinAPI functions autonomously
- **Trading Bots**: Automated trading systems with unified API access
- **Portfolio Management**: Consolidated access to market data and metrics
- **Research Tools**: Streamlined data access for analysis applications

#### Development Workflow Benefits
- **Rapid Prototyping**: Quick API integration without boilerplate
- **Consistent Interface**: Same patterns across different APIs
- **Automatic Documentation**: Self-describing functions with schemas
- **Testing Simplification**: Unified testing approach for multiple APIs

#### Enterprise Integration
- **Microservices**: Unified API gateway for distributed systems
- **Multi-Vendor APIs**: Consistent access to different service providers
- **Legacy System Integration**: Modernize API access patterns
- **Compliance**: Standardized validation and audit trails

### Getting Started with MCP

#### Prerequisites
- Understanding of JSON-RPC 2.0 protocol
- API authentication credentials for desired services
- Client capable of HTTP streaming or Server-Sent Events

#### Basic Integration Steps
1. **Connect**: Establish connection to MCP endpoint
2. **Discover**: Query available tools and their schemas
3. **Validate**: Use JSON Schema validation for requests
4. **Execute**: Call API functions through MCP interface
5. **Handle**: Process standardized responses and errors

#### Best Practices
- **Schema Validation**: Always validate requests against provided schemas
- **Error Handling**: Implement robust error handling for API failures
- **Authentication**: Secure API key management and rotation
- **Rate Limiting**: Respect underlying API rate limits
- **Monitoring**: Track API usage and performance metrics

**Strategic Value**: MCP Servers enable treating "a heterogeneous fleet of APIs as a single, extensible RPC surface—simplifying integration, reducing boilerplate, and speeding up development cycles."

---

*Created: 2025-08-31*
*Last Updated: 2025-08-31 - Added comprehensive authentication, SDK support, REST API framework, WebSocket documentation, and Model Context Protocol (MCP) Servers for unified API access*