# CoinAPI Module

## Overview
Comprehensive CoinAPI integration library with **170+ documented endpoints** covering the complete cryptocurrency data ecosystem. Built for enterprise-grade applications with modular architecture for reuse across multiple projects.

## Structure
```
COINAPI/
├── docs/           # API documentation & knowledge base
│   ├── COINAPI.md     # Complete API documentation
│   └── COINAPI_BLOG.md # Blog insights & tutorials
├── src/
│   ├── modules/    # Reusable API modules
│   │   ├── auth.js        # Authentication & config
│   │   ├── marketData.js  # REST API methods
│   │   └── websocket.js   # WebSocket client
│   ├── types/      # TypeScript definitions
│   │   └── index.ts       # Type definitions
│   ├── utils/      # Helper utilities
│   │   └── index.js       # Utility functions
│   └── index.js    # Main export
├── examples/       # Usage examples
│   └── usage.js       # Example implementations
├── tests/          # Test files
└── package.json    # Dependencies
```

## Installation

### Local Development
```bash
cd COINAPI
npm install
npm link
```

### In Other Projects
```bash
npm link ../COINAPI
# or
import { MarketData, WebSocketClient } from '../COINAPI/src/index.js'
```

## Quick Start

### Environment Setup
```bash
# Create .env file
COINAPI_KEY=your_api_key_here
COINAPI_BASE_URL=https://rest.coinapi.io
```

### REST API Usage
```javascript
import { MarketData } from 'coinapi-module';

const api = new MarketData();

// Get Bitcoin price
const btcPrice = await api.getExchangeRate('BTC', 'USD');
console.log(`BTC: $${btcPrice.rate}`);

// Get OHLCV data
const ohlcv = await api.getOHLCV('BITSTAMP_SPOT_BTC_USD', {
  periodId: '1DAY',
  limit: 30
});
```

### WebSocket Usage
```javascript
import { WebSocketClient } from 'coinapi-module';

const ws = new WebSocketClient();
await ws.connect();

// Subscribe to trades
ws.subscribeTrades(['BITSTAMP_SPOT_BTC_USD'], (trade) => {
  console.log(`Trade: ${trade.size} BTC at $${trade.price}`);
});

// Subscribe to order book
ws.subscribeOrderBook(['BITSTAMP_SPOT_BTC_USD'], (orderbook) => {
  console.log(`Order Book updated: ${orderbook.asks.length} asks`);
}, 5); // 5 levels depth
```

## Features

### ✅ Complete CoinAPI Ecosystem Coverage

**🏆 Market-Data API (90+ endpoints)**
- **Real-Time Streaming**: WebSocket trades, quotes, order book (L1/L2/L3)
- **Historical Data**: OHLCV, trades, quotes with all time periods (5SEC to 5YRS) 
- **Market Depth**: Order book analysis (5/20/50 levels), liquidity assessment
- **Exchange Rates**: Current and historical rates with VWAP-24H calculation
- **Metadata**: Assets, exchanges, symbols, blockchain chains information
- **MetricsV1/V2**: Trading volume, market depth, derivatives pricing, funding rates
- **Options Data**: Greeks calculations (Delta, Gamma, Theta, Vega), strike prices
- **Multi-Protocol**: REST, WebSocket V1/DS, FIX 4.4, JSON-RPC 2.0 support

**💾 Flat Files API (30+ endpoints)**  
- **S3-Compatible Access**: Industry-standard bulk data retrieval patterns
- **Historical Archives**: Complete market data in compressed CSV format
- **Snowflake Integration**: SQL-based analytics on 7+ datasets (assets, trades, quotes, OHLCV)
- **Push API**: Automated data delivery to customer S3 buckets
- **Data Types**: Quotes, trades, full limit order book, OHLCV (coming)
- **Multi-Language SDKs**: Python boto3, JavaScript AWS SDK, Java, C#, Ruby, PHP, Go

**📈 Indexes API (50+ links)**
- **PRIMKT**: Principal Market Price Index for fair value pricing
- **VWAP**: Volume Weighted Average Price for execution quality measurement  
- **CAPIVIX**: Volatility Index for market sentiment and risk assessment
- **Real-Time Access**: REST and WebSocket APIs for live index values
- **Methodology**: Transparent calculation and governance documentation

**⚡ Advanced Trading Infrastructure**
- **High-Frequency Strategies**: Statistical arbitrage, cross-exchange, market making, momentum, scalping
- **Low-Latency Optimization**: Sub-millisecond execution, AWS Direct Connect, VPC peering
- **Protocol Hierarchy**: FIX < WebSocket < REST latency performance ranking
- **Market Making Framework**: Liquidity provision, revenue models, risk management
- **Infrastructure Requirements**: Multi-exchange connectivity, real-time data access

**🔐 Authentication & Security Framework**
- **5 Primary Methods**: API key header, query string, URL path, Bearer token, Basic auth
- **Advanced JWT**: RS256/PS256/ES256/HS256 algorithms with public key validation
- **Protocol-Specific**: FIX authentication, AWS Signature V4 for Flat Files
- **Security Best Practices**: Environment variables, HTTPS only, key rotation, scope limitation

**🌐 Multi-Language SDK Ecosystem**
- **Web Development**: JavaScript, TypeScript, PHP with framework integrations
- **Enterprise Backend**: Java, C#/.NET, C++, Python, Ruby, Go for scalable applications  
- **Data Analysis**: Python (pandas/numpy), R, MATLAB for research and modeling
- **Mobile Development**: React Native, Android (Java/Kotlin) with native implementations
- **Testing & DevOps**: Unit testing, integration testing, mocking, CI/CD pipeline support

**🤖 Model Context Protocol (MCP) Integration**
- **Unified API Access**: Single endpoint for heterogeneous API fleet management
- **Schema Validation**: Automatic JSON-Schema validation and autonomous discovery
- **AI Agent Support**: Self-describing functions for autonomous trading systems
- **Enterprise Integration**: Microservices architecture, multi-vendor API consistency

### ✅ REST API Module
- Exchange rates (current, historical, timeseries)
- OHLCV data with all time periods
- Trades (historical, latest)
- Quotes (current, historical)
- Order book (current, historical)
- Metadata (exchanges, assets, symbols)
- Built-in error handling & retries
- Rate limiting protection

### ✅ WebSocket Module
- Real-time trade data
- Live quotes (bid/ask)
- Order book updates (5/20/50 levels)
- OHLCV streaming
- Auto-reconnection with exponential backoff
- Subscription management
- Heartbeat handling

### ✅ Authentication Module
- API key management
- Environment variable support
- Connection testing
- Header generation

### ✅ Utility Functions
- Symbol ID parsing/building
- Volume/currency formatting
- Percentage calculations
- Time utilities
- Rate limiting
- Retry mechanisms

### ✅ TypeScript Support
- Complete type definitions
- Interface declarations
- Type-safe API calls

## 🎯 Comprehensive Use Cases

Perfect for diverse cryptocurrency applications:

### 📊 **Volume Spike Detection**
```javascript
import { MarketData, WebSocketClient, utils } from 'coinapi-module';

// Get historical average
const api = new MarketData();
const historical = await api.getOHLCV('BITSTAMP_SPOT_BTC_USD', {
  periodId: '1HRS', 
  limit: 24
});

const avgVolume = historical.reduce((sum, candle) => 
  sum + candle.volume_traded, 0) / historical.length;

// Monitor real-time for spikes
const ws = new WebSocketClient();
await ws.connect();

ws.subscribeTrades(['BITSTAMP_SPOT_BTC_USD'], (trade) => {
  // Volume spike detection logic
  if (currentVolume > avgVolume * 2) {
    console.log('🚨 VOLUME SPIKE DETECTED!');
  }
});
```

### 💰 **Market Making Strategy**
```javascript
// Get order book depth for liquidity analysis
const orderBook = await api.getCurrentOrderBook('BINANCE_SPOT_BTC_USDT');
const spread = orderBook.asks[0].price - orderBook.bids[0].price;

// Real-time order book monitoring for market making
ws.subscribeOrderBook(['BINANCE_SPOT_BTC_USDT'], (book) => {
  if (spread > threshold) {
    // Place market making orders
    console.log('💹 Market Making Opportunity');
  }
}, 20); // 20 levels depth
```

### 🏦 **Portfolio Management**
```javascript
// Multi-asset portfolio tracking
const assets = ['BTC', 'ETH', 'ADA', 'DOT'];
const portfolio = [];

for (const asset of assets) {
  const price = await api.getExchangeRate(asset, 'USD');
  const ohlcv = await api.getLatestOHLCV(`BINANCE_SPOT_${asset}_USDT`, '1DAY', 30);
  
  portfolio.push({
    asset,
    currentPrice: price.rate,
    volatility: utils.calculateVolatility(ohlcv),
    performance30d: utils.calculatePerformance(ohlcv)
  });
}
```

### ⚡ **High-Frequency Trading (HFT)**
```javascript
// Cross-exchange arbitrage detection
const exchanges = ['BINANCE', 'COINBASE', 'KRAKEN'];
const arbitrageOpportunities = [];

for (const exchange of exchanges) {
  const orderBook = await api.getCurrentOrderBook(`${exchange}_SPOT_BTC_USD`);
  arbitrageOpportunities.push({
    exchange,
    bestBid: orderBook.bids[0].price,
    bestAsk: orderBook.asks[0].price
  });
}

// Detect arbitrage opportunities
const priceDiff = Math.max(...arbitrageOpportunities.map(o => o.bestBid)) - 
                 Math.min(...arbitrageOpportunities.map(o => o.bestAsk));
if (priceDiff > minProfitThreshold) {
  console.log('🚀 ARBITRAGE OPPORTUNITY DETECTED');
}
```

### 📈 **Derivatives & Options Trading**
```javascript
// Options Greeks monitoring
const optionsData = await api.getOptionsData('DERIBIT');
const btcOptions = optionsData.filter(opt => opt.underlying === 'BTC');

// Monitor funding rates for perpetual contracts
ws.subscribeMetrics('BINANCE_PERP_BTC_USD', (metrics) => {
  if (metrics.metric_id === 'FUNDING_RATE') {
    console.log(`Funding Rate: ${metrics.value}%`);
  }
});
```

### 📊 **Market Research & Analytics**
```javascript
// Volatility index analysis
const volatilityIndex = await api.getIndexData('CAPIVIX');
const marketSentiment = volatilityIndex.value > 80 ? 'FEAR' : 'GREED';

// Historical correlation analysis
const btcData = await api.getOHLCV('COINBASE_SPOT_BTC_USD', {periodId: '1DAY', limit: 90});
const ethData = await api.getOHLCV('COINBASE_SPOT_ETH_USD', {periodId: '1DAY', limit: 90});
const correlation = utils.calculateCorrelation(btcData, ethData);
```

## Usage in Other Projects

### Project Integration
```javascript
// In volume-spike-bot project
import { MarketData, WebSocketClient } from '../COINAPI/src/index.js';

const api = new MarketData(process.env.COINAPI_KEY);
const ws = new WebSocketClient(process.env.COINAPI_KEY);
```

### npm Link Method
```bash
# In COINAPI directory
npm link

# In other project directory
npm link coinapi-module

# Then import normally
import { MarketData } from 'coinapi-module';
```

## Error Handling

Built-in error handling with retries:

```javascript
try {
  const data = await api.getExchangeRate('BTC', 'USD');
} catch (error) {
  if (error.message.includes('429')) {
    // Rate limit hit - automatic retry with backoff
  }
  if (error.message.includes('401')) {
    // Invalid API key
  }
}
```

## Documentation

### 📚 Comprehensive CoinAPI Knowledge Base
- **Complete API Ecosystem**: `docs/COINAPI.md` - **170+ endpoints documented**
  - ✅ Market-Data API (90+ endpoints) - REST, WebSocket, Metadata, OHLCV, Trades, Quotes, Order Book
  - ✅ Flat Files API (30+ endpoints) - S3, Snowflake, Push API with bulk data access
  - ✅ Indexes API (50+ links) - PRIMKT, VWAP, CAPIVIX with benchmarking frameworks
  - ✅ Advanced Trading Infrastructure - HFT strategies, market making, low-latency optimization
  - ✅ Authentication Framework - 5 methods + JWT + security best practices
  - ✅ Programming Language SDKs - 10+ languages with integration examples
  - ✅ Model Context Protocol (MCP) - Unified API access for AI agents
- **Blog Insights**: `docs/COINAPI_BLOG.md` - Industry analysis & tutorials
- **Implementation Examples**: `examples/usage.js` - Practical code samples
- **TypeScript Definitions**: `src/types/index.ts` - Complete type safety

## Testing

```bash
npm test  # Run tests
npm run dev  # Run examples
```

## Contributing

1. Read `docs/COINAPI.md` for API understanding
2. Add tests for new features
3. Update TypeScript definitions
4. Follow existing code patterns