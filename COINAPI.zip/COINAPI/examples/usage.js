/**
 * Example usage of CoinAPI modules
 * Demonstrates how to use the reusable API modules in other projects
 */

import { MarketData, WebSocketClient, utils } from '../src/index.js';

// =====================
// REST API Examples
// =====================

async function restApiExamples() {
  try {
    // Initialize with API key from environment
    const api = new MarketData();
    
    // Test connection
    console.log('Testing API connection...');
    await api.testConnection();
    console.log('✅ Connection successful');
    
    // Get Bitcoin price in USD
    console.log('\n📊 Getting Bitcoin price...');
    const btcPrice = await api.getExchangeRate('BTC', 'USD');
    console.log(`BTC/USD: $${btcPrice.rate.toLocaleString()}`);
    
    // Get OHLCV data for Bitcoin
    console.log('\n📈 Getting OHLCV data...');
    const ohlcv = await api.getLatestOHLCV('BITSTAMP_SPOT_BTC_USD', '1DAY', 7);
    console.log(`Last 7 days OHLCV data: ${ohlcv.length} records`);
    
    // Get latest trades
    console.log('\n💰 Getting latest trades...');
    const trades = await api.getLatestTrades('BITSTAMP_SPOT_BTC_USD', 10);
    console.log(`Latest 10 trades fetched`);
    
    // Get all exchanges
    console.log('\n🏢 Getting exchanges...');
    const exchanges = await api.getExchanges();
    console.log(`Total exchanges: ${exchanges.length}`);
    
  } catch (error) {
    console.error('❌ REST API Error:', error.message);
  }
}

// =====================
// WebSocket Examples
// =====================

async function webSocketExamples() {
  try {
    // Initialize WebSocket client
    const ws = new WebSocketClient();
    
    // Set up event handlers
    ws.onConnect(() => {
      console.log('🔌 WebSocket connected');
    });
    
    ws.onDisconnect((event) => {
      console.log('🔌 WebSocket disconnected:', event.reason);
    });
    
    ws.onError((error) => {
      console.error('❌ WebSocket error:', error);
    });
    
    // Connect to WebSocket
    console.log('Connecting to WebSocket...');
    await ws.connect();
    
    // Subscribe to trade data
    const tradeSubscription = ws.subscribeTrades(['BITSTAMP_SPOT_BTC_USD'], (trade) => {
      console.log(`🔄 Trade: ${trade.size} BTC at $${trade.price} (${trade.taker_side})`);
    });
    
    // Subscribe to quote data
    const quoteSubscription = ws.subscribeQuotes(['BITSTAMP_SPOT_BTC_USD'], (quote) => {
      console.log(`📊 Quote: Bid $${quote.bid_price} | Ask $${quote.ask_price}`);
    });
    
    // Subscribe to order book (5 levels)
    const bookSubscription = ws.subscribeOrderBook(['BITSTAMP_SPOT_BTC_USD'], (orderbook) => {
      console.log(`📖 Order Book: ${orderbook.asks.length} asks, ${orderbook.bids.length} bids`);
    }, 5);
    
    // Run for 30 seconds then cleanup
    setTimeout(() => {
      console.log('🛑 Cleaning up subscriptions...');
      tradeSubscription.unsubscribe();
      quoteSubscription.unsubscribe();
      bookSubscription.unsubscribe();
      ws.disconnect();
    }, 30000);
    
  } catch (error) {
    console.error('❌ WebSocket Error:', error.message);
  }
}

// =====================
// Utility Examples
// =====================

function utilityExamples() {
  console.log('\n🔧 Utility Functions Examples:');
  
  // Parse symbol ID
  const symbolInfo = utils.parseSymbolId('BITSTAMP_SPOT_BTC_USD');
  console.log('Symbol info:', symbolInfo);
  
  // Build symbol ID
  const symbolId = utils.buildSymbolId('BINANCE', 'SPOT', 'ETH', 'USDT');
  console.log('Built symbol ID:', symbolId);
  
  // Calculate percentage change
  const change = utils.calculatePercentChange(30000, 31500);
  console.log(`Price change: ${change.toFixed(2)}%`);
  
  // Format volume
  const volume = utils.formatVolume(1234567890);
  console.log(`Formatted volume: ${volume}`);
  
  // Format currency
  const price = utils.formatCurrency(31234.56, 2, '$');
  console.log(`Formatted price: ${price}`);
}

// =====================
// Advanced Trading Examples
// =====================

async function marketMakingExample() {
  try {
    console.log('\n💹 Market Making Strategy Example');
    const api = new MarketData();
    const ws = new WebSocketClient();
    
    // Get initial order book depth
    const orderBook = await api.getCurrentOrderBook('BINANCE_SPOT_BTC_USDT');
    const spread = orderBook.asks[0].price - orderBook.bids[0].price;
    console.log(`Initial spread: $${spread.toFixed(2)}`);
    
    await ws.connect();
    
    // Monitor order book for market making opportunities
    ws.subscribeOrderBook(['BINANCE_SPOT_BTC_USDT'], (book) => {
      const currentSpread = book.asks[0].price - book.bids[0].price;
      const midPrice = (book.asks[0].price + book.bids[0].price) / 2;
      
      if (currentSpread > 50) { // Spread threshold in USDT
        console.log(`💰 Market Making Opportunity: Spread $${currentSpread.toFixed(2)} at mid-price $${midPrice.toFixed(2)}`);
        // Place buy order below mid and sell order above mid
        console.log(`📝 Would place: BUY at $${(midPrice - 10).toFixed(2)}, SELL at $${(midPrice + 10).toFixed(2)}`);
      }
    }, 20); // 20 levels depth for liquidity analysis
    
  } catch (error) {
    console.error('❌ Market Making Error:', error.message);
  }
}

async function arbitrageDetectionExample() {
  try {
    console.log('\n🚀 Cross-Exchange Arbitrage Detection');
    const api = new MarketData();
    
    const exchanges = ['BINANCE', 'COINBASE', 'KRAKEN', 'BITSTAMP'];
    const opportunities = [];
    
    for (const exchange of exchanges) {
      try {
        const orderBook = await api.getCurrentOrderBook(`${exchange}_SPOT_BTC_USD`);
        opportunities.push({
          exchange,
          bestBid: orderBook.bids[0].price,
          bestAsk: orderBook.asks[0].price,
          bidVolume: orderBook.bids[0].size,
          askVolume: orderBook.asks[0].size
        });
      } catch (error) {
        console.log(`⚠️ ${exchange} data unavailable`);
      }
    }
    
    // Find arbitrage opportunities
    const bestBidExchange = opportunities.reduce((max, curr) => max.bestBid > curr.bestBid ? max : curr);
    const bestAskExchange = opportunities.reduce((min, curr) => min.bestAsk < curr.bestAsk ? min : curr);
    
    const priceDiff = bestBidExchange.bestBid - bestAskExchange.bestAsk;
    const profitPercentage = (priceDiff / bestAskExchange.bestAsk) * 100;
    
    if (priceDiff > 100) { // $100 minimum profit threshold
      console.log(`🎯 ARBITRAGE OPPORTUNITY:`);
      console.log(`   Buy from ${bestAskExchange.exchange} at $${bestAskExchange.bestAsk}`);
      console.log(`   Sell to ${bestBidExchange.exchange} at $${bestBidExchange.bestBid}`);
      console.log(`   Profit: $${priceDiff.toFixed(2)} (${profitPercentage.toFixed(2)}%)`);
    } else {
      console.log('📊 No profitable arbitrage opportunities found');
    }
    
  } catch (error) {
    console.error('❌ Arbitrage Detection Error:', error.message);
  }
}

async function portfolioManagementExample() {
  try {
    console.log('\n🏦 Portfolio Management & Risk Assessment');
    const api = new MarketData();
    
    const portfolio = [
      { symbol: 'BTC', allocation: 0.4 },
      { symbol: 'ETH', allocation: 0.3 },
      { symbol: 'ADA', allocation: 0.15 },
      { symbol: 'DOT', allocation: 0.15 }
    ];
    
    const portfolioData = [];
    
    for (const asset of portfolio) {
      const price = await api.getExchangeRate(asset.symbol, 'USD');
      const ohlcv = await api.getLatestOHLCV(`BINANCE_SPOT_${asset.symbol}_USDT`, '1DAY', 30);
      
      // Calculate volatility (standard deviation of daily returns)
      const returns = ohlcv.slice(1).map((candle, i) => 
        (candle.price_close - ohlcv[i].price_close) / ohlcv[i].price_close
      );
      const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
      const volatility = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length) * Math.sqrt(365);
      
      portfolioData.push({
        symbol: asset.symbol,
        allocation: asset.allocation,
        currentPrice: price.rate,
        volatility: volatility * 100, // Convert to percentage
        monthlyReturn: ((ohlcv[ohlcv.length - 1].price_close - ohlcv[0].price_close) / ohlcv[0].price_close) * 100
      });
    }
    
    console.log('📊 Portfolio Analysis:');
    portfolioData.forEach(asset => {
      console.log(`   ${asset.symbol}: $${asset.currentPrice.toLocaleString()} | Vol: ${asset.volatility.toFixed(1)}% | 30d: ${asset.monthlyReturn.toFixed(1)}%`);
    });
    
    // Portfolio-level metrics
    const portfolioVolatility = Math.sqrt(portfolioData.reduce((sum, asset) => 
      sum + Math.pow(asset.allocation * asset.volatility, 2), 0));
    console.log(`📈 Portfolio Volatility: ${portfolioVolatility.toFixed(1)}%`);
    
  } catch (error) {
    console.error('❌ Portfolio Management Error:', error.message);
  }
}

async function derivativesAnalysisExample() {
  try {
    console.log('\n📈 Derivatives & Options Analysis');
    const api = new MarketData();
    const ws = new WebSocketClient();
    
    // Get perpetual contract funding rates
    console.log('💰 Funding Rates Analysis:');
    const symbols = ['BINANCE_PERP_BTC_USD', 'BINANCE_PERP_ETH_USD'];
    
    for (const symbol of symbols) {
      try {
        const metrics = await api.getMetrics(symbol);
        const fundingRate = metrics.find(m => m.metric_id === 'FUNDING_RATE');
        if (fundingRate) {
          console.log(`   ${symbol.split('_')[2]}: ${(fundingRate.value * 100).toFixed(4)}% funding rate`);
        }
      } catch (error) {
        console.log(`⚠️ ${symbol} metrics unavailable`);
      }
    }
    
    // Monitor real-time funding rate changes
    await ws.connect();
    
    ws.subscribeMetrics('BINANCE_PERP_BTC_USD', (metrics) => {
      if (metrics.metric_id === 'FUNDING_RATE') {
        const rate = metrics.value * 100;
        if (Math.abs(rate) > 0.01) { // Alert if funding rate > 0.01%
          console.log(`🚨 High Funding Rate Alert: ${rate.toFixed(4)}% for BTC Perpetual`);
        }
      }
    });
    
    // Options Greeks analysis (if available)
    try {
      console.log('🎲 Options Analysis:');
      const optionsData = await api.getOptionsData('DERIBIT');
      const btcOptions = optionsData.filter(opt => opt.underlying === 'BTC' && opt.days_to_expiry < 30);
      
      if (btcOptions.length > 0) {
        console.log(`   Found ${btcOptions.length} BTC options expiring within 30 days`);
        const highDelta = btcOptions.filter(opt => Math.abs(opt.delta) > 0.5);
        console.log(`   ${highDelta.length} options with |Delta| > 0.5 (high sensitivity to price)`);
      }
    } catch (error) {
      console.log('📊 Options data not available');
    }
    
  } catch (error) {
    console.error('❌ Derivatives Analysis Error:', error.message);
  }
}

async function marketSentimentExample() {
  try {
    console.log('\n📊 Market Sentiment & Volatility Analysis');
    const api = new MarketData();
    
    // Volatility Index Analysis
    try {
      const volatilityIndex = await api.getIndexData('CAPIVIX');
      const fearGreedLevel = volatilityIndex.value > 80 ? 'EXTREME FEAR' :
                            volatilityIndex.value > 60 ? 'FEAR' :
                            volatilityIndex.value > 40 ? 'NEUTRAL' :
                            volatilityIndex.value > 20 ? 'GREED' : 'EXTREME GREED';
      
      console.log(`🎭 Market Sentiment: ${fearGreedLevel} (VIX: ${volatilityIndex.value.toFixed(2)})`);
    } catch (error) {
      console.log('📊 Volatility index not available');
    }
    
    // Correlation Analysis
    const symbols = ['BTC', 'ETH', 'ADA'];
    const correlationMatrix = {};
    
    for (const symbol1 of symbols) {
      correlationMatrix[symbol1] = {};
      const data1 = await api.getOHLCV(`COINBASE_SPOT_${symbol1}_USD`, {periodId: '1DAY', limit: 30});
      
      for (const symbol2 of symbols) {
        if (symbol1 === symbol2) {
          correlationMatrix[symbol1][symbol2] = 1.0;
          continue;
        }
        
        const data2 = await api.getOHLCV(`COINBASE_SPOT_${symbol2}_USD`, {periodId: '1DAY', limit: 30});
        
        // Calculate correlation coefficient
        const returns1 = data1.slice(1).map((candle, i) => (candle.price_close - data1[i].price_close) / data1[i].price_close);
        const returns2 = data2.slice(1).map((candle, i) => (candle.price_close - data2[i].price_close) / data2[i].price_close);
        
        const correlation = utils.calculateCorrelation(returns1, returns2);
        correlationMatrix[symbol1][symbol2] = correlation;
      }
    }
    
    console.log('🔗 30-Day Correlation Matrix:');
    console.log('     ', symbols.map(s => s.padEnd(6)).join(''));
    symbols.forEach(symbol1 => {
      const row = symbols.map(symbol2 => correlationMatrix[symbol1][symbol2].toFixed(2).padEnd(6)).join('');
      console.log(`${symbol1}: ${row}`);
    });
    
  } catch (error) {
    console.error('❌ Market Sentiment Error:', error.message);
  }
}

async function institutionalDataExample() {
  try {
    console.log('\n🏛️ Institutional Data & Flat Files');
    const api = new MarketData();
    
    // Bulk data access patterns
    console.log('💾 Available Flat File Data Types:');
    const dataTypes = ['trades', 'quotes', 'orderbook', 'ohlcv'];
    
    dataTypes.forEach(type => {
      console.log(`   📁 ${type.toUpperCase()}: S3://coinapi-market-data-${type}/`);
      console.log(`      Format: Parquet/CSV | Compression: GZIP | Partitioned by: exchange/date`);
    });
    
    // Snowflake integration example
    console.log('❄️ Snowflake SQL Analytics:');
    console.log(`
    -- Example queries for institutional analysis
    SELECT 
      symbol_id,
      exchange_id,
      AVG(price) as avg_price,
      SUM(size) as total_volume,
      COUNT(*) as trade_count
    FROM COINAPI.MARKET_DATA.TRADES 
    WHERE time_exchange >= '2024-01-01' 
      AND symbol_id LIKE '%BTC_USD'
    GROUP BY symbol_id, exchange_id
    ORDER BY total_volume DESC;
    `);
    
    // Advanced metrics for institutional clients
    const symbols = ['COINBASE_SPOT_BTC_USD', 'BINANCE_SPOT_BTC_USDT'];
    
    for (const symbol of symbols) {
      try {
        const trades = await api.getLatestTrades(symbol, 100);
        
        // Calculate VWAP
        const totalValue = trades.reduce((sum, trade) => sum + (trade.price * trade.size), 0);
        const totalVolume = trades.reduce((sum, trade) => sum + trade.size, 0);
        const vwap = totalValue / totalVolume;
        
        // Large trade analysis
        const largeTrades = trades.filter(trade => trade.size > 1.0); // > 1 BTC
        const institutionalFlow = largeTrades.reduce((sum, trade) => sum + trade.size, 0);
        
        console.log(`📊 ${symbol}:`);
        console.log(`   VWAP (100 trades): $${vwap.toFixed(2)}`);
        console.log(`   Institutional Flow: ${institutionalFlow.toFixed(2)} BTC (${largeTrades.length} large trades)`);
        
      } catch (error) {
        console.log(`⚠️ ${symbol} institutional data unavailable`);
      }
    }
    
  } catch (error) {
    console.error('❌ Institutional Data Error:', error.message);
  }
}

// =====================
// Volume Spike Detection Example  
// =====================

async function volumeSpikeExample() {
  try {
    const api = new MarketData();
    const ws = new WebSocketClient();
    
    // Get historical volume average (last 24 hours)
    const historical = await api.getOHLCV('BITSTAMP_SPOT_BTC_USD', {
      periodId: '1HRS',
      limit: 24
    });
    
    const avgVolume = historical.reduce((sum, candle) => sum + candle.volume_traded, 0) / historical.length;
    console.log(`📊 24h Average Volume: ${utils.formatVolume(avgVolume)}`);
    
    // Monitor real-time trades for volume spikes
    await ws.connect();
    
    let currentHourVolume = 0;
    let hourStart = new Date().getHours();
    
    ws.subscribeTrades(['BITSTAMP_SPOT_BTC_USD'], (trade) => {
      const currentHour = new Date().getHours();
      
      // Reset volume counter every hour
      if (currentHour !== hourStart) {
        currentHourVolume = 0;
        hourStart = currentHour;
      }
      
      currentHourVolume += trade.size;
      
      // Check for volume spike (2x average)
      if (currentHourVolume > avgVolume * 2) {
        console.log(`🚨 VOLUME SPIKE DETECTED! Current: ${utils.formatVolume(currentHourVolume)} | Average: ${utils.formatVolume(avgVolume)}`);
      }
    });
    
  } catch (error) {
    console.error('❌ Volume Spike Detection Error:', error.message);
  }
}

async function runExamples() {
  console.log('🚀 CoinAPI Comprehensive Examples\n');
  
  // Basic REST API examples
  await restApiExamples();
  
  // Utility examples
  utilityExamples();
  
  // Advanced Trading Examples (uncomment to run)
  // await marketMakingExample();
  // await arbitrageDetectionExample(); 
  // await portfolioManagementExample();
  // await derivativesAnalysisExample();
  // await marketSentimentExample();
  // await institutionalDataExample();
  
  // Volume spike detection
  // await volumeSpikeExample();
  
  // WebSocket examples (uncomment to run)
  // await webSocketExamples();
  
  console.log('\n✅ Examples completed');
}

// Export all functions for use in other files
export {
  restApiExamples,
  webSocketExamples,
  utilityExamples,
  volumeSpikeExample,
  marketMakingExample,
  arbitrageDetectionExample,
  portfolioManagementExample,
  derivativesAnalysisExample,
  marketSentimentExample,
  institutionalDataExample,
  runExamples
};

// Run examples if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runExamples().catch(console.error);
}